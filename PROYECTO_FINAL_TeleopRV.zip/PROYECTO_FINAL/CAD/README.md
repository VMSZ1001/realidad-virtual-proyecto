# Control háptico — CAD en SolidWorks

Carcasa de dos piezas para el control de mano descrito en `Docs/ESPECIFICACION.md`, hecha en
**SolidWorks 2026** para este hardware:

| Componente | Medidas usadas |
|---|---|
| ESP32 DevKit (30 pines) sobre **shield expansora** con filas G-V-S | shield 60 × 57 mm, agujeros a 3.5 mm de los bordes (**verificar**) |
| Joystick **HW-504** (KY-023) | PCB 34 × 26 mm, 32 mm de alto; agujeros 26.5 × 20 mm (**verificar**) |
| **MPU6050 GY-521** con regleta en L (pines acostados) | 21.2 × 16.4 mm; el plástico de la regleta la levanta 2.5 mm |
| **Módulo motor vibrador** (IN-VCC-GND) | 23 × 20.8 mm |
| **Powerbank 5000 mAh** | 99 × 61 × 15 mm, 114 g |

Todo sale de un solo script: `SolidWorks/generar_control_sw.py`. Las medidas están en el diccionario `P`
al principio; si algo no coincide con tus piezas, se corrige ahí y se vuelve a ejecutar (tarda ~2 min,
abre SolidWorks solo y regenera piezas, ensamblaje, STL, STEP e imágenes):

```bash
python CAD/SolidWorks/generar_control_sw.py
```

El script comprueba cada operación (si un corte o saliente no cambia el volumen, se detiene) y al final
corre la **detección de interferencias** del ensamblaje: hoy da *"Sin interferencias entre piezas"*.

## Archivos (`CAD/SolidWorks/`)

| Archivo | Qué es |
|---|---|
| `Carcasa_Base.SLDPRT` | Base: compartimento de la powerbank, repisa, postes y marcos de la electrónica |
| `Carcasa_Tapa.SLDPRT` | Tapa: agujero del joystick, LED, labio de encastre y torres de tornillos |
| `Control_TeleopRV.SLDASM` | Ensamblaje con los 7 componentes en su posición (todos fijos) |
| `Powerbank_5000mAh`, `Shield_ESP32`, `Joystick_HW504`, `MPU6050_GY521`, `Motor_vibrador` `.SLDPRT` | Modelos simplificados de los componentes, solo para el ensamblaje y las interferencias |
| `Control_TeleopRV.STEP` | Ensamblaje neutro (para abrirlo en otro CAD) |
| `STL/Carcasa_Base.STL`, `STL/Carcasa_Tapa.STL` | Para imprimir (mm, calidad fina) |
| `imagenes/` | Vistas: cerrado, sin tapa, superior y trasera; base y tapa sueltas |

Las operaciones del árbol tienen nombre (`Repisa`, `Postes_shield`, `Ventana_conectores`, …). Los croquis
no quedan acotados: para cambiar medidas conviene editar `P` y regenerar, no el árbol a mano.

## Diseño

**Medidas exteriores: 120.9 × 67.8 × 70.5 mm** (la perilla del joystick sobresale 10 mm). La tapa tiene
20 mm extra de altura (`tapa_extra`) para que los jumpers Dupont verticales de la shield quepan sin doblar
los cables. Base 76 g y tapa 66 g en PLA macizo (con 20–30 % de relleno quedan cerca de 80 g entre las dos).
Con la powerbank y la electrónica, el control pesa unos 250 g.

Coordenadas (las del firmware y Unity): **x** a lo largo, de la cara trasera (x = 0, conectores) hacia la
punta; **w** a lo ancho, positivo a la izquierda; **z** hacia arriba. En SolidWorks: X = x, Y = z, Z = w.

- **Piso (z 0–2) y compartimento de la powerbank (z 2–18.2)**, abierto por detrás. La powerbank entra por la
  cara trasera con sus puertos a ras; una pestaña de 0.8 mm en el piso la retiene (se levanta un poco para
  sacarla). Un agujero de 20 mm en el piso sirve para empujarla con el dedo. Tope delantero de 6 mm de alto.
- **Repisa (z 18.2–20.7)** que separa la powerbank de la electrónica. Sobre ella:
  - **Shield + ESP32** atrás, en 4 postes de 5 mm (M3 autorroscante, piloto de 2.5 mm), con su borde
    trasero a 0.6 mm de la pared: los conectores de la shield y el USB del ESP32 quedan en la
    **ventana trasera** (52 × 23 mm).
  - **Joystick** adelante, en 4 postes de 27.8 mm (Ø6.6) para que la perilla asome 10 mm sobre la tapa
    alta; la palanca queda en x = 103 mm, centrada. Entre la
    shield y el joystick quedan ~20 mm para los conectores Dupont del joystick.
  - **MPU6050** a la izquierda del joystick, en una cuna: el plástico de su regleta en L apoya en la repisa
    y el resto de la placa en un taco de 1.5 mm con cinta doble faz de espuma de 1 mm (queda nivelada), entre
    dos topes. La regleta va en el borde que mira al joystick, con **VCC hacia atrás**: así la flecha X del
    módulo apunta a la punta y la Y a la izquierda (lo que espera el firmware), y los 4 Dupont (VCC, GND, SCL,
    SDA) salen acostados por debajo del joystick, entre sus postes, hacia la shield.
  - **Módulo vibrador** de canto contra la pared derecha, metido en un riel: vibra directo en la pared
    que toca la palma. Se asegura con una gota de silicona caliente.
- **Tapa (z 27.5–70.5)**: agujero de 34 mm para la perilla, agujero de 3.2 mm para el LED de estado,
  labio de encastre de 2.5 mm que entra en la base, 4 tornillos **M3 × 25** desde arriba que roscan en las
  torres de la base. Como la tapa es alta, la cabeza del tornillo baja por un pozo de 6.5 mm (torre de 10 mm)
  hasta z ≈ 47: se necesita un destornillador de caña larga (≥ 25 mm).
- **Cara trasera**: abajo la boca de la powerbank, arriba la ventana de conectores. Un cable USB corto por
  fuera une la powerbank con la shield: enchufarlo enciende el control, desenchufarlo lo apaga.

## Imprimir

| Pieza | Orientación | Soportes |
|---|---|---|
| Base | Sobre el piso | **Solo dentro del compartimento de la powerbank** (la repisa es un puente de 63 mm). Se retiran por la boca trasera. En PrusaSlicer/Cura: pintar/bloquear soportes para que no salgan en otro lado |
| Tapa | **Boca abajo** (cara superior sobre la cama) | No necesita |

PLA o PETG, boquilla 0.4, capa 0.2 mm, 3 perímetros, 20–30 % de relleno.

## Verificar antes de imprimir (con calibrador)

1. **Shield**: largo y ancho (`sh_L`, `sh_W`), posición de los agujeros (`sh_ag_borde`) y que sus
   conectores de alimentación y el USB del ESP32 queden hacia el mismo borde (el trasero). Si el USB del
   ESP32 queda hacia el otro lado, se programa con la tapa quitada.
2. **Joystick HW-504**: distancia entre agujeros (`js_ag_dx`, `js_ag_dw`) y desfase de la palanca
   respecto al centro del PCB (`js_desf`).
3. **Powerbank**: que sus puertos estén en uno de los lados cortos (así quedan en la cara trasera).
4. **Perilla**: diámetro menor a 34 mm (`js_agujero`).

## Notas

- Algunas powerbanks se apagan solas si el consumo es muy bajo. El control consume ~110–150 mA con el
  Bluetooth conectado, lo que normalmente basta; si la tuya se apaga, prueba otro puerto de la powerbank.
- `anterior_openscad/` guarda el diseño anterior (OpenSCAD, LiPo + TP4056 + MT3608 y 3 botones). Ya no se usa.
