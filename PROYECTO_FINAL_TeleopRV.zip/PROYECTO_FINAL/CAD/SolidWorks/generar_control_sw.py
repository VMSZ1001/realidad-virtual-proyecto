# -*- coding: utf-8 -*-
"""
Genera en SolidWorks el control háptico TeleopRV (carcasa de 2 piezas + componentes + ensamblaje).

Uso (con SolidWorks instalado; se abre solo):
    python generar_control_sw.py            -> piezas, ensamblaje, STL, STEP e imágenes
    python generar_control_sw.py --sin-img  -> sin imágenes

Todas las medidas están en mm en el diccionario P de abajo. Si tus componentes miden distinto
(sobre todo la shield expansora y el joystick), corrige P y vuelve a ejecutar: se regenera todo.

Sistema de coordenadas del control (el mismo de Docs/ESPECIFICACION.md):
    x = a lo largo, de la cara trasera (x=0, conectores) hacia la punta (x=L)
    w = a lo ancho, positivo hacia la izquierda del usuario
    z = hacia arriba (z=0 es el fondo de la carcasa)
En SolidWorks: X = x, Y = z (arriba), Z = w.
"""
import math
import os
import struct
import sys
import types

import pythoncom
import win32com.client as wc
from win32com.client import VARIANT

AQUI = os.path.dirname(os.path.abspath(__file__))
SALIDA_STL = os.path.join(AQUI, "STL")
SALIDA_IMG = os.path.join(AQUI, "imagenes")
TEMPLATES = r"C:\ProgramData\SolidWorks\SOLIDWORKS 2026\templates"

# =====================================================================================
#  PARÁMETROS (mm)
# =====================================================================================
P = dict(
    # --- Carcasa ---
    t=2.4,            # pared lateral
    piso=2.0,         # espesor del piso
    techo=2.5,        # espesor de la tapa
    r_esq=8.0,        # radio de las esquinas verticales
    r_fondo=1.5,      # redondeo del borde inferior
    r_techo=3.0,      # redondeo del borde superior
    z_union=30.0,     # altura de la unión base/tapa
    labio_h=2.5,      # labio de encastre de la tapa (entra en la base)
    labio_e=1.2,      # espesor del labio
    labio_holg=0.2,   # holgura labio-pared
    tapa_extra=20.0,  # altura adicional de la tapa: espacio para los jumpers Dupont sin forzar los cables

    # --- Powerbank 5000 mAh (99 x 61 x 15, 114 g) ---
    pb_L=99.0, pb_W=61.0, pb_H=15.0,
    pb_holg_w=1.0,    # holgura a cada lado
    pb_holg_z=1.2,    # holgura en altura
    pb_holg_x=0.5,
    tope_x=2.0, tope_h=6.0,  # tope delantero de la powerbank (bajo: deja sacar los soportes de impresión por atrás)
    pestana_x=1.6, pestana_h=0.8, pestana_w=50.0,  # pestaña trasera que la retiene
    repisa=2.5,       # repisa que separa la powerbank de la electrónica
    dedo_d=20.0, dedo_x=70.0,  # agujero en el piso para empujar la powerbank hacia atrás

    # --- Shield expansora del ESP32 (VERIFICAR con calibrador) ---
    sh_L=60.0, sh_W=57.0, sh_t=1.6,
    sh_x0=3.0,        # distancia del borde trasero de la shield al exterior (x)
    sh_ag_borde=3.5,  # centro de los agujeros de la shield a cada borde
    sh_poste_h=5.0,   # altura de los postes (deja pasar las soldaduras por debajo)
    # ESP32 DevKit sobre la shield (solo para el ensamblaje)
    esp_L=51.5, esp_W=28.3, esp_t=1.6, esp_hdr=8.5,

    # --- Joystick HW-504 (KY-023) (VERIFICAR la distancia entre agujeros) ---
    js_L=34.0, js_W=26.0, js_t=1.6,
    js_alto=32.0,     # del fondo del PCB a la punta de la perilla
    js_desf=3.0,      # la palanca está 3 mm corrida hacia el lado sin pines
    js_ag_dx=26.5,    # distancia entre agujeros a lo largo
    js_ag_dw=20.0,    # distancia entre agujeros a lo ancho
    js_cx=100.0,      # centro del PCB en x
    js_asoma=10.0,    # cuánto sobresale la perilla por encima de la tapa
    js_agujero=34.0,  # agujero de la tapa para la perilla
    js_poste_d=6.6,   # diámetro de los postes del joystick (son altos: la tapa creció)

    # --- MPU6050 GY-521 con regleta en L (pines acostados, paralelos a la placa) ---
    # La regleta va en el borde interior (hacia el joystick) con VCC hacia atrás: así X del módulo apunta a la
    # punta e Y a la izquierda, como espera el firmware, y los Dupont pasan por debajo del joystick.
    mpu_L=21.2, mpu_W=16.4, mpu_t=1.6,
    mpu_x0=89.9, mpu_w0=14.8,   # esquina del PCB (x mínimo, w mínimo = borde de la regleta)
    mpu_reg_h=2.5, mpu_reg_w=2.5,   # plástico de la regleta en L, debajo del PCB
    mpu_taco_h=1.5,                 # taco bajo el resto del PCB (+1 mm de cinta doble faz = 2.5)
    mpu_tope_w1=24.5,               # el tope delantero termina antes de la torre del tornillo
    dupont_L=14.0,

    # --- Módulo motor vibrador (23 x 20.8), de canto contra la pared derecha ---
    mot_L=23.0, mot_H=20.8, mot_t=1.6,
    mot_x0=88.0,
    mot_riel_h=4.0,

    # --- Tornillos de la tapa (M3 x 25 autorroscante o M3 de máquina) ---
    tor_x=(67.0, None),   # None = junto a la pared delantera
    tor_d_pil=2.5, tor_d_pas=3.4, tor_d_cab=6.5, tor_cab_h=3.5, tor_boss=7.0,
    tor_L=25.0,       # largo del tornillo: si la tapa es alta, la cabeza queda embutida en un pozo
    tor_boss_cab=10.0,  # diámetro de la torre de la tapa alrededor del pozo de la cabeza
    pil_d=2.5,        # agujero piloto de los postes (M3 autorroscante; M2.5 para 2.2)

    # --- Ventana trasera para los conectores (USB del ESP32 y de la shield) ---
    ven_W=52.0, ven_z0=23.0, ven_z1=46.0,
    led_d=3.2, led_x=76.0, led_w=-20.0,

    pla_densidad=1240.0,  # kg/m3
)


def derivar(P):
    """Medidas que se calculan a partir de las anteriores."""
    D = dict(P)
    D["W_in"] = P["pb_W"] + 2 * P["pb_holg_w"]
    D["W"] = D["W_in"] + 2 * P["t"]
    D["bay_z0"] = P["piso"]
    D["bay_z1"] = P["piso"] + P["pb_H"] + P["pb_holg_z"]
    D["repisa_z"] = D["bay_z1"] + P["repisa"]                       # cara superior de la repisa
    D["pb_x0"] = P["pestana_x"] + 0.2
    D["tope_x0"] = D["pb_x0"] + P["pb_L"] + P["pb_holg_x"]
    D["js_x"] = P["js_cx"] + P["js_desf"]                           # centro de la palanca
    D["L_in_fin"] = P["js_cx"] + P["js_L"] / 2 + 1.5                # cara interior delantera
    D["L"] = D["L_in_fin"] + P["t"]
    # altura: cabe la pila shield + ESP32 + conectores Dupont verticales
    pila = D["repisa_z"] + P["sh_poste_h"] + P["sh_t"] + 2.5 + 14 + 4
    D["z_techo_in"] = max(pila, 48.0) + P["tapa_extra"]
    D["H"] = D["z_techo_in"] + P["techo"]
    D["js_z0"] = D["H"] + P["js_asoma"] - P["js_alto"]               # fondo del PCB del joystick
    D["js_poste_h"] = D["js_z0"] - D["repisa_z"]
    D["sh_z0"] = D["repisa_z"] + P["sh_poste_h"]
    wb = D["W_in"] / 2 - 3.0
    xf = D["L_in_fin"] - P["tor_boss"] / 2
    D["tornillos"] = [(P["tor_x"][0], wb), (P["tor_x"][0], -wb), (xf, wb), (xf, -wb)]
    x0, w0 = P["sh_x0"], P["sh_W"] / 2
    e = P["sh_ag_borde"]
    D["sh_agujeros"] = [(x0 + e, w0 - e), (x0 + e, -w0 + e), (x0 + P["sh_L"] - e, w0 - e), (x0 + P["sh_L"] - e, -w0 + e)]
    D["js_agujeros"] = [(P["js_cx"] + sx * P["js_ag_dx"] / 2, sw * P["js_ag_dw"] / 2) for sx in (-1, 1) for sw in (-1, 1)]
    return D


D = derivar(P)

# =====================================================================================
#  Capa delgada sobre la API de SolidWorks
# =====================================================================================
MM = 1e-3
NUL = VARIANT(pythoncom.VT_DISPATCH, None)
VACIO = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, [])


def g(o, n):
    """Llama un método COM sin argumentos o lee la propiedad (el enlace dinámico no los distingue)."""
    a = getattr(o, n)
    return a() if isinstance(a, types.MethodType) else a


class Pieza:
    """Documento de pieza con planos base: 'top' (z), 'front' (w), 'right' (x)."""

    def __init__(self, sw, nombre):
        self.sw = sw
        self.nombre = nombre
        self.m = sw.NewDocument(os.path.join(TEMPLATES, "Pieza.PRTDOT"), 0, 0, 0)
        if self.m is None:
            raise RuntimeError("No se pudo crear la pieza (¿plantilla?)")
        self.sm = self.m.SketchManager
        self.fm = self.m.FeatureManager
        planos = []
        f = g(self.m, "FirstFeature")
        while f:
            if g(f, "GetTypeName2") == "RefPlane":
                planos.append(f)
            f = g(f, "GetNextFeature")
        self.base = {"front": planos[0], "top": planos[1], "right": planos[2]}
        self.cache = {}
        self.n_ops = 0

    # ---------- planos ----------
    def plano(self, tipo, d):
        """Plano paralelo a 'top' (altura z=d), 'front' (w=d) o 'right' (x=d)."""
        d = round(d, 4)
        if d == 0:
            return self.base[tipo]
        clave = (tipo, d)
        if clave not in self.cache:
            self.m.ClearSelection2(True)
            self.base[tipo].Select2(False, 0)
            flags = 8 | (256 if d < 0 else 0)
            pl = self.fm.InsertRefPlane(flags, abs(d) * MM, 0, 0, 0, 0)
            if pl is None:
                raise RuntimeError(f"No se pudo crear el plano {clave}")
            pl.Name = f"P_{tipo}_{d:g}".replace(".", "_").replace("-", "m")
            # comprobar que el plano quedó del lado pedido (la bandera de invertir cambia entre versiones)
            tr = list(g(pl, "GetSpecificFeature2").Transform.ArrayData)
            eje = {"top": 10, "front": 11, "right": 9}[tipo]
            if abs(tr[eje] / MM - d) > 1e-3:
                raise RuntimeError(f"Plano {clave} quedó en {tr[eje] / MM:.3f} mm")
            self.cache[clave] = pl
            self.m.ClearSelection2(True)
        return self.cache[clave]

    # ---------- croquis ----------
    def _uv(self, tipo, a, b):
        # top: (x, w) -> (u=x, v=-w);  front: (x, z) -> (u=x, v=z);  right: (w, z) -> (u=-w, v=z)
        if tipo == "top":
            return a * MM, -b * MM
        if tipo == "front":
            return a * MM, b * MM
        return -a * MM, b * MM

    def croquis(self, tipo, d, formas, nombre=None):
        pl = self.plano(tipo, d)
        self.m.ClearSelection2(True)
        pl.Select2(False, 0)
        self.sm.InsertSketch(True)
        self.sm.AddToDB = True
        for f in formas:
            k = f[0]
            if k == "c":            # ("c", a, b, diámetro)
                u, v = self._uv(tipo, f[1], f[2])
                self.sm.CreateCircleByRadius(u, v, 0, f[3] / 2 * MM)
            elif k == "r":          # ("r", a0, b0, a1, b1) rectángulo por esquinas
                u0, v0 = self._uv(tipo, f[1], f[2])
                u1, v1 = self._uv(tipo, f[3], f[4])
                self.sm.CreateCornerRectangle(u0, v0, 0, u1, v1, 0)
            elif k == "pl":         # ("pl", [(a, b), ...]) polígono cerrado
                pts = [self._uv(tipo, a, b) for a, b in f[1]]
                for (u0, v0), (u1, v1) in zip(pts, pts[1:] + pts[:1]):
                    self.sm.CreateLine(u0, v0, 0, u1, v1, 0)
            elif k == "rr":         # ("rr", a_c, b_c, largo_a, largo_b, radio) rectángulo redondeado centrado
                self._rrect(tipo, *f[1:])
            else:
                raise ValueError(k)
        self.sm.AddToDB = False
        self.sm.InsertSketch(True)
        sk = self.m.FeatureByPositionReverse(0)
        if nombre:
            sk.Name = "Cq_" + nombre
        self.m.ClearSelection2(True)
        sk.Select2(False, 0)
        return sk

    def _rrect(self, tipo, ca, cb, la, lb, r):
        cu, cv = self._uv(tipo, ca, cb)
        a, b, r = la / 2 * MM, lb / 2 * MM, min(r, la / 2 - 0.01, lb / 2 - 0.01) * MM
        sm = self.sm
        if r <= 0:
            sm.CreateCornerRectangle(cu - a, cv - b, 0, cu + a, cv + b, 0)
            return
        sm.CreateLine(cu - a + r, cv - b, 0, cu + a - r, cv - b, 0)
        sm.CreateLine(cu + a, cv - b + r, 0, cu + a, cv + b - r, 0)
        sm.CreateLine(cu + a - r, cv + b, 0, cu - a + r, cv + b, 0)
        sm.CreateLine(cu - a, cv + b - r, 0, cu - a, cv - b + r, 0)
        sm.CreateArc(cu + a - r, cv - b + r, 0, cu + a - r, cv - b, 0, cu + a, cv - b + r, 0, 1)
        sm.CreateArc(cu + a - r, cv + b - r, 0, cu + a, cv + b - r, 0, cu + a - r, cv + b, 0, 1)
        sm.CreateArc(cu - a + r, cv + b - r, 0, cu - a + r, cv + b, 0, cu - a, cv + b - r, 0, 1)
        sm.CreateArc(cu - a + r, cv - b + r, 0, cu - a, cv - b + r, 0, cu - a + r, cv - b, 0, 1)

    # ---------- operaciones ----------
    def volumen(self):
        cuerpos = self.m.GetBodies2(0, False)
        if not cuerpos:
            return 0.0
        return sum(c.GetMassProperties(1.0)[3] for c in cuerpos) * 1e9

    def n_cuerpos(self):
        cuerpos = self.m.GetBodies2(0, False)
        return len(cuerpos) if cuerpos else 0

    def extruir(self, tipo, d, formas, alto, nombre, hacia=+1):
        """Saliente desde el plano (tipo, d) con altura 'alto' hacia +normal (hacia=+1) o -normal."""
        v0 = self.volumen()
        sk = self.croquis(tipo, d, formas, nombre)
        # Saliente: Dir=False -> +normal
        f = self.fm.FeatureExtrusion3(True, False, hacia < 0, 0, 0, alto * MM, 0.0, False, False, False, False,
                                      0.0, 0.0, False, False, False, False, True, True, True, 0, 0.0, False)
        self._verificar(f, nombre, v0, +1)
        return f

    def cortar(self, tipo, d, formas, prof, nombre, hacia=-1):
        """Corte desde el plano (tipo, d), profundidad 'prof' hacia +normal (+1) o -normal (-1).
        El plano NO debe coincidir con una cara del sólido (SolidWorks rechaza el corte): se arranca 0.5 mm afuera."""
        v0 = self.volumen()
        sk = self.croquis(tipo, d, formas, nombre)
        # Corte: Dir=True -> +normal
        f = self.fm.FeatureCut4(True, False, hacia > 0, 0, 0, prof * MM, 0.0, False, False, False, False,
                                0.0, 0.0, False, False, False, False, False, True, True, False, False, False,
                                0, 0.0, False, False)
        self._verificar(f, nombre, v0, -1)
        return f

    def _verificar(self, f, nombre, v0, signo):
        if f is None:
            raise RuntimeError(f"[{self.nombre}] falló la operación '{nombre}'")
        f.Name = nombre
        dv = self.volumen() - v0
        if dv * signo <= 1e-6:
            raise RuntimeError(f"[{self.nombre}] '{nombre}' no cambió el volumen (dv={dv:.3f} mm3)")
        self.n_ops += 1

    def redondear(self, puntos, r, nombre):
        """Redondeo de aristas elegidas por un punto sobre cada una (x, w, z en mm); propaga por tangencia."""
        self.m.ClearSelection2(True)
        ext = self.m.Extension
        for (x, w, z) in puntos:
            if not ext.SelectByID2("", "EDGE", x * MM, z * MM, w * MM, True, 1, NUL, 0):
                raise RuntimeError(f"[{self.nombre}] no se encontró la arista en {(x, w, z)}")
        f = self.fm.FeatureFillet3(195, r * MM, r * MM, 0, 0, 0, 0, VACIO, VACIO, VACIO, VACIO, VACIO, VACIO, VACIO)
        if f is None:
            raise RuntimeError(f"[{self.nombre}] falló el redondeo '{nombre}'")
        f.Name = nombre
        self.m.ClearSelection2(True)

    def color(self, rgb, brillo=0.3, transp=0.0):
        r, gg, b = [c / 255 for c in rgb]
        self.m.MaterialPropertyValues = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8,
                                                [r, gg, b, 1.0, 1.0, brillo, 0.3, transp, 0.0])

    def material_pla(self):
        try:
            self.m.SetMaterialPropertyName2("", "solidworks materials.sldmat", "PLA")
        except Exception:
            pass

    def caja(self, x0, x1, w0, w1, z0, z1, nombre):
        self.extruir("top", z0, [("r", x0, w0, x1, w1)], z1 - z0, nombre)

    def cilindro_z(self, x, w, d, z0, z1, nombre):
        self.extruir("top", z0, [("c", x, w, d)], z1 - z0, nombre)

    def ocultar_planos(self):
        self.m.ClearSelection2(True)
        for pl in self.cache.values():
            pl.Select2(True, 0)
        if self.cache:
            g(self.m, "BlankRefGeom")
        self.m.ClearSelection2(True)

    def guardar(self, ruta):
        self.ocultar_planos()
        self.m.ForceRebuild3(False)
        err = self.m.SaveAs3(ruta, 0, 1)
        if err != 0:
            raise RuntimeError(f"No se pudo guardar {ruta} (código {err})")
        return ruta


# =====================================================================================
#  Carcasa
# =====================================================================================
def construir_base(sw):
    p = Pieza(sw, "Base")
    L, W, t, H = D["L"], D["W"], P["t"], D["H"]
    Win, Lin = D["W_in"], L - 2 * t
    zu = P["z_union"]
    r_in = P["r_esq"] - t
    xc = L / 2

    # 1. Cuerpo exterior y vaciado
    p.extruir("top", 0, [("rr", xc, 0, L, W, P["r_esq"])], zu, "Cuerpo")
    p.cortar("top", zu + 0.5, [("rr", xc, 0, Lin, Win, r_in)], zu + 0.5 - P["piso"], "Vaciado")

    # 2. Repisa entre la powerbank y la electrónica
    p.extruir("top", D["bay_z1"], [("rr", xc, 0, Lin, Win, r_in)], P["repisa"], "Repisa")

    # 3. Tope que detiene la powerbank
    x0 = D["tope_x0"]
    p.extruir("top", D["bay_z0"], [("r", x0, -Win / 2, x0 + P["tope_x"], Win / 2)],
              P["tope_h"], "Tope_powerbank")

    # 4. Boca trasera de la powerbank y ventana de conectores (desde un plano 0.5 mm por detrás)
    p.cortar("right", -0.5, [("r", -Win / 2, D["bay_z0"], Win / 2, D["bay_z1"])], t + 1.0, "Boca_powerbank", hacia=+1)
    p.cortar("right", -0.5, [("r", -P["ven_W"] / 2, P["ven_z0"], P["ven_W"] / 2, zu + 1)], t + 1.0,
             "Ventana_conectores", hacia=+1)

    # 5. Pestaña trasera en el piso (la powerbank se levanta un poco para sacarla)
    p.extruir("top", P["piso"], [("r", 0.0, -P["pestana_w"] / 2, P["pestana_x"], P["pestana_w"] / 2)],
              P["pestana_h"], "Pestana_retencion")

    # 6. Agujero para empujar la powerbank con el dedo
    p.cortar("top", -0.5, [("c", P["dedo_x"], 0, P["dedo_d"])], P["piso"] + 1.0, "Agujero_dedo", hacia=+1)

    rz = D["repisa_z"]
    # 7. Postes de la shield
    p.extruir("top", rz, [("c", x, w, 6.0) for x, w in D["sh_agujeros"]], P["sh_poste_h"], "Postes_shield")
    p.cortar("top", rz + P["sh_poste_h"] + 0.5, [("c", x, w, P["pil_d"]) for x, w in D["sh_agujeros"]],
             P["sh_poste_h"] + 0.5, "Pilotos_shield")

    # 8. Postes del joystick
    p.extruir("top", rz, [("c", x, w, P["js_poste_d"]) for x, w in D["js_agujeros"]], D["js_poste_h"],
              "Postes_joystick")
    p.cortar("top", D["js_z0"] + 0.5, [("c", x, w, P["pil_d"]) for x, w in D["js_agujeros"]],
             min(8.0, D["js_poste_h"]), "Pilotos_joystick")

    # 9. Cuna del MPU6050: el plástico de la regleta en L apoya en la repisa y levanta el borde interior
    #    2.5 mm; el resto del PCB apoya en un taco de 1.5 mm con cinta doble faz de espuma de 1 mm.
    #    El borde de la regleta queda libre para que los Dupont salgan acostados hacia el joystick.
    x0, x1 = P["mpu_x0"], P["mpu_x0"] + P["mpu_L"]
    wa = P["mpu_w0"] + P["mpu_reg_w"] + 0.5
    p.extruir("top", rz, [("r", x0, wa, x1, Win / 2)], P["mpu_taco_h"], "Taco_MPU")
    h_tope = P["mpu_reg_h"] + P["mpu_t"] + 0.5
    p.extruir("top", rz, [("r", x0 - 1.6, wa, x0 - 0.4, Win / 2), ("r", x1 + 0.4, wa, x1 + 1.6, P["mpu_tope_w1"])],
              h_tope, "Topes_MPU")

    # 10. Riel del motor vibrador: el PCB entra de canto entre la pared derecha y el riel
    wpared = -Win / 2
    p.extruir("top", rz, [("r", P["mot_x0"], wpared + 2.2, P["mot_x0"] + P["mot_L"], wpared + 3.7)],
              P["mot_riel_h"], "Riel_motor")

    # 11. Torres de los tornillos de la tapa
    torres = D["tornillos"]
    p.extruir("top", rz, [("c", x, w, P["tor_boss"]) for x, w in torres], zu - rz, "Torres_tapa")
    p.cortar("top", zu + 0.5, [("c", x, w, P["tor_d_pil"]) for x, w in torres], zu - rz - 0.3, "Pilotos_tapa")

    # 12. Redondeo del borde inferior
    p.redondear([(xc, W / 2, 0.0)], P["r_fondo"], "Redondeo_fondo")
    p.material_pla()
    p.color((40, 44, 52))
    return p


def construir_tapa(sw):
    p = Pieza(sw, "Tapa")
    L, W, t, H = D["L"], D["W"], P["t"], D["H"]
    Win, Lin = D["W_in"], L - 2 * t
    zu = P["z_union"]
    r_in = P["r_esq"] - t
    xc = L / 2

    p.extruir("top", zu, [("rr", xc, 0, L, W, P["r_esq"])], H - zu, "Cuerpo")
    p.cortar("top", zu - 0.5, [("rr", xc, 0, Lin, Win, r_in)], D["z_techo_in"] - zu + 0.5, "Vaciado", hacia=+1)

    # Labio de encastre: entra 2.5 mm en la base
    hg, le = P["labio_holg"], P["labio_e"]
    ext = ("rr", xc, 0, Lin - 2 * hg, Win - 2 * hg, r_in - hg)
    intr = ("rr", xc, 0, Lin - 2 * (hg + le), Win - 2 * (hg + le), max(r_in - hg - le, 0.5))
    p.extruir("top", zu - P["labio_h"], [ext, intr], P["labio_h"] + 2.0, "Labio")
    p.extruir("top", zu, [("rr", xc, 0, Lin + 0.2, Win + 0.2, r_in + 0.1), intr], 2.0, "Union_labio")

    # Torres de los tornillos
    torres = D["tornillos"]
    p.extruir("top", zu, [("c", x, w, P["tor_boss"]) for x, w in torres], D["z_techo_in"] - zu, "Torres")
    # el labio no debe chocar con las torres de la base
    p.cortar("top", zu - P["labio_h"] - 0.5, [("c", x, w, P["tor_boss"] + 1.0) for x, w in torres],
             P["labio_h"] + 0.5, "Alivio_labio_torres", hacia=+1)
    # el labio tampoco debe chocar con el módulo vibrador, que va pegado a la pared derecha
    mx0, mx1 = P["mot_x0"] - 1.0, P["mot_x0"] + P["mot_L"] + 1.0
    p.cortar("top", zu - P["labio_h"] - 0.5, [("r", mx0, -Win / 2 - 0.1, mx1, -Win / 2 + 1.6)],
             P["labio_h"] + 3.0, "Alivio_labio_motor", hacia=+1)
    p.cortar("top", H + 0.5, [("c", x, w, P["tor_d_pas"]) for x, w in torres], H - zu + 1.0, "Pasantes")
    # Cabeza del tornillo: con tornillo de tor_L la cabeza apoya en z_cab (pozo si la tapa es alta)
    z_cab = min(D["repisa_z"] + 1.5 + P["tor_L"], H - P["tor_cab_h"])
    if H - z_cab > P["tor_cab_h"] + 0.1:
        p.extruir("top", z_cab - 3.0, [("c", x, w, P["tor_boss_cab"]) for x, w in torres],
                  D["z_techo_in"] - z_cab + 3.0, "Torres_pozo")
    p.cortar("top", H + 0.5, [("c", x, w, P["tor_d_cab"]) for x, w in torres], H + 0.5 - z_cab, "Avellanado")

    # Ventana trasera de conectores y agujeros de la cara superior
    p.cortar("right", -0.5, [("r", -P["ven_W"] / 2, zu - P["labio_h"] - 1, P["ven_W"] / 2, P["ven_z1"])], t + 2.0,
             "Ventana_conectores", hacia=+1)
    p.cortar("top", H + 0.5, [("c", D["js_x"], 0, P["js_agujero"])], P["techo"] + 1.0, "Agujero_joystick")
    p.cortar("top", H + 0.5, [("c", P["led_x"], P["led_w"], P["led_d"])], P["techo"] + 1.0, "Agujero_LED")

    p.redondear([(xc, W / 2, H)], P["r_techo"], "Redondeo_techo")
    p.material_pla()
    p.color((230, 120, 30))
    return p


# =====================================================================================
#  Componentes (modelos simplificados en la posición final)
# =====================================================================================
def construir_powerbank(sw):
    p = Pieza(sw, "Powerbank")
    x0, z0 = D["pb_x0"], P["piso"]
    p.extruir("top", z0, [("rr", x0 + P["pb_L"] / 2, 0, P["pb_L"], P["pb_W"], 6.0)], P["pb_H"], "Cuerpo")
    # puertos en la cara trasera (referencia visual)
    p.cortar("right", -0.5, [("r", -9, z0 + 5, 3, z0 + 10)], 8.0, "Puerto_USB_A", hacia=+1)
    p.cortar("right", -0.5, [("rr", 12, z0 + 7.5, 9, 3.4, 1.6)], 7.0, "Puerto_USB_C", hacia=+1)
    p.color((20, 20, 20), brillo=0.6)
    return p


def construir_shield(sw):
    p = Pieza(sw, "Shield_ESP32")
    x0, z0 = P["sh_x0"], D["sh_z0"]
    p.caja(x0, x0 + P["sh_L"], -P["sh_W"] / 2, P["sh_W"] / 2, z0, z0 + P["sh_t"], "PCB_shield")
    p.cortar("top", z0 + P["sh_t"] + 0.5, [("c", x, w, 3.0) for x, w in D["sh_agujeros"]], P["sh_t"] + 1, "Agujeros")
    zt = z0 + P["sh_t"]
    # filas GVS a los lados
    for s in (1, -1):
        wc_ = s * (P["sh_W"] / 2 - 9)
        p.caja(x0 + 6, x0 + P["sh_L"] - 6, wc_ - 3.8, wc_ + 3.8, zt, zt + 8.5, f"GVS_{'izq' if s > 0 else 'der'}")
    # conectores de alimentación de la shield (DC + USB-C) en el borde trasero
    p.caja(x0 - 0.5, x0 + 13, -P["sh_W"] / 2 + 12, -P["sh_W"] / 2 + 21, zt, zt + 11, "Jack_DC")
    p.caja(x0 - 0.5, x0 + 7, P["sh_W"] / 2 - 22, P["sh_W"] / 2 - 13, zt, zt + 3.3, "USB_C_shield")
    # ESP32 DevKit sobre regletas hembra
    ex0 = x0 + 1.5
    ez = zt + P["esp_hdr"]
    for s in (1, -1):
        wc_ = s * (P["esp_W"] / 2 - 1.3)
        p.caja(ex0 + 3, ex0 + P["esp_L"] - 3, wc_ - 1.3, wc_ + 1.3, zt, ez, f"Regleta_{s}")
    p.caja(ex0, ex0 + P["esp_L"], -P["esp_W"] / 2, P["esp_W"] / 2, ez, ez + P["esp_t"], "PCB_ESP32")
    et = ez + P["esp_t"]
    p.caja(ex0 + P["esp_L"] - 25.5, ex0 + P["esp_L"] - 0.5, -9, 9, et, et + 3.2, "Modulo_WROOM")
    p.caja(ex0 - 1.0, ex0 + 6.5, -4.5, 4.5, et, et + 3.2, "USB_ESP32")
    p.color((20, 90, 160))
    return p


def construir_joystick(sw):
    p = Pieza(sw, "Joystick_HW504")
    cx, z0 = P["js_cx"], D["js_z0"]
    p.caja(cx - P["js_L"] / 2, cx + P["js_L"] / 2, -P["js_W"] / 2, P["js_W"] / 2, z0, z0 + P["js_t"], "PCB")
    p.cortar("top", z0 + P["js_t"] + 0.5, [("c", x, w, 3.2) for x, w in D["js_agujeros"]], P["js_t"] + 1, "Agujeros")
    zt = z0 + P["js_t"]
    jx = D["js_x"]
    p.caja(jx - 10, jx + 10, -10, 10, zt, zt + 11, "Cuerpo_potenciometros")
    p.cilindro_z(jx, 0, 14, zt + 11, zt + 16, "Domo")
    p.cilindro_z(jx, 0, 4.5, zt + 16, D["H"] + 1, "Palanca")
    p.cilindro_z(jx, 0, 26, D["H"] + P["js_asoma"] - 9, D["H"] + P["js_asoma"], "Perilla")
    # pines en ángulo recto hacia atrás
    p.caja(cx - P["js_L"] / 2 - 8, cx - P["js_L"] / 2 + 1, -6.4, 6.4, zt, zt + 2.5, "Pines")
    p.color((30, 30, 30), brillo=0.5)
    return p


def construir_mpu(sw):
    p = Pieza(sw, "MPU6050_GY521")
    x0, w0, rz = P["mpu_x0"], P["mpu_w0"], D["repisa_z"]
    z0 = rz + P["mpu_reg_h"]                       # el PCB descansa sobre el plástico de la regleta
    x1 = x0 + P["mpu_L"]
    p.caja(x0, x1, w0, w0 + P["mpu_W"], z0, z0 + P["mpu_t"], "PCB")
    zt = z0 + P["mpu_t"]
    p.caja(x0 + 8, x0 + 12, w0 + 7, w0 + 11, zt, zt + 0.9, "Chip")
    # regleta en L: plástico bajo el borde y 8 pines acostados hacia -w
    p.caja(x0 + 0.3, x1 - 0.3, w0, w0 + P["mpu_reg_w"], rz, rz + P["mpu_reg_h"], "Regleta_L")
    c = x0 + P["mpu_L"] / 2                        # 8 pines a 2.54 mm centrados en el PCB
    p.caja(c - 8.89 - 0.32, c + 8.89 + 0.32, w0 - 6.0, w0, rz + 0.95, rz + 1.55, "Pines")
    # Dupont en VCC, GND, SCL, SDA (los 4 primeros, del lado trasero)
    xa, xb = c - 8.89 - 1.3, c - 1.27 + 1.3
    p.caja(xa, xb, w0 - P["dupont_L"], w0 - 0.2, rz + 0.05, rz + 2.55, "Dupont")
    p.color((30, 90, 200))
    return p


def construir_motor(sw):
    p = Pieza(sw, "Motor_vibrador")
    x0, z0 = P["mot_x0"], D["repisa_z"] + 0.2
    wpared = -D["W_in"] / 2 + 0.3
    p.caja(x0, x0 + P["mot_L"], wpared, wpared + P["mot_t"], z0, z0 + P["mot_H"], "PCB")
    # motor de moneda hacia el interior
    p.extruir("front", wpared + P["mot_t"], [("c", x0 + 9, z0 + P["mot_H"] / 2, 10)], 3.0, "Motor")
    p.caja(x0 - 8, x0 + 1, wpared + P["mot_t"], wpared + P["mot_t"] + 2.5, z0 + 6.6, z0 + 14.2, "Pines")
    p.color((15, 15, 15))
    return p


# =====================================================================================
#  Exportación
# =====================================================================================
def caja_stl(ruta):
    with open(ruta, "rb") as f:
        datos = f.read()
    n = struct.unpack("<I", datos[80:84])[0]
    if 84 + n * 50 != len(datos):
        raise RuntimeError(f"{ruta}: STL no binario")
    mn = [1e9] * 3
    mx = [-1e9] * 3
    for i in range(n):
        o = 84 + i * 50 + 12
        for k in range(3):
            v = struct.unpack("<3f", datos[o + 12 * k:o + 12 * k + 12])
            for j in range(3):
                mn[j] = min(mn[j], v[j])
                mx[j] = max(mx[j], v[j])
    return [round(b - a, 2) for a, b in zip(mn, mx)], n


def exportar_stl(sw, doc, ruta):
    """STL binario en mm con calidad fina (0.02 mm, 5°); deja las preferencias del usuario como estaban."""
    ints = {78: 3, 211: 0}                # swSTLQuality = Custom, swExportStlUnits = mm
    dbls = {2: 0.02 * MM, 3: math.radians(5)}   # swSTLDeviation (m), swSTLAngleTolerance (rad)
    tog = {69: True}                      # swSTLBinaryFormat
    antes = ({k: sw.GetUserPreferenceIntegerValue(k) for k in ints},
             {k: sw.GetUserPreferenceDoubleValue(k) for k in dbls},
             {k: sw.GetUserPreferenceToggle(k) for k in tog})
    try:
        for k, v in ints.items():
            sw.SetUserPreferenceIntegerValue(k, v)
        for k, v in dbls.items():
            sw.SetUserPreferenceDoubleValue(k, v)
        for k, v in tog.items():
            sw.SetUserPreferenceToggle(k, v)
        err = doc.SaveAs3(ruta, 0, 1)
        if err != 0:
            raise RuntimeError(f"No se pudo exportar {ruta} ({err})")
    finally:
        for k, v in antes[0].items():
            sw.SetUserPreferenceIntegerValue(k, v)
        for k, v in antes[1].items():
            sw.SetUserPreferenceDoubleValue(k, v)
        for k, v in antes[2].items():
            sw.SetUserPreferenceToggle(k, v)


def construir_ensamblaje(sw, rutas, ruta_asm):
    asm = sw.NewDocument(os.path.join(TEMPLATES, "Ensamblaje.ASMDOT"), 0, 0, 0)
    if asm is None:
        raise RuntimeError("No se pudo crear el ensamblaje")
    # AddComponent5 ubica el CENTRO del componente en (x, y, z): se reemplaza por la transformación
    # identidad para que cada pieza quede donde fue modelada (todas usan el origen de la carcasa)
    mu = g(sw, "GetMathUtility")
    mu._FlagAsMethod("CreateTransform")
    ident = VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, [1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0])
    for r in rutas:
        c = asm.AddComponent5(r, 0, "", False, "", 0, 0, 0)
        if c is None:
            raise RuntimeError(f"No se pudo insertar {r}")
        c.Transform2 = mu.CreateTransform(ident)
    asm.ClearSelection2(True)
    for c in asm.GetComponents(True):
        c.Select4(True, NUL, False)
    g(asm, "FixComponent")
    asm.ClearSelection2(True)
    asm.ForceRebuild3(False)
    err = asm.SaveAs3(ruta_asm, 0, 1)
    if err != 0:
        raise RuntimeError(f"No se pudo guardar el ensamblaje ({err})")
    return asm


def interferencias(asm):
    """Detección de interferencias del ensamblaje: [(componentes, mm3)] con volumen > 0."""
    im = asm.InterferenceDetectionManager
    im.TreatCoincidenceAsInterference = False
    im.TreatSubAssembliesAsComponents = True
    im.IncludeMultibodyPartInterferences = False
    im.MakeInterferingPartsTransparent = False
    im.CreateFastenersFolder = False
    for n in ("GetInterferenceCount", "GetInterferences", "Done"):
        im._FlagAsMethod(n)
    im.GetInterferenceCount()
    out = []
    for it in im.GetInterferences() or ():
        it = wc.Dispatch(it)
        vol = it.Volume * 1e9
        if vol > 0.01:
            out.append(([wc.Dispatch(c).Name2 for c in it.Components], round(vol, 2)))
    im.Done()
    return out


def imagen(sw, doc, ruta, vista, ocultar=()):
    g(doc, "ViewDisplayShaded")
    doc.ShowNamedView2("", vista)
    g(doc, "ViewZoomtofit2")
    g(doc, "GraphicsRedraw2")
    err = doc.SaveAs3(ruta, 0, 1)
    return err == 0


def main():
    con_img = "--sin-img" not in sys.argv
    os.makedirs(SALIDA_STL, exist_ok=True)
    os.makedirs(SALIDA_IMG, exist_ok=True)
    pythoncom.CoInitialize()
    sw = wc.Dispatch("SldWorks.Application")
    sw.Visible = True
    sw.CloseAllDocuments(True)

    print(f"Carcasa exterior: {D['L']:.1f} x {D['W']:.1f} x {D['H']:.1f} mm")
    print(f"Joystick: postes de {D['js_poste_h']:.1f} mm, perilla {P['js_asoma']} mm sobre la tapa")

    fabricas = [
        ("Carcasa_Base", construir_base),
        ("Carcasa_Tapa", construir_tapa),
        ("Powerbank_5000mAh", construir_powerbank),
        ("Shield_ESP32", construir_shield),
        ("Joystick_HW504", construir_joystick),
        ("MPU6050_GY521", construir_mpu),
        ("Motor_vibrador", construir_motor),
    ]
    rutas = []
    masas = {}
    for nombre, fab in fabricas:
        p = fab(sw)
        ruta = p.guardar(os.path.join(AQUI, nombre + ".SLDPRT"))
        rutas.append(ruta)
        vol = p.volumen()
        if p.n_cuerpos() != 1 and nombre.startswith("Carcasa"):
            raise RuntimeError(f"{nombre}: quedó con {p.n_cuerpos()} cuerpos")
        masas[nombre] = vol
        print(f"  {nombre}: {p.n_ops} operaciones, {vol / 1000:.1f} cm3")
        if nombre.startswith("Carcasa"):
            stl = os.path.join(SALIDA_STL, nombre + ".STL")
            exportar_stl(sw, p.m, stl)
            dims, n = caja_stl(stl)
            print(f"    STL {n} triángulos, caja {dims}")
            if con_img:
                imagen(sw, p.m, os.path.join(SALIDA_IMG, nombre + ".png"), 7)

    for nombre in ("Carcasa_Base", "Carcasa_Tapa"):
        g_ = masas[nombre] * 1e-9 * P["pla_densidad"] * 1000
        print(f"  Masa {nombre} (PLA macizo): {g_:.0f} g")

    asm = construir_ensamblaje(sw, rutas, os.path.join(AQUI, "Control_TeleopRV.SLDASM"))
    choques = interferencias(asm)
    for comps, vol in choques:
        print(f"  INTERFERENCIA {' <-> '.join(comps)}: {vol} mm3")
    if not choques:
        print("  Sin interferencias entre piezas")
    asm.SaveAs3(os.path.join(AQUI, "Control_TeleopRV.STEP"), 0, 1)
    if con_img:
        imagen(sw, asm, os.path.join(SALIDA_IMG, "Ensamblaje_cerrado.png"), 7)
        tapa = [c for c in asm.GetComponents(True) if c.Name2.startswith("Carcasa_Tapa")][0]
        tapa.Visible = 0
        imagen(sw, asm, os.path.join(SALIDA_IMG, "Ensamblaje_sin_tapa.png"), 7)
        imagen(sw, asm, os.path.join(SALIDA_IMG, "Ensamblaje_superior.png"), 5)   # swTopView
        tapa.Visible = 1
        imagen(sw, asm, os.path.join(SALIDA_IMG, "Ensamblaje_trasera.png"), 3)   # swLeftView: mira la cara trasera (x = 0)
        asm.Save3(1, VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0), VARIANT(pythoncom.VT_BYREF | pythoncom.VT_I4, 0))
    print("Listo.")


if __name__ == "__main__":
    main()
