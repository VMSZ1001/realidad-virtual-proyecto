# Carcasa del control háptico — CAD

Carcasa imprimible (FDM, PLA o PETG, boquilla de 0.4 mm, **sin soportes**) del control
háptico inalámbrico de una mano descrito en `Docs/ESPECIFICACION.md`: ESP32 DevKit V1,
MPU6050 (GY-521), 3 pulsadores, motor vibrador de moneda, LiPo 503450, TP4056 USB-C,
MT3608 e interruptor SS12D00.

| Archivo | Contenido |
|---|---|
| `carcasa_control.scad` | Modelo paramétrico único (OpenSCAD, solo primitivas nativas; no usa BOSL2 ni MCAD) |
| `vista_previa.py` | Genera el plano acotado 2D leyendo los **mismos** parámetros del `.scad` |
| `plano_carcasa.png` | Plano esquemático para el informe (vistas superior ×2, corte lateral, vista trasera) |

**Dimensiones exteriores:** 160 × 50 × 36 mm (cintura de agarre de 45 mm de ancho).
Los capuchones del pulgar sobresalen 2 mm por arriba y el gatillo 3 mm por debajo.
Masa estimada con electrónica: unos 140 g. Centro de masa estimado en x ≈ 78 mm, es decir,
dentro de la mano y junto al MPU (x = 80).

Sistema de coordenadas (el mismo del firmware y de Unity): **+X** a lo largo del eje largo hacia la
punta, **+Y** a la izquierda del usuario y **+Z** hacia arriba (la cara de los botones del pulgar).
El pitch es el giro alrededor de Y (inclinar la punta) y el roll el giro alrededor de X (girar sobre
el eje largo).

---

## 1. Piezas

| `pieza =` | Qué es | Orientación en el STL |
|---|---|---|
| `"base"` | Media carcasa inferior. Contiene el piso, los esquineros del ESP32, los postes del MPU, el alojamiento del motor, el marco y la ventana del interruptor, la guía y los postes del gatillo, los postes de la bandeja, las guías de cables, las 4 torres M3 con avellanado inferior, la ranura USB de programación y el labio de encastre. | Piso sobre la cama |
| `"tapa"` | Media carcasa superior. Contiene los agujeros triangulares ADELANTE/ATRÁS con sus guías, los postes de la placa del pulgar, los nervios que sujetan la batería, el tubo del LED, 4 torres (piloto M3 o inserto) y la ranura USB-C de carga. | **Ya volteada**: cara exterior sobre la cama |
| `"bandeja"` | Placa separadora de 2 mm que va sobre el ESP32. Lleva el TP4056 y el MT3608 (atrás) y la batería (adelante), con esquinas de ubicación y una ventana para pasar cables. Queda aprisionada entre las torres traseras de la base y de la tapa. | Plana |
| `"botones"` | 3 capuchones: **ADELANTE** (triángulo hacia la punta, con un punto en relieve), **ATRÁS** (triángulo hacia atrás, liso) y **AGARRE** (gatillo rectangular con dos nervios). Cada uno tiene una **pestaña** más ancha que su agujero, así que se meten desde adentro y no se pueden caer. | Pestaña sobre la cama |
| `"ensamble"` | Vista explotada con componentes fantasma en colores (ESP32 verde, MPU azul con flecha roja X+, batería gris, placas azules, pulsadores negros, capuchones naranja). Úsela con **F5**; con F6 se pierden los colores. | — |
| `"todo"` | Todas las piezas separadas en la cama (≈ 200 × 190 mm), solo como referencia. Se recomienda imprimirlas por separado. | — |

## 2. Parámetros clave (inicio del `.scad`, todos en mm)

| Parámetro | Valor | Nota |
|---|---|---|
| `largo`, `alto` | 160, 36 | Cuerpo exterior |
| `ancho_trasero` / `ancho_cintura` / `ancho_cabeza` | 50 / 45 / 50 | Forma de mando con cintura de agarre |
| `radio_borde`, `pared` | 5, 2.2 | Redondeo de aristas y espesor de pared |
| `alto_base`, `labio_alto`, `labio_holgura` | 20, 2, 0.3 | Plano de unión y encastre |
| `holgura` | 0.5 | Holgura alrededor de cada componente |
| `tipo_fijacion` | `"autorroscante"` | Cámbielo a `"inserto"` para insertos térmicos M3 (agujero `inserto_d` = 4.0 × 6 mm) |
| `esp_largo`, `esp_ancho`, `esp_hueco_pines` | 55, 28, 10.5 | Para el DevKit de **30 pines** use unos 51.5 × 28.5 |
| `mpu_x`, `mpu_sep_agujeros`, `mpu_rot` | `largo/2`, 15.2, 0 | MPU en el centro. Mida la separación de los agujeros de su módulo |
| `bat_largo`, `bat_ancho`, `bat_alto`, `bat_x0` | 50, 34, 5.5, 54 | Revise la medida real (ver sección 8) |
| `boton_tam`, `boton_alto` | 12, 7.3 | Para pulsadores 6×6×5 ponga 6 y 5 |
| `x_atras`, `x_adelante`, `x_gatillo` | 117, 139, 133 | Posición de los botones (21 y 43 mm desde la punta) |
| `lado_palma`, `lado_interruptor` | −1, +1 | Motor del lado de la palma (diestro). Para zurdo invierta ambos |
| `cabeza_saliente`, `gat_saliente` | 2, 3 | Cuánto sobresalen los capuchones |
| `fn_esfera` | 28 | Súbalo a 48 para el STL final (más suave, más lento) |

Al renderizar, la consola muestra un `echo` con las dimensiones, el espacio libre entre las placas
de botones (3.2 mm con 12×12) y lo que entran los tornillos. Si algún componente choca, aparece una
**ADVERTENCIA**.

## 3. Exportar STL

**Desde la interfaz:** abra `carcasa_control.scad`, cambie la línea `pieza = "todo";` a la pieza que
quiere, presione **F6** (render; puede tardar de 1 a 3 minutos) y vaya a **Archivo › Exportar ›
Exportar como STL**.

**Por línea de comandos** (con `openscad` en el PATH):

```bash
# bash / Git Bash / Linux / macOS
openscad -o base.stl    -D 'pieza="base"'    carcasa_control.scad
openscad -o tapa.stl    -D 'pieza="tapa"'    carcasa_control.scad
openscad -o bandeja.stl -D 'pieza="bandeja"' carcasa_control.scad
openscad -o botones.stl -D 'pieza="botones"' carcasa_control.scad
```

```bat
:: cmd.exe (Windows)
"C:\Program Files\OpenSCAD\openscad.exe" -o base.stl -D "pieza=\"base\"" carcasa_control.scad
```

Para suavizar el acabado final agregue `-D fn_esfera=48`.

Plano 2D: `python vista_previa.py` regenera `plano_carcasa.png` con los parámetros que tenga el `.scad`.

## 4. Impresión

| Pieza | Orientación | Capa | Perímetros | Relleno | Notas |
|---|---|---|---|---|---|
| Base | Piso abajo | 0.2 mm | 3 (1.2 mm) | 20–25 % gyroid | Sin soportes. Los techos de las ranuras (11 mm), de la ventana del interruptor y del marco se imprimen como puentes cortos |
| Tapa | Cara exterior abajo (ya viene así) | 0.2 mm | 3 | 20–25 % gyroid | Torres, postes, guías y nervios crecen hacia arriba. Con 5 capas superiores/inferiores la cara visible queda lisa |
| Bandeja | Plana | 0.2 mm | 3 | 30 % | Pieza sencilla |
| Botones | Pestaña abajo | 0.12–0.16 mm | — | 100 % | Imprimir varios juegos y quedarse con los que deslicen mejor |

- Material: PLA (fácil) o PETG (más resistente a golpes y al calor del auto). Como la pared es de 2.2 mm
  y se usan 3 perímetros, la pared queda prácticamente sólida.
- Las aristas redondeadas (r = 5) que tocan la cama tienen un voladizo leve en las primeras capas.
  Active la compensación de "pata de elefante" (0.1–0.2 mm).
- Revise el encastre del labio con una impresión de prueba. Si queda duro, suba `labio_holgura` a 0.4.
  Si queda flojo, bájela a 0.2.
- PETG: agregue unos 0.1 mm a `holgura_boton` si los capuchones rozan.

## 5. Lista de materiales (tornillería y consumibles)

| Cant. | Elemento | Uso |
|---|---|---|
| 4 | Tornillo **M3 × 30 cabeza avellanada** (DIN 965 / ISO 7046, o Allen avellanado ISO 10642) | Cierre base–tapa, desde abajo. En modo autorroscante se rosca directo en el piloto de 2.5 mm de la tapa (entra 9.5–10 mm) |
| 4 | Inserto térmico M3 (Ø ext. 4.0–4.6, largo 5.7) — *opcional* | Solo con `tipo_fijacion = "inserto"`, colocados con cautín en las torres de la tapa |
| 2 | Tornillo autorroscante **M2.5 × 6** (o M2 × 6 con `mpu_piloto = 1.7`) | Fijar el MPU6050 a sus postes |
| 8 | Tornillo autorroscante **M2 × 6** | 4 para la placa del pulgar y 4 para la placa del gatillo |
| 1 | Placa perforada 2.54 mm de 5 × 7 cm | Cortar 40 × 26 mm (pulgar) y 32 × 20 mm (gatillo) y taladrar Ø2.2 a 3 mm de cada esquina |
| 3 | Pulsador táctil 12 × 12 × 7.3 mm | ADELANTE, ATRÁS, AGARRE |
| 1 | LED de 3 mm + resistencia de 330 Ω | Estado, en paralelo con GPIO2 (el LED integrado queda tapado por la bandeja) |
| — | Cinta doble faz de espuma de 1 mm | TP4056 y MT3608 sobre la bandeja; espuma sobre la batería |
| — | Pegamento (silicona caliente o cianoacrilato) | Motor contra la pared, LED en su tubo y, si hace falta, el ESP32 en sus esquineros |
| 4 | Patas de goma adhesivas de ≥ 4 mm — *recomendado* | Para que el gatillo no quede oprimido al dejar el control sobre la mesa |
| — | Cable calibre 26–28 AWG y termoencogible | Cableado interno |

## 6. Orden de ensamble

1. **Preparar:** ajuste el MT3608 a **5.0 V** antes de montarlo (con la carcasa cerrada el
   potenciómetro no queda accesible). Suelde los cables a los pines del ESP32 (sin conectores
   Dupont: no caben), al GY-521 (directo a los pads o con pines hacia arriba), a los pulsadores
   en sus placas perforadas, al motor y al interruptor.
2. **Base:**
   1. MPU6050 sobre sus 2 postes con M2.5, componentes hacia arriba y con la **flecha X de su
      serigrafía apuntando igual que la flecha "X+" en relieve del piso** (hacia la punta).
      Los agujeros del módulo quedan del lado +Y y el conector del lado −Y.
   2. Motor pegado dentro de su anillo, con la cara plana contra la pared y los cables saliendo por la ranura superior.
   3. Interruptor SS12D00 a presión en su marco, con la palanca asomando por la ventana lateral.
   4. Capuchón **AGARRE** metido desde adentro por el agujero del piso. Luego la placa del gatillo,
      con el pulsador hacia abajo, atornillada con 4 × M2 a sus postes.
   5. ESP32 entre los 4 esquineros en L, con el USB hacia la cara trasera y alineado con la ranura.
   6. Pasar los cables por las guías del piso.
3. **Bandeja:** pegue el TP4056 (USB-C contra la cara trasera) y el MT3608 con cinta doble faz dentro
   de sus esquinas. Coloque la bandeja sobre los pasadores de los postes, con los cables del ESP32
   pasando por la ventana central, y ponga la batería en sus esquinas con 1 mm de espuma encima.
4. **Tapa:** meta los capuchones **ADELANTE** (punta hacia la punta del control) y **ATRÁS** desde
   adentro. Atornille la placa del pulgar (pulsadores hacia arriba) con 4 × M2. Pegue el LED en su tubo.
5. **Cierre:** una los cables de la tapa (botones y LED) dejando holgura, encaje el labio y ponga
   los 4 tornillos M3 × 30 desde abajo. Los 2 traseros también aprietan la bandeja.
6. **Prueba:** cargue por la ranura USB-C trasera y programe por la ranura USB inferior de la misma
   cara. Con el monitor serie compruebe que al **inclinar la punta hacia abajo el pitch sube** y que
   al **girar a la derecha el roll sube** (convención de `ESPECIFICACION.md` §5).

## 7. Justificación ergonómica (para el informe técnico)

- **Agarre tipo mando con gatillo.** El control se sostiene como un control remoto o un mando de
  RV de una mano. La palma envuelve la zona media (cintura de 45 mm, un poco más estrecha que la
  cabeza y el pomo de 50 mm), así que la mano queda ubicada por tacto y no se desliza a lo largo.
  Todas las aristas tienen un redondeo de 5 mm para no marcar la palma durante sesiones largas.
- **Posición del pulgar.** ADELANTE y ATRÁS están en la cara superior, sobre el eje central, a
  21 mm y 43 mm de la punta y separados 22 mm entre centros. Es donde descansa el pulgar con la
  mano cerrada, sin estirarlo. Se distinguen **sin mirar**, lo que es indispensable con el visor
  puesto: son triángulos que apuntan en la dirección del movimiento que producen, y ADELANTE
  además tiene un punto en relieve.
- **Gatillo bajo el índice.** AGARRE está en la cara inferior, a 27 mm de la punta, justo debajo
  de los botones del pulgar. El índice lo oprime con un movimiento natural de "cerrar la mano", que
  coincide con la metáfora de agarrar un objeto. Su forma alargada (12 × 20 mm, transversal al
  dedo) con dos nervios lo hace diferente al tacto de los botones del pulgar.
- **Peso centrado.** La batería (el componente más pesado, unos 20 g) va sobre la bandeja en la
  zona de la palma. El ESP32 y los reguladores van en el pomo trasero y los botones en la cabeza.
  El centro de masa estimado (x ≈ 78 mm) queda dentro de la mano, casi sobre el MPU (x = 80 mm),
  así que el control no "cabecea" ni cansa la muñeca. La masa total (unos 140 g) es parecida a
  la de un mando de RV comercial.
- **IMU alineada con los ejes del control.** El MPU6050 va **plano sobre postes del propio piso**
  (no sobre la bandeja, para evitar flexión), en el **centro geométrico** (x = L/2, y = 0). Su eje X
  queda paralelo al eje largo y su eje Y al eje corto, con flechas en relieve como guía. Así, el
  pitch (inclinar adelante/atrás) y el roll (girar sobre el eje largo) se leen directamente de los
  ejes del sensor, sin matrices de corrección. Como está sobre el eje de roll y cerca del centro
  del agarre, las aceleraciones tangenciales y centrípetas al girar la muñeca son pequeñas frente a
  la gravedad, y el filtro complementario estima mejor la inclinación.
- **Háptica donde se siente.** El motor de moneda va en un anillo pegado a la pared lateral del
  lado de la palma, en la cintura, donde el contacto con la piel es mayor. Queda a unos 8 mm del
  MPU y sin contacto directo con sus postes, lo que reduce el ruido de vibración en el acelerómetro.
- **Servicio.** Carga (USB-C) y programación (USB) salen por el pomo trasero, lejos de la mano.
  El interruptor queda en el costado izquierdo del pomo, detrás del meñique, así que no se apaga por
  accidente. El LED de estado queda visible arriba, entre el pomo y el agarre.

## 8. Suposiciones que debe verificar con sus componentes

1. **ESP32:** se asumió una PCB de 55 × 28 mm, pines de 8.5 mm bajo la PCB, al menos 3 mm libres de
   pines en cada extremo corto (ahí apoyan los esquineros) y el conector USB centrado en el lado
   corto. Con Dupont hembra **no cabe**: suelde los cables o recorte los pines. El LED integrado
   (GPIO2) queda tapado por la bandeja, por eso se usa un LED externo en paralelo.
2. **GY-521:** separación de agujeros de 15.2 mm, a 2.5 mm del borde opuesto al conector, y eje X de
   la serigrafía paralelo al lado largo de 21 mm. Si su módulo es distinto, ajuste
   `mpu_sep_agujeros` y `mpu_agujero_borde`, o gire el patrón con `mpu_rot = 180`. Confirme los
   signos de pitch y roll en el firmware.
3. **Batería 503450:** muchas traen el circuito de protección doblado en un extremo y miden
   **52–53 mm** de largo y hasta 6 mm de espesor. Hay espacio hasta unos 51.5 mm con
   `bat_x0 = 54`. Si la suya es más larga, reduzca `bat_x0` (mínimo unos 52, por la torre trasera)
   o suba `bandeja_x_fin`.
4. **TP4056:** 28 × 17 mm con el USB-C centrado en el lado corto (algunas versiones miden 26 × 17). Si su
   conector no está centrado, ajuste `tp_y`.
5. **Pulsadores:** la altura total de 7.3 mm (base del cuerpo hasta la punta del vástago) define dónde
   quedan las placas. Si usa otra altura, cambie `boton_alto`. Con 6×6×5 ponga `boton_tam = 6` y
   `boton_alto = 5`.
6. **SS12D00:** se asumió una palanca de unos 4 mm, que asoma cerca de 1.8 mm fuera de la pared. Con
   palanca corta (2 mm) no alcanza a salir: use un interruptor de palanca larga.
7. **Motor:** 10 × 3 mm (hay de 10 × 2.7; el anillo tiene 3.4 mm de fondo y el pegamento compensa).
8. **Gatillo:** sobresale 3 mm por debajo. Al apoyar el control sobre la mesa queda oprimido, por
   eso se recomiendan las patas de goma o dejarlo de lado.
9. **Modelo sin renderizar:** OpenSCAD no estaba instalado cuando se escribió el modelo. Se revisaron
   la sintaxis y el balance de paréntesis, y el plano 2D se genera con los mismos parámetros, pero la
   **primera vez presione F6 y revise la consola** antes de imprimir. Conviene imprimir primero la
   bandeja y un capuchón como prueba de ajuste.
