// =====================================================================
//  CARCASA DEL CONTROL HÁPTICO INALÁMBRICO
//  Proyecto final · Realidad Virtual · Ingeniería Mecatrónica · UMNG
//
//  ESP32 DevKit V1 + MPU6050 (GY-521) + 3 pulsadores + motor vibrador
//  + LiPo 503450 + TP4056 (USB-C) + MT3608 + interruptor SS12D00.
//
//  Sistema de coordenadas (el mismo del firmware / Unity):
//    +X = eje largo, hacia la PUNTA del control (adelante)
//    +Y = eje corto, hacia la IZQUIERDA del usuario
//    +Z = hacia arriba (cara de los botones del pulgar)
//  Pitch = giro alrededor de Y (inclinar la punta arriba/abajo).
//  Roll  = giro alrededor de X (girar sobre el eje largo).
//
//  Todas las medidas en milímetros. Solo primitivas nativas de OpenSCAD
//  (sin BOSL2 ni MCAD). Probado sintácticamente para OpenSCAD 2019.05+.
//
//  Uso:  cambie la variable `pieza` y presione F5 (vista) o F6 (render),
//        luego Archivo > Exportar > STL.  Por consola:
//        openscad -o base.stl -D 'pieza="base"' carcasa_control.scad
// =====================================================================

// ---------------------------------------------------------------------
// PIEZA A GENERAR
//   "base"     : media carcasa inferior (orientada para imprimir)
//   "tapa"     : media carcasa superior (ya volteada para imprimir)
//   "bandeja"  : placa separadora batería / electrónica
//   "botones"  : 3 capuchones (ADELANTE, ATRÁS, AGARRE)
//   "ensamble" : vista explotada con componentes fantasma en colores (F5)
//   "todo"     : todas las piezas separadas sobre la cama de impresión
// ---------------------------------------------------------------------
pieza = "todo";

// ---------------------------------------------------------------------
// CALIDAD DE RENDER
// ---------------------------------------------------------------------
$fa = 6;               // ángulo mínimo de faceta (grados)
$fs = 0.5;             // tamaño mínimo de faceta (mm)
fn_esfera = 28;        // caras de las esferas del cuerpo (48 para el STL final)

// ---------------------------------------------------------------------
// CUERPO EXTERIOR (forma de mando de una mano)
// ---------------------------------------------------------------------
largo          = 160;  // largo total (eje X)
alto           = 36;   // alto total base + tapa (eje Z)
ancho_trasero  = 50;   // ancho del pomo trasero (zona de electrónica)
ancho_cintura  = 45;   // ancho de la zona de agarre (más estrecha)
ancho_cabeza   = 50;   // ancho de la cabeza (zona de botones)
x_fin_trasero  = 60;   // donde termina el tramo trasero recto
x_ini_cintura  = 82;   // donde empieza la cintura
x_fin_cintura  = 100;  // donde termina la cintura
x_ini_cabeza   = 122;  // donde empieza la cabeza
radio_borde    = 5;    // radio de redondeo de todas las aristas
pared          = 2.2;  // espesor de pared (2.0 a 2.4)
alto_base      = 20;   // altura del plano de unión base/tapa
labio_alto     = 2.0;  // altura del labio de encastre
labio_holgura  = 0.3;  // juego total entre labio y rebaje
holgura        = 0.5;  // holgura general alrededor de los componentes

// ---------------------------------------------------------------------
// TORNILLERÍA DE CIERRE (4 tornillos M3 desde abajo)
// ---------------------------------------------------------------------
tipo_fijacion  = "autorroscante"; // "autorroscante" (rosca en el plástico) o "inserto" (inserto térmico M3)
tornillo_paso  = 3.4;  // agujero pasante M3 en la base y la bandeja
tornillo_piloto = 2.5; // agujero piloto M3 en la tapa (modo autorroscante)
inserto_d      = 4.0;  // agujero para inserto térmico M3 (según su inserto: 4.0 a 4.2)
inserto_prof   = 6.0;  // profundidad del agujero del inserto
avellanado_d   = 6.4;  // diámetro del avellanado 90° (M3 cabeza avellanada DIN 965)
tornillo_largo = 30;   // largo recomendado del tornillo M3 (se verifica abajo con echo)
prof_tornillo_tapa = 12; // profundidad del agujero en las torres de la tapa
torre_d        = 7;    // diámetro de las torres de los tornillos
torre_x_tras   = 48;   // X de las torres traseras
torre_x_del    = 150;  // X de las torres delanteras
torre_y        = 18.5; // |Y| de las torres
m2_piloto      = 1.7;  // piloto para tornillos M2 autorroscantes (placas de botones)
poste_d        = 5;    // diámetro de los postes internos
pin_d          = 2.0;  // pasador de centrado de los postes de la bandeja
pin_alto       = 1.5;  // altura del pasador

// ---------------------------------------------------------------------
// ESP32 DevKit V1 (38 pines) — va en el piso de la base, al fondo,
// con el conector USB hacia la cara trasera
// ---------------------------------------------------------------------
esp_largo      = 55;   // largo de la PCB
esp_ancho      = 28;   // ancho de la PCB
esp_pcb        = 1.6;  // espesor de la PCB
esp_alto_sobre_pcb = 3.5; // módulo WROOM / conector sobre la PCB
esp_hueco_pines = 10.5;// espacio bajo la PCB: pines de 8.5 mm + 2 mm para cables soldados
esp_x0         = 3.0;  // X del borde trasero (lado USB) de la PCB
usb_esp_ancho  = 11;   // ancho de la ranura USB de programación (cabe el plástico del cable)
usb_esp_alto   = 7;    // alto de la ranura USB de programación
usb_esp_sobre_pcb = 1.3; // altura del centro del conector sobre la cara superior de la PCB
esq_apoyo      = 3;    // tamaño del apoyo de las esquinas bajo la PCB (sin pines ahí)
esq_pared      = 1.2;  // espesor de las esquinas en L
esq_largo      = 6;    // largo de cada brazo de las esquinas en L

// ---------------------------------------------------------------------
// BANDEJA SEPARADORA (encima del ESP32; soporta TP4056, MT3608 y batería)
// ---------------------------------------------------------------------
bandeja_esp    = 2.0;  // espesor de la bandeja
bandeja_x_fin  = 106;  // X del borde delantero de la bandeja
bandeja_holgura = 0.5; // juego entre bandeja y pared interior
borde_alto     = 2.0;  // altura de las esquinas de ubicación de las placas
cinta          = 1.0;  // espesor de la cinta doble faz bajo TP4056/MT3608
pase_x         = 48;   // centro X de la ventana de paso de cables de la bandeja
pase_largo     = 7;    // largo (X) de la ventana de paso de cables
pase_ancho     = 10;   // ancho (Y) de la ventana de paso de cables

// ---------------------------------------------------------------------
// TP4056 con protección (USB-C) — sobre la bandeja, USB hacia atrás
// ---------------------------------------------------------------------
tp_largo       = 28;
tp_ancho       = 17;
tp_x0          = 3.0;  // X del borde trasero (lado USB-C)
tp_y           = 10.5; // Y del centro de la placa
tp_usb_alto    = 3.2;  // alto del conector USB-C
ranura_tp_ancho = 12;  // ancho de la ranura de carga
ranura_tp_alto = 7;    // alto de la ranura de carga

// ---------------------------------------------------------------------
// MT3608 (elevador a 5 V) — sobre la bandeja, al lado del TP4056
// ---------------------------------------------------------------------
mt_largo       = 37;
mt_ancho       = 17;
mt_alto        = 6;
mt_x0          = 5;
mt_y           = -9.25;

// ---------------------------------------------------------------------
// BATERÍA LiPo 503450 (1000 mAh) — sobre la bandeja, zona del agarre
// ---------------------------------------------------------------------
bat_largo      = 50;
bat_ancho      = 34;
bat_alto       = 5.5;
bat_x0         = 54;   // X del extremo trasero de la batería
espuma         = 1.0;  // espuma entre batería y nervios de la tapa
nervio_x1      = 62;   // X del primer nervio que sujeta la batería
nervio_x2      = 95;   // X del segundo nervio
nervio_largo   = 28;   // largo (Y) de los nervios
nervio_esp     = 1.6;  // espesor de los nervios

// ---------------------------------------------------------------------
// MPU6050 GY-521 — PLANO en el piso, en el centro del control, eje X del
// módulo (serigrafía) paralelo al eje largo y apuntando a la punta
// ---------------------------------------------------------------------
mpu_largo      = 21;   // lado paralelo a X (lado del conector de 8 pines)
mpu_ancho      = 16;   // lado paralelo a Y
mpu_alto       = 3;    // alto con el chip
mpu_x          = largo / 2; // centro del módulo (centro del control)
mpu_sep_agujeros = 15.2; // distancia entre los 2 agujeros Ø3 (mídala en su módulo)
mpu_agujero_borde = 2.5; // distancia del centro del agujero al borde opuesto al conector
mpu_poste_alto = 4;    // altura de los postes sobre el piso
mpu_piloto     = 2.2;  // piloto para M2.5 autorroscante (1.7 si usa M2)
mpu_rot        = 0;    // giro del patrón de montaje (0 o 180) si su módulo lo requiere

// ---------------------------------------------------------------------
// MOTOR VIBRADOR DE MONEDA — pegado a la pared lateral del agarre (palma)
// ---------------------------------------------------------------------
motor_d        = 10;
motor_esp      = 3;
motor_anillo   = 1.2;  // espesor del anillo del alojamiento
motor_x        = 90;
motor_z        = 11.5; // altura del centro del motor
lado_palma     = -1;   // -1 = lado derecho (+Y es izquierda): palma de mano derecha

// ---------------------------------------------------------------------
// INTERRUPTOR DESLIZANTE SS12D00 — ventana en el costado
// ---------------------------------------------------------------------
int_largo      = 8.5;  // cuerpo (dirección de deslizamiento, eje X)
int_ancho      = 3.6;  // cuerpo (eje Z)
int_soporte_prof = 3.0;// profundidad del marco que lo sujeta
int_x          = 25;
int_z          = 10;
lado_interruptor = 1;  // +1 = costado izquierdo (+Y), -1 = derecho
int_ventana_largo = 5.0; // ventana para la palanca (incluye recorrido)
int_ventana_alto = 2.4;

// ---------------------------------------------------------------------
// PULSADORES TÁCTILES (12x12x7.3 por defecto; para 6x6x5 use 6 y 5)
// ---------------------------------------------------------------------
boton_tam      = 12;   // lado del cuerpo del pulsador
boton_alto     = 7.3;  // altura total: base del cuerpo hasta la punta del vástago
boton_cuerpo_alto = 3.5; // altura del cuerpo metálico
precarga       = 0.2;  // el vástago empuja el capuchón 0.2 mm (evita traqueteo)

// Capuchones (pieza "botones")
holgura_boton  = 0.3;  // juego entre capuchón y agujero
manga_alto     = 3.0;  // guía tubular bajo el techo / sobre el piso
manga_pared    = 1.2;  // pared de la guía
pestana_ancho  = 1.5;  // pestaña de retención (sobresale del contorno)
pestana_esp    = 1.0;  // espesor de la pestaña
cabeza_saliente = 2.0; // cuánto sobresalen ADELANTE/ATRÁS sobre la tapa

// Botones del pulgar (cara superior): triángulos que apuntan adelante/atrás
x_atras        = 117;  // centro del botón ATRÁS (triángulo hacia atrás)
x_adelante     = 139;  // centro del botón ADELANTE (triángulo hacia adelante)
tri_radio      = 8;    // radio circunscrito del triángulo
tri_redondeo   = 1.5;  // redondeo de las puntas del triángulo
pp_largo       = 40;   // placa perforada de los botones del pulgar (X)
pp_ancho       = 26;   // placa perforada de los botones del pulgar (Y)
pp_esp         = 1.6;  // espesor de la placa perforada
pp_inset       = 3;    // distancia del agujero de fijación al borde de la placa

// Gatillo AGARRE (cara inferior, bajo el índice)
x_gatillo      = 133;
gat_largo      = 12;   // X
gat_ancho      = 20;   // Y (a lo ancho del dedo)
gat_redondeo   = 3;
gat_saliente   = 3.0;  // cuánto sobresale bajo el piso
pg_largo       = 32;   // placa perforada del gatillo (X)
pg_ancho       = 20;   // placa perforada del gatillo (Y)
pg_esp         = 1.6;

// ---------------------------------------------------------------------
// LED DE ESTADO (LED externo de 3 mm en paralelo con GPIO2)
// ---------------------------------------------------------------------
led_x          = 50;
led_y          = 0;
led_d          = 3;
led_manga      = 5;    // largo del tubo que sujeta el LED bajo la tapa

// ---------------------------------------------------------------------
// GUÍAS DE CABLES (pares de nervios bajos en el piso)
// ---------------------------------------------------------------------
guia1_x        = 61;
guia2_x        = 105;
guia_largo     = 11;
guia_y         = 11.5;
guia_canal     = 3.5;  // ancho del canal entre nervios
guia_alto      = 3;
marca_alto     = 0.6;  // relieve de las flechas de orientación

// ---------------------------------------------------------------------
// VISTA EXPLOTADA
// ---------------------------------------------------------------------
explosion      = 30;   // separación entre niveles en "ensamble"

// ---------------------------------------------------------------------
// POSICIONES (vectores)
// ---------------------------------------------------------------------
// Tramos del cuerpo: [x, ancho]. El cuerpo es la unión de envolventes
// (hull) de esferas entre estaciones consecutivas.
estaciones = [[radio_borde, ancho_trasero], [x_fin_trasero, ancho_trasero], [x_ini_cintura, ancho_cintura], [x_fin_cintura, ancho_cintura], [x_ini_cabeza, ancho_cabeza], [largo - radio_borde, ancho_cabeza]];
torres = [[torre_x_tras, torre_y], [torre_x_tras, -torre_y], [torre_x_del, torre_y], [torre_x_del, -torre_y]];
postes_bandeja = [[8, 18.5], [8, -18.5], [36, 18.5], [36, -18.5], [78, 16], [78, -16], [101, 14.5], [101, -14.5]];
botones_pulgar = [[x_atras, -1], [x_adelante, 1]];

// ---------------------------------------------------------------------
// VALORES DERIVADOS (no editar)
// ---------------------------------------------------------------------
ancho_max        = max(ancho_trasero, ancho_cintura, ancho_cabeza);
z_techo          = alto - pared;                         // cara interior del techo
esp_z            = pared + esp_hueco_pines;              // cara inferior de la PCB del ESP32
esp_tope         = esp_z + esp_pcb + esp_alto_sobre_pcb; // punto más alto del ESP32
bandeja_z0       = esp_tope + 0.7;                       // cara inferior de la bandeja
bandeja_z1       = bandeja_z0 + bandeja_esp;             // cara superior de la bandeja
tp_z             = bandeja_z1 + cinta;                   // cara inferior de la PCB del TP4056
z_usb_tp         = tp_z + 1.6 + tp_usb_alto / 2;         // centro de la ranura de carga
z_usb_esp        = esp_z + esp_pcb + usb_esp_sobre_pcb;  // centro de la ranura de programación
z_bat_sup        = bandeja_z1 + bat_alto + holgura;      // cara superior de la batería
z_pestana_pulgar = z_techo - manga_alto - pestana_esp;   // cara inferior de la pestaña (pulgar)
z_pp_sup         = z_pestana_pulgar - boton_alto + precarga; // cara superior de la placa del pulgar
z_pestana_gat    = pared + manga_alto + pestana_esp;     // cara superior de la pestaña (gatillo)
z_pg_inf         = z_pestana_gat + boton_alto - precarga;// cara inferior de la placa del gatillo
x_pp             = (x_atras + x_adelante) / 2;           // centro de la placa del pulgar
hueco_placas     = (z_pp_sup - pp_esp - 1.5) - (z_pg_inf + pg_esp + 1.5); // espacio libre entre placas (con patas)

// === FIN DE PARÁMETROS === (vista_previa.py lee hasta esta línea)

// =====================================================================
// FUNCIONES
// =====================================================================
function ancho_en(x, i = 0) =
    (i >= len(estaciones) - 1) ? estaciones[len(estaciones) - 1][1] :
    (x <= estaciones[i][0]) ? estaciones[i][1] :
    (x <= estaciones[i + 1][0]) ?
        estaciones[i][1] + (estaciones[i + 1][1] - estaciones[i][1]) * (x - estaciones[i][0]) / (estaciones[i + 1][0] - estaciones[i][0]) :
    ancho_en(x, i + 1);

function y_pared_int(x) = ancho_en(x) / 2 - pared;          // |Y| de la cara interior de la pared
function z_torre_base(x) = (x < bandeja_x_fin) ? bandeja_z0 : alto_base;
function z_torre_tapa(x) = (x < bandeja_x_fin) ? bandeja_z1 : alto_base;

// =====================================================================
// GEOMETRÍA BÁSICA
// =====================================================================
// Una estación: 4 esferas en las esquinas de la sección (Y-Z).
// d = desplazamiento de la superficie (0 exterior, -pared interior).
module estacion(e, d) {
    for (sy = [-1, 1], z = [radio_borde, alto - radio_borde])
        translate([e[0], sy * (e[1] / 2 - radio_borde), z])
            sphere(r = radio_borde + d, $fn = fn_esfera);
}

// Cuerpo sólido: unión de envolventes entre estaciones consecutivas.
// Como todo son esferas, cuerpo(-pared) es un desfase exacto -> pared uniforme.
module cuerpo(d = 0) {
    for (i = [0 : len(estaciones) - 2])
        hull() {
            estacion(estaciones[i], d);
            estacion(estaciones[i + 1], d);
        }
}

// Contorno en planta (a media altura) con desfase d.
module planta(d = 0) {
    for (i = [0 : len(estaciones) - 2])
        hull()
            for (j = [i, i + 1], sy = [-1, 1])
                translate([estaciones[j][0], sy * (estaciones[j][1] / 2 - radio_borde)])
                    circle(r = radio_borde + d);
}

module caja_z(z0, z1) {
    translate([-10, -100, z0]) cube([largo + 20, 200, z1 - z0]);
}

module rect_redondeado(lx, ly, r) {
    offset(r = r) square([max(lx - 2 * r, 0.01), max(ly - 2 * r, 0.01)], center = true);
}

module forma_triangulo(dir = 1) {
    rotate(dir > 0 ? 0 : 180)
        offset(r = tri_redondeo) offset(delta = -tri_redondeo)
            polygon([[tri_radio, 0],
                     [tri_radio * cos(120), tri_radio * sin(120)],
                     [tri_radio * cos(240), tri_radio * sin(240)]]);
}

module forma_gatillo() {
    rect_redondeado(gat_largo, gat_ancho, gat_redondeo);
}

module forma_capuchon(tipo) {
    if (tipo == "adelante") forma_triangulo(1);
    else if (tipo == "atras") forma_triangulo(-1);
    else forma_gatillo();
}

module flecha2d(lf, af) {
    polygon([[0, -af / 2], [lf - 4, -af / 2], [lf - 4, -af / 2 - 1.5], [lf, 0],
             [lf - 4, af / 2 + 1.5], [lf - 4, af / 2], [0, af / 2]]);
}

// =====================================================================
// BASE (media carcasa inferior)
// =====================================================================
module base() {
    difference() {
        union() {
            difference() {
                intersection() { cuerpo(0); caja_z(-1, alto_base); }
                cuerpo(-pared);
            }
            labio_base();
            intersection() { cuerpo(0); elementos_base(); }
        }
        vaciados_base();
        vaciados_comunes();
    }
}

// Labio: mitad interior de la pared que sube por encima del plano de unión
module labio_base() {
    intersection() {
        difference() {
            cuerpo(-pared / 2 - labio_holgura / 2);
            cuerpo(-pared);
        }
        caja_z(alto_base - 0.01, alto_base + labio_alto);
    }
}

module elementos_base() {
    // Torres de los tornillos de cierre
    for (t = torres)
        translate([t[0], t[1], 0]) cylinder(d = torre_d, h = z_torre_base(t[0]));
    // Postes de la bandeja con pasador de centrado
    for (p = postes_bandeja)
        translate([p[0], p[1], 0]) {
            cylinder(d = poste_d, h = bandeja_z0);
            cylinder(d = pin_d, h = bandeja_z0 + pin_alto);
        }
    esquineros_esp();
    soporte_mpu();
    alojamiento_motor();
    soporte_interruptor();
    gatillo_base();
    guias_cable();
    marcas_orientacion();
}

// Esquina en L: apoyo bajo la PCB + dos paredes que la ubican
module esquinero(h_apoyo, h_total) {
    cube([esq_apoyo, esq_apoyo + 0.5, h_apoyo]);
    translate([-esq_pared, -esq_pared, 0]) cube([esq_largo, esq_pared, h_total]);
    translate([-esq_pared, -esq_pared, 0]) cube([esq_pared, esq_largo, h_total]);
}

module esquineros_esp() {
    x0 = esp_x0;
    x1 = esp_x0 + esp_largo + holgura;
    y1 = (esp_ancho + holgura) / 2;
    for (cx = [0, 1], cy = [0, 1])
        translate([cx == 0 ? x0 : x1, cy == 0 ? -y1 : y1, 0])
            scale([cx == 0 ? 1 : -1, cy == 0 ? 1 : -1, 1])
                esquinero(esp_z, esp_z + esp_pcb + 1.5);
}

module soporte_mpu() {
    translate([mpu_x, 0, 0]) rotate([0, 0, mpu_rot]) {
        for (sx = [-1, 1]) {
            // postes con agujero (lado de los agujeros del módulo)
            translate([sx * mpu_sep_agujeros / 2, mpu_ancho / 2 - mpu_agujero_borde, 0])
                cylinder(d = poste_d, h = pared + mpu_poste_alto);
            // apoyos sin tornillo (lado del conector) para que quede plano
            translate([sx * mpu_sep_agujeros / 2, -mpu_ancho / 2 + 5, 0])
                cylinder(d = 3, h = pared + mpu_poste_alto);
        }
        // contorno de ubicación en el piso
        translate([0, 0, pared - 0.01]) linear_extrude(0.4 + 0.01)
            difference() {
                square([mpu_largo + holgura + 1.6, mpu_ancho + holgura + 1.6], center = true);
                square([mpu_largo + holgura, mpu_ancho + holgura], center = true);
            }
    }
}

// Alojamiento cilíndrico del motor de moneda, pegado a la pared (palma)
module alojamiento_motor() {
    yw = y_pared_int(motor_x);
    translate([motor_x, lado_palma * yw, motor_z])
        scale([1, -lado_palma, 1])          // +Y local apunta hacia el interior
            rotate([-90, 0, 0])             // eje del cilindro -> +Y local
                difference() {
                    translate([0, 0, -1])
                        cylinder(d = motor_d + holgura + 2 * motor_anillo, h = motor_esp + 0.4 + 1);
                    cylinder(d = motor_d + holgura, h = motor_esp + 2);
                    translate([-1.25, -20, -0.5]) cube([2.5, 20, motor_esp + 3]); // salida de cables hacia arriba
                }
}

// Marco que sujeta el cuerpo del interruptor contra la pared
module soporte_interruptor() {
    yw = y_pared_int(int_x);
    L = int_largo + 0.4;
    A = int_ancho + 0.4;
    translate([int_x, lado_interruptor * yw, int_z])
        scale([1, -lado_interruptor, 1])
            difference() {
                translate([-L / 2 - 1.2, -1, -A / 2 - 1.2]) cube([L + 2.4, int_soporte_prof + 1, A + 2.4]);
                translate([-L / 2, -2, -A / 2]) cube([L, int_soporte_prof + 3, A]);
            }
}

module ventana_interruptor() {
    yw = y_pared_int(int_x);
    translate([int_x, lado_interruptor * yw, int_z])
        scale([1, -lado_interruptor, 1])
            translate([-int_ventana_largo / 2, -pared - 2, -int_ventana_alto / 2])
                cube([int_ventana_largo, pared + 2.5, int_ventana_alto]);
}

// Guía del capuchón del gatillo + postes de su placa perforada
module gatillo_base() {
    translate([x_gatillo, 0, 0]) {
        linear_extrude(pared + manga_alto)
            offset(r = holgura_boton + manga_pared) forma_gatillo();
        for (sx = [-1, 1], sy = [-1, 1])
            translate([sx * (pg_largo / 2 - pp_inset), sy * (pg_ancho / 2 - pp_inset), 0])
                cylinder(d = poste_d, h = z_pg_inf);
    }
}

module guias_cable() {
    for (gx = [guia1_x, guia2_x], k = [0, 1])
        translate([gx, guia_y + k * (guia_canal + 1.2), 0])
            cube([guia_largo, 1.2, pared + guia_alto]);
}

// Flechas en relieve junto al MPU: ejes X+ (adelante) e Y+ (izquierda)
module marcas_orientacion() {
    translate([0, 0, pared - 0.01]) linear_extrude(marca_alto + 0.01) {
        translate([mpu_x + mpu_largo / 2 + 3, 0]) flecha2d(12, 1.6);
        translate([mpu_x + mpu_largo / 2 + 3, -6])
            text("X+", size = 3.5, halign = "left", valign = "center");
        translate([mpu_x - mpu_largo / 2 - 5, -5]) rotate(90) flecha2d(12, 1.6);
        translate([mpu_x - mpu_largo / 2 - 9, -4]) rotate(90)
            text("Y+", size = 3.5, halign = "left", valign = "center");
    }
}

module vaciados_base() {
    // Tornillos de cierre: pasante + avellanado 90° por debajo
    for (t = torres)
        translate([t[0], t[1], 0]) {
            translate([0, 0, -1]) cylinder(d = tornillo_paso, h = z_torre_base(t[0]) + 2);
            translate([0, 0, -0.01])
                cylinder(d1 = avellanado_d, d2 = tornillo_paso, h = (avellanado_d - tornillo_paso) / 2);
            translate([0, 0, -2]) cylinder(d = avellanado_d, h = 2);
        }
    // Pilotos del MPU (no atraviesan el piso)
    translate([mpu_x, 0, 0]) rotate([0, 0, mpu_rot])
        for (sx = [-1, 1])
            translate([sx * mpu_sep_agujeros / 2, mpu_ancho / 2 - mpu_agujero_borde, pared + 0.6])
                cylinder(d = mpu_piloto, h = mpu_poste_alto + 1);
    // Agujero del gatillo
    translate([x_gatillo, 0, -1])
        linear_extrude(pared + manga_alto + 2) offset(r = holgura_boton) forma_gatillo();
    // Pilotos M2 de la placa del gatillo
    for (sx = [-1, 1], sy = [-1, 1])
        translate([x_gatillo + sx * (pg_largo / 2 - pp_inset), sy * (pg_ancho / 2 - pp_inset), z_pg_inf - 6])
            cylinder(d = m2_piloto, h = 7);
    ventana_interruptor();
}

// Ranuras de la cara trasera (se restan de base y tapa)
module ranura_trasera(yc, zc, w, h) {
    translate([-2, yc, zc]) rotate([0, 90, 0])
        linear_extrude(pared + 2.8) rect_redondeado(h, w, 1.5);
}

module vaciados_comunes() {
    ranura_trasera(0, z_usb_esp, usb_esp_ancho, usb_esp_alto);          // programación ESP32
    ranura_trasera(tp_y, z_usb_tp, ranura_tp_ancho, ranura_tp_alto);    // carga TP4056
}

// =====================================================================
// TAPA (media carcasa superior) — en coordenadas de ensamble
// =====================================================================
module tapa() {
    difference() {
        union() {
            difference() {
                intersection() { cuerpo(0); caja_z(alto_base, alto + 1); }
                cuerpo(-pared);
                // rebaje donde entra el labio de la base
                intersection() {
                    cuerpo(-pared / 2 + labio_holgura / 2);
                    caja_z(alto_base - 1, alto_base + labio_alto + labio_holgura);
                }
            }
            intersection() { cuerpo(0); elementos_tapa(); }
        }
        vaciados_tapa();
        vaciados_comunes();
    }
}

module elementos_tapa() {
    // Torres (reciben el tornillo; las traseras aprisionan la bandeja)
    for (t = torres)
        translate([t[0], t[1], z_torre_tapa(t[0])])
            cylinder(d = torre_d, h = alto - z_torre_tapa(t[0]) - 0.3);
    // Guías de los capuchones del pulgar
    for (b = botones_pulgar)
        translate([b[0], 0, z_techo - manga_alto])
            linear_extrude(manga_alto + 1) offset(r = holgura_boton + manga_pared) forma_triangulo(b[1]);
    // Postes de la placa perforada del pulgar
    for (sx = [-1, 1], sy = [-1, 1])
        translate([x_pp + sx * (pp_largo / 2 - pp_inset), sy * (pp_ancho / 2 - pp_inset), z_pp_sup])
            cylinder(d = poste_d, h = alto - z_pp_sup - 0.3);
    // Nervios que sujetan la batería (con espuma)
    for (nx = [nervio_x1, nervio_x2])
        translate([nx - nervio_esp / 2, -nervio_largo / 2, z_bat_sup + espuma])
            cube([nervio_esp, nervio_largo, alto - z_bat_sup - espuma - 0.3]);
    // Tubo del LED
    translate([led_x, led_y, z_techo - led_manga])
        cylinder(d = led_d + 2.4, h = led_manga + 1);
}

module vaciados_tapa() {
    // Agujeros de los tornillos
    for (t = torres)
        translate([t[0], t[1], z_torre_tapa(t[0]) - 0.01]) {
            if (tipo_fijacion == "inserto") {
                cylinder(d = inserto_d, h = inserto_prof);
                cylinder(d = tornillo_paso - 0.2, h = prof_tornillo_tapa);
            } else {
                cylinder(d = tornillo_piloto, h = prof_tornillo_tapa);
            }
        }
    // Agujeros de los botones del pulgar
    for (b = botones_pulgar)
        translate([b[0], 0, z_techo - manga_alto - 1])
            linear_extrude(alto) offset(r = holgura_boton) forma_triangulo(b[1]);
    // Pilotos M2 de la placa del pulgar
    for (sx = [-1, 1], sy = [-1, 1])
        translate([x_pp + sx * (pp_largo / 2 - pp_inset), sy * (pp_ancho / 2 - pp_inset), z_pp_sup - 0.01])
            cylinder(d = m2_piloto, h = 6);
    // LED
    translate([led_x, led_y, z_techo - led_manga - 1]) cylinder(d = led_d + 0.2, h = alto);
}

// =====================================================================
// BANDEJA SEPARADORA (coordenadas locales: cara inferior en z = 0)
// =====================================================================
module bandeja() {
    difference() {
        union() {
            linear_extrude(bandeja_esp) contorno_bandeja();
            // esquinas de ubicación de las placas y de la batería
            intersection() {
                translate([0, 0, bandeja_esp - 0.01]) linear_extrude(borde_alto + 0.01) contorno_bandeja();
                translate([0, 0, bandeja_esp - 0.01]) {
                    esquinas_bajas(tp_x0, tp_y, tp_largo + holgura, tp_ancho + holgura, false); // atrás: la pared
                    esquinas_bajas(mt_x0, mt_y, mt_largo + holgura, mt_ancho + holgura, true);
                    esquinas_bajas(bat_x0, 0, bat_largo + holgura, bat_ancho + holgura, true);
                }
            }
        }
        // agujeros de los pasadores de los postes
        for (p = postes_bandeja)
            translate([p[0], p[1], -1]) cylinder(d = pin_d + 0.6, h = bandeja_esp + 2);
        // tornillos traseros (la bandeja queda aprisionada entre torres)
        for (t = torres)
            if (t[0] < bandeja_x_fin)
                translate([t[0], t[1], -1]) cylinder(d = tornillo_paso, h = bandeja_esp + 2);
        // ventana de paso de cables
        translate([pase_x, 0, -1]) linear_extrude(bandeja_esp + 2) rect_redondeado(pase_largo, pase_ancho, 2);
    }
}

module contorno_bandeja() {
    intersection() {
        planta(-pared - bandeja_holgura);
        translate([-10, -100]) square([bandeja_x_fin + 10, 200]);
    }
}

// 4 esquinas en L bajas alrededor de un rectángulo (x0 = borde trasero, yc = centro Y)
module esquinas_bajas(x0, yc, lx, ly, traseras = true) {
    for (cx = [0, 1], cy = [0, 1])
        if (cx == 1 || traseras)
            translate([x0 + cx * lx, yc + (cy == 0 ? -ly / 2 : ly / 2), 0])
                scale([cx == 0 ? 1 : -1, cy == 0 ? 1 : -1, 1]) {
                    translate([-1.2, -1.2, 0]) cube([6, 1.2, borde_alto]);
                    translate([-1.2, -1.2, 0]) cube([1.2, 6, borde_alto]);
                }
}

// =====================================================================
// CAPUCHONES (coordenadas locales: pestaña abajo en z = 0, así se imprimen)
// =====================================================================
module capuchon(tipo) {
    largo_vast = (tipo == "gatillo") ? pared + manga_alto + gat_saliente
                                     : manga_alto + pared + cabeza_saliente;
    ch = 0.6; // chaflán superior
    // pestaña de retención (no deja que el capuchón salga por el agujero)
    linear_extrude(pestana_esp) offset(r = pestana_ancho) forma_capuchon(tipo);
    // vástago + cabeza
    translate([0, 0, pestana_esp - 0.01])
        linear_extrude(largo_vast - ch + 0.01) forma_capuchon(tipo);
    // chaflán
    translate([0, 0, pestana_esp + largo_vast - ch])
        hull() {
            linear_extrude(0.01) forma_capuchon(tipo);
            translate([0, 0, ch - 0.01]) linear_extrude(0.01) offset(delta = -ch) forma_capuchon(tipo);
        }
    // relieve táctil: punto en ADELANTE, dos nervios en AGARRE, ATRÁS liso
    translate([0, 0, pestana_esp + largo_vast - 0.01]) {
        if (tipo == "adelante") cylinder(d = 2.4, h = 0.6);
        if (tipo == "gatillo")
            for (s = [-1, 1]) translate([s * 2.5 - 0.5, -gat_ancho / 2 + 3, 0]) cube([1, gat_ancho - 6, 0.6]);
    }
}

module botones_cama() {
    translate([0, 0, 0]) capuchon("adelante");
    translate([0, 22, 0]) capuchon("atras");
    translate([22, 11, 0]) capuchon("gatillo");
}

// =====================================================================
// COMPONENTES FANTASMA (solo para "ensamble")
// =====================================================================
module interruptor_tactil() {   // base del cuerpo en z = 0, vástago hacia +Z
    color("Black") translate([-boton_tam / 2, -boton_tam / 2, 0]) cube([boton_tam, boton_tam, boton_cuerpo_alto]);
    color("DimGray") cylinder(d = boton_tam / 3, h = boton_alto);
}

module componentes_base() {
    // ESP32
    translate([esp_x0 + holgura / 2, -esp_ancho / 2, esp_z]) {
        color("DarkGreen", 0.9) cube([esp_largo, esp_ancho, esp_pcb]);
        color("Silver") translate([esp_largo - 25.5, (esp_ancho - 18) / 2, esp_pcb]) cube([25.5, 18, 3.2]);
        color("Silver") translate([-0.6, esp_ancho / 2 - 4, esp_pcb]) cube([5.5, 8, 2.8]);
        color("Black") for (py = [1.3 - 1.25, esp_ancho - 1.3 - 1.25])
            translate([(esp_largo - 48.3) / 2, py, -8.5]) cube([48.3, 2.5, 8.5]);
    }
    // MPU6050 con flecha de orientación
    translate([mpu_x, 0, pared + mpu_poste_alto]) rotate([0, 0, mpu_rot]) {
        color("RoyalBlue") difference() {
            translate([-mpu_largo / 2, -mpu_ancho / 2, 0]) cube([mpu_largo, mpu_ancho, 1.6]);
            for (sx = [-1, 1])
                translate([sx * mpu_sep_agujeros / 2, mpu_ancho / 2 - mpu_agujero_borde, -1]) cylinder(d = 3, h = 4);
        }
        color("Black") translate([-2, -2, 1.6]) cube([4, 4, 0.9]);
        color("Red") translate([0, 0, 2.5]) linear_extrude(0.4) {
            translate([-6, 0]) flecha2d(12, 1.2);
            rotate(90) translate([-2, 0]) flecha2d(8, 1.0);
        }
    }
    // Motor vibrador
    color("DimGray") translate([motor_x, lado_palma * (y_pared_int(motor_x) - motor_esp / 2), motor_z])
        rotate([90, 0, 0]) cylinder(d = motor_d, h = motor_esp, center = true);
    // Interruptor deslizante
    color("Black") translate([int_x, lado_interruptor * (y_pared_int(int_x) - 1.75), int_z])
        cube([int_largo, 3.5, int_ancho], center = true);
    color("White") translate([int_x, lado_interruptor * (y_pared_int(int_x) + 0.9), int_z])
        cube([1.5, 3.5, 1.5], center = true);
    // Gatillo: placa perforada + pulsador boca abajo
    color("Tan") translate([x_gatillo - pg_largo / 2, -pg_ancho / 2, z_pg_inf]) cube([pg_largo, pg_ancho, pg_esp]);
    translate([x_gatillo, 0, z_pg_inf]) mirror([0, 0, 1]) interruptor_tactil();
}

module componentes_bandeja() {   // coordenadas de ensamble
    color("Silver", 0.9) translate([bat_x0 + holgura / 2, -bat_ancho / 2, bandeja_z1]) cube([bat_largo, bat_ancho, bat_alto]);
    color("MediumBlue") translate([tp_x0, tp_y - tp_ancho / 2, tp_z]) cube([tp_largo, tp_ancho, 1.6]);
    color("Silver") translate([tp_x0 - 0.6, tp_y - 4.5, tp_z + 1.6]) cube([7.5, 9, tp_usb_alto]);
    color("Blue") translate([mt_x0, mt_y - mt_ancho / 2, bandeja_z1 + cinta]) cube([mt_largo, mt_ancho, 1.6]);
    color("Orange") translate([mt_x0 + 4, mt_y - 3, bandeja_z1 + cinta + 1.6]) cube([6, 6, mt_alto - 1.6]);
}

module componentes_tapa() {
    color("Tan") translate([x_pp - pp_largo / 2, -pp_ancho / 2, z_pp_sup - pp_esp]) cube([pp_largo, pp_ancho, pp_esp]);
    for (b = botones_pulgar) translate([b[0], 0, z_pp_sup]) interruptor_tactil();
    color("Red") translate([led_x, led_y, z_techo - led_manga - 1]) cylinder(d = led_d, h = led_manga + 2);
}

module ensamble() {
    color("SteelBlue") base();
    componentes_base();
    color("OrangeRed") translate([x_gatillo, 0, z_pestana_gat - explosion * 0.4])
        rotate([180, 0, 0]) capuchon("gatillo");
    translate([0, 0, explosion * 0.5]) {
        color("Khaki") translate([0, 0, bandeja_z0]) bandeja();
        componentes_bandeja();
    }
    translate([0, 0, explosion * 1.4]) {
        color("LightSteelBlue", 0.45) tapa();
        componentes_tapa();
        color("OrangeRed") for (b = botones_pulgar)
            translate([b[0], 0, z_pestana_pulgar + explosion * 0.4])
                capuchon(b[1] > 0 ? "adelante" : "atras");
    }
}

// =====================================================================
// PIEZAS PARA IMPRIMIR
// =====================================================================
module tapa_para_imprimir() {       // cara exterior sobre la cama
    translate([0, 0, alto]) rotate([180, 0, 0]) tapa();
}

module todo() {
    base();
    translate([0, ancho_max + 10, 0]) tapa_para_imprimir();
    translate([0, -(ancho_max + 10), 0]) bandeja();
    translate([largo + 15, -18, 0]) botones_cama();
}

// =====================================================================
// SELECCIÓN
// =====================================================================
if (pieza == "base") base();
else if (pieza == "tapa") tapa_para_imprimir();
else if (pieza == "bandeja") bandeja();
else if (pieza == "botones") botones_cama();
else if (pieza == "ensamble") ensamble();
else todo();

// =====================================================================
// VERIFICACIONES (ver consola)
// =====================================================================
echo(str("Dimensiones exteriores: ", largo, " x ", ancho_max, " x ", alto, " mm (sin capuchones)"));
echo(str("Capuchones: pulgar +", cabeza_saliente, " mm arriba, gatillo +", gat_saliente, " mm abajo"));
echo(str("Espacio libre entre placa del gatillo y placa del pulgar: ", hueco_placas, " mm"));
if (hueco_placas < 1) echo("ADVERTENCIA: las placas de botones chocan; aumente 'alto' o use pulsadores 6x6.");
if (bandeja_z0 < esp_tope + 0.3) echo("ADVERTENCIA: la bandeja toca el ESP32.");
if (z_bat_sup + espuma > z_techo - 1) echo("ADVERTENCIA: la batería no cabe bajo la tapa.");
echo(str("Tornillo M3 x ", tornillo_largo, ": entra ", tornillo_largo - bandeja_z1, " mm en torres traseras y ",
         tornillo_largo - alto_base, " mm en delanteras (agujero de ", prof_tornillo_tapa, " mm)"));
