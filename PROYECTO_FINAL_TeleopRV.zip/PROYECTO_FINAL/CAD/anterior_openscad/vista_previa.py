# -*- coding: utf-8 -*-
"""
Plano esquemático acotado de la carcasa del control háptico.

Lee los parámetros directamente de carcasa_control.scad (todo lo que está antes
de la línea "=== FIN DE PARÁMETROS ===") para que el plano use EXACTAMENTE los
mismos valores que el modelo 3D. Genera CAD/plano_carcasa.png con:
  - Vista superior, nivel inferior (piso de la base)
  - Vista superior, nivel superior (bandeja y tapa)
  - Corte longitudinal esquemático (lateral)
  - Vista trasera (ranuras de carga y programación)

Uso:  python vista_previa.py
"""
import math
import os
import re

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Polygon, Circle, FancyBboxPatch

AQUI = os.path.dirname(os.path.abspath(__file__))
SCAD = os.path.join(AQUI, "carcasa_control.scad")
SALIDA = os.path.join(AQUI, "plano_carcasa.png")


# ---------------------------------------------------------------------------
# Lectura de parámetros
# ---------------------------------------------------------------------------
def cargar_parametros(ruta):
    txt = open(ruta, encoding="utf-8").read()
    txt = txt.split("=== FIN DE PARÁMETROS ===")[0]
    txt = re.sub(r"/\*.*?\*/", "", txt, flags=re.S)
    P = {}
    entorno = {"__builtins__": {}, "max": max, "min": min, "abs": abs}
    for linea in txt.splitlines():
        linea = linea.split("//")[0].strip()
        m = re.match(r"^([A-Za-z_]\w*)\s*=\s*(.+);$", linea)
        if not m:
            continue
        nombre, expr = m.groups()
        expr = re.sub(r"\btrue\b", "True", expr)
        expr = re.sub(r"\bfalse\b", "False", expr)
        try:
            P[nombre] = eval(expr, entorno, P)
        except Exception as e:  # pragma: no cover
            print("No se pudo evaluar", nombre, "=", expr, "->", e)
    return P


P = cargar_parametros(SCAD)
L, H, t, r, hol = P["largo"], P["alto"], P["pared"], P["radio_borde"], P["holgura"]
EST = P["estaciones"]


def ancho_en(x):
    if x <= EST[0][0]:
        return EST[0][1]
    for (x0, w0), (x1, w1) in zip(EST[:-1], EST[1:]):
        if x <= x1:
            return w0 + (w1 - w0) * (x - x0) / (x1 - x0)
    return EST[-1][1]


def y_pared_int(x):
    return ancho_en(x) / 2 - t


def z_torre_base(x):
    return P["bandeja_z0"] if x < P["bandeja_x_fin"] else P["alto_base"]


def z_torre_tapa(x):
    return P["bandeja_z1"] if x < P["bandeja_x_fin"] else P["alto_base"]


# ---------------------------------------------------------------------------
# Geometría 2D
# ---------------------------------------------------------------------------
def contorno_planta(d=0.0, n=24):
    """Contorno en planta de la unión de envolventes de esferas, desfasado d."""
    rr = r + d
    x0, x1 = EST[0][0], EST[-1][0]
    w0, w1 = EST[0][1], EST[-1][1]
    pts = []
    xs = [x0 + (x1 - x0) * i / 200.0 for i in range(201)]
    for x in xs:  # borde +Y
        pts.append((x, ancho_en(x) / 2 - r + rr))
    c = (x1, w1 / 2 - r)
    for i in range(n + 1):  # esquina delantera +Y
        a = math.radians(90 - 90 * i / n)
        pts.append((c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)))
    c = (x1, -(w1 / 2 - r))
    for i in range(n + 1):
        a = math.radians(0 - 90 * i / n)
        pts.append((c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)))
    for x in reversed(xs):  # borde -Y
        pts.append((x, -(ancho_en(x) / 2 - r + rr)))
    c = (x0, -(w0 / 2 - r))
    for i in range(n + 1):
        a = math.radians(270 - 90 * i / n)
        pts.append((c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)))
    c = (x0, w0 / 2 - r)
    for i in range(n + 1):
        a = math.radians(180 - 90 * i / n)
        pts.append((c[0] + rr * math.cos(a), c[1] + rr * math.sin(a)))
    return pts


def rect_redondeado_pts(x0, y0, x1, y1, rad, n=10):
    rad = min(rad, (x1 - x0) / 2, (y1 - y0) / 2)
    pts = []
    for cx, cy, a0 in ((x1 - rad, y1 - rad, 0), (x0 + rad, y1 - rad, 90),
                       (x0 + rad, y0 + rad, 180), (x1 - rad, y0 + rad, 270)):
        for i in range(n + 1):
            a = math.radians(a0 + 90 * i / n)
            pts.append((cx + rad * math.cos(a), cy + rad * math.sin(a)))
    return pts


def triangulo(cx, cy, R, direccion):
    ang = [0, 120, 240] if direccion > 0 else [180, 300, 60]
    return [(cx + R * math.cos(math.radians(a)), cy + R * math.sin(math.radians(a))) for a in ang]


# ---------------------------------------------------------------------------
# Ayudas de dibujo
# ---------------------------------------------------------------------------
COL = {
    "cuerpo": "#1f2d3d", "pared": "#8a99a8", "esp": "#2e8b57", "mpu": "#1f5fbf",
    "motor": "#555555", "int": "#111111", "gat": "#e0531f", "band": "#e6d38a",
    "bat": "#b8bec6", "placa": "#3d5ccf", "boton": "#e0531f", "perf": "#c9a66b",
    "torre": "#7b4fa0", "poste": "#9c7a3c", "led": "#d62728", "usb": "#d62728",
}
FS = 8.5  # tamaño de letra base


def rect(ax, x0, y0, x1, y1, fc, ec="k", lw=0.8, ls="-", alpha=0.55, z=2, hatch=None):
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, facecolor=fc, edgecolor=ec,
                           lw=lw, ls=ls, alpha=alpha, zorder=z, hatch=hatch))


def poly(ax, pts, fc, ec="k", lw=0.8, ls="-", alpha=0.55, z=2, fill=True):
    ax.add_patch(Polygon(pts, closed=True, facecolor=fc if fill else "none", edgecolor=ec,
                         lw=lw, ls=ls, alpha=alpha, zorder=z, fill=fill))


def circ(ax, x, y, d, fc, ec="k", lw=0.7, ls="-", alpha=0.7, z=3):
    ax.add_patch(Circle((x, y), d / 2, facecolor=fc, edgecolor=ec, lw=lw, ls=ls, alpha=alpha, zorder=z))


def globo(ax, n, objetivo, pos):
    """Número en círculo con línea guía hacia el objetivo."""
    ax.annotate("", xy=objetivo, xytext=pos,
                arrowprops=dict(arrowstyle="-", lw=0.6, color="#333333", shrinkA=6, shrinkB=0),
                zorder=8)
    ax.plot([objetivo[0]], [objetivo[1]], marker="o", ms=2.2, color="#333333", zorder=9)
    ax.text(pos[0], pos[1], str(n), ha="center", va="center", fontsize=FS - 0.5, fontweight="bold",
            zorder=10, bbox=dict(boxstyle="circle,pad=0.25", fc="white", ec="#333333", lw=0.8))


def cota_h(ax, x0, x1, y, texto, y_ref=None, col="#b03030"):
    """Cota horizontal entre x0 y x1 a la altura y. y_ref: de dónde salen las líneas de referencia."""
    ax.annotate("", xy=(x0, y), xytext=(x1, y),
                arrowprops=dict(arrowstyle="<|-|>", lw=0.7, color=col, mutation_scale=7,
                                shrinkA=0, shrinkB=0), zorder=6)
    if y_ref is not None:
        for x in (x0, x1):
            ax.plot([x, x], [y_ref, y + (1.2 if y > y_ref else -1.2)], lw=0.45, color=col, zorder=5)
    ax.text((x0 + x1) / 2, y, texto, ha="center", va="center", fontsize=FS - 0.5, color=col, zorder=7,
            bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))


def cota_v(ax, x, y0, y1, texto, x_ref=None, col="#b03030", rot=90):
    ax.annotate("", xy=(x, y0), xytext=(x, y1),
                arrowprops=dict(arrowstyle="<|-|>", lw=0.7, color=col, mutation_scale=7,
                                shrinkA=0, shrinkB=0), zorder=6)
    if x_ref is not None:
        for y in (y0, y1):
            ax.plot([x_ref, x + (1.2 if x > x_ref else -1.2)], [y, y], lw=0.45, color=col, zorder=5)
    ax.text(x, (y0 + y1) / 2, texto, ha="center", va="center", fontsize=FS - 0.5, color=col, rotation=rot,
            zorder=7, bbox=dict(boxstyle="round,pad=0.15", fc="white", ec="none"))


def preparar(ax, titulo, xlim, ylim, ylabel):
    ax.set_xlim(*xlim)
    ax.set_ylim(*ylim)
    ax.set_aspect("equal")
    ax.set_title(titulo, fontsize=FS + 2, fontweight="bold", loc="left")
    ax.tick_params(labelsize=FS - 1)
    ax.set_ylabel(ylabel, fontsize=FS)
    ax.grid(True, lw=0.3, alpha=0.35)


def dibujar_carcasa_planta(ax):
    poly(ax, contorno_planta(0), "#f4f6f8", ec=COL["cuerpo"], lw=1.5, alpha=1, z=1)
    poly(ax, contorno_planta(-t), "none", ec=COL["pared"], lw=0.7, ls="--", alpha=1, z=1.5, fill=False)


# ---------------------------------------------------------------------------
# Posiciones derivadas (idénticas al .scad)
# ---------------------------------------------------------------------------
esp_x0 = P["esp_x0"]
esp_x1 = esp_x0 + P["esp_largo"] + hol
esp_y = (P["esp_ancho"] + hol) / 2
mpu_x = P["mpu_x"]
mpu_hl, mpu_hw = (P["mpu_largo"] + hol) / 2, (P["mpu_ancho"] + hol) / 2
tp_x0, tp_x1 = P["tp_x0"], P["tp_x0"] + P["tp_largo"] + hol
tp_y0, tp_y1 = P["tp_y"] - (P["tp_ancho"] + hol) / 2, P["tp_y"] + (P["tp_ancho"] + hol) / 2
mt_x0, mt_x1 = P["mt_x0"], P["mt_x0"] + P["mt_largo"] + hol
mt_y0, mt_y1 = P["mt_y"] - (P["mt_ancho"] + hol) / 2, P["mt_y"] + (P["mt_ancho"] + hol) / 2
bat_x0, bat_x1 = P["bat_x0"], P["bat_x0"] + P["bat_largo"] + hol
bat_hw = (P["bat_ancho"] + hol) / 2
xg, xa, xd = P["x_gatillo"], P["x_atras"], P["x_adelante"]
x_pp = P["x_pp"]
ins = P["pp_inset"]
postes_pp = [(x_pp + sx * (P["pp_largo"] / 2 - ins), sy * (P["pp_ancho"] / 2 - ins)) for sx in (-1, 1) for sy in (-1, 1)]
postes_pg = [(xg + sx * (P["pg_largo"] / 2 - ins), sy * (P["pg_ancho"] / 2 - ins)) for sx in (-1, 1) for sy in (-1, 1)]
motor_ext = P["motor_d"] + hol + 2 * P["motor_anillo"]
motor_yw = y_pared_int(P["motor_x"])
int_yw = y_pared_int(P["int_x"])
lp, li = P["lado_palma"], P["lado_interruptor"]

# ---------------------------------------------------------------------------
# Figura
# ---------------------------------------------------------------------------
fig = plt.figure(figsize=(15, 19.5))
gs = fig.add_gridspec(4, 2, height_ratios=[1.0, 1.0, 0.78, 0.40], width_ratios=[3.6, 1.15],
                      hspace=0.13, wspace=0.08, left=0.05, right=0.985, top=0.935, bottom=0.015)
fig.suptitle("Carcasa del control háptico — plano esquemático (cotas en mm)",
             fontsize=15, fontweight="bold", y=0.985)
fig.text(0.5, 0.958, "Generado desde carcasa_control.scad · X = eje largo (hacia la punta) · "
         "Y = eje corto (+Y a la izquierda del usuario) · Z = arriba",
         ha="center", fontsize=FS + 1, color="#444444")

XL = (-24, L + 24)

# ======================= VISTA 1: NIVEL INFERIOR ===========================
ax = fig.add_subplot(gs[0, :])
preparar(ax, "A. Vista superior — nivel inferior (piso de la base, sin bandeja ni tapa)", XL, (-52, 52), "Y [mm]")
dibujar_carcasa_planta(ax)
# ESP32 y esquineros
rect(ax, esp_x0, -esp_y, esp_x1, esp_y, COL["esp"], alpha=0.35)
ax.text((esp_x0 + esp_x1) / 2, 2.5, "ESP32 DevKit V1\n55 × 28 (pines abajo)", ha="center", va="center",
        fontsize=FS, color="#0d3d22", zorder=7)
for cx in (esp_x0, esp_x1):
    for cy in (-esp_y, esp_y):
        sx = 1 if cx == esp_x0 else -1
        sy = 1 if cy == -esp_y else -1
        rect(ax, min(cx, cx + sx * 3), min(cy, cy + sy * 3.5), max(cx, cx + sx * 3), max(cy, cy + sy * 3.5),
             "#6b8e23", alpha=0.8, lw=0.4, z=3)
# ranura USB del ESP32
rect(ax, -0.8, -P["usb_esp_ancho"] / 2, t + 0.4, P["usb_esp_ancho"] / 2, COL["usb"], ec=COL["usb"], alpha=0.9, z=4)
# MPU
rect(ax, mpu_x - mpu_hl, -mpu_hw, mpu_x + mpu_hl, mpu_hw, COL["mpu"], alpha=0.45, z=3)
for sx in (-1, 1):
    circ(ax, mpu_x + sx * P["mpu_sep_agujeros"] / 2, P["mpu_ancho"] / 2 - P["mpu_agujero_borde"], P["poste_d"],
         "#ffffff", alpha=0.9, z=4)
    circ(ax, mpu_x + sx * P["mpu_sep_agujeros"] / 2, -P["mpu_ancho"] / 2 + 5, 3, "#cccccc", alpha=0.9, z=4)
ax.annotate("", xy=(mpu_x + 12.5, 0), xytext=(mpu_x - 1, 0),
            arrowprops=dict(arrowstyle="-|>", lw=1.6, color="#d62728", mutation_scale=11), zorder=9)
ax.annotate("", xy=(mpu_x - 1, 11.5), xytext=(mpu_x - 1, -1),
            arrowprops=dict(arrowstyle="-|>", lw=1.6, color="#2ca02c", mutation_scale=11), zorder=9)
ax.text(mpu_x + 13.5, -3.2, "X+", color="#d62728", fontsize=FS, fontweight="bold", zorder=9)
ax.text(mpu_x - 6.5, 9.5, "Y+", color="#2ca02c", fontsize=FS, fontweight="bold", zorder=9)
# motor (anillo pegado a la pared del lado de la palma)
yin = lp * motor_yw
rect(ax, P["motor_x"] - motor_ext / 2, min(yin, yin - lp * (P["motor_esp"] + 0.4)),
     P["motor_x"] + motor_ext / 2, max(yin, yin - lp * (P["motor_esp"] + 0.4)), COL["motor"], alpha=0.8, z=4)
# interruptor
yi = li * int_yw
rect(ax, P["int_x"] - P["int_largo"] / 2, min(yi, yi - li * 3.5), P["int_x"] + P["int_largo"] / 2,
     max(yi, yi - li * 3.5), COL["int"], alpha=0.85, z=4)
rect(ax, P["int_x"] - P["int_ventana_largo"] / 2, min(yi, yi + li * t), P["int_x"] + P["int_ventana_largo"] / 2,
     max(yi, yi + li * t), "white", ec=COL["int"], alpha=1, z=4)
# gatillo (en la cara inferior) y su placa
rect(ax, xg - P["pg_largo"] / 2, -P["pg_ancho"] / 2, xg + P["pg_largo"] / 2, P["pg_ancho"] / 2, COL["perf"],
     ls="--", alpha=0.35, z=2)
poly(ax, rect_redondeado_pts(xg - P["gat_largo"] / 2, -P["gat_ancho"] / 2, xg + P["gat_largo"] / 2,
                             P["gat_ancho"] / 2, P["gat_redondeo"]), COL["gat"], alpha=0.75, z=3)
for (px, py) in postes_pg:
    circ(ax, px, py, P["poste_d"], COL["poste"], alpha=0.7)
# torres y postes de la bandeja
for (tx, ty) in P["torres"]:
    circ(ax, tx, ty, P["torre_d"], COL["torre"], alpha=0.75, z=4)
    circ(ax, tx, ty, P["tornillo_paso"], "white", alpha=1, z=5)
for (px, py) in P["postes_bandeja"]:
    circ(ax, px, py, P["poste_d"], COL["poste"], alpha=0.7)
# guías de cables
for gx in (P["guia1_x"], P["guia2_x"]):
    for k in (0, 1):
        y0 = P["guia_y"] + k * (P["guia_canal"] + 1.2)
        rect(ax, gx, y0, gx + P["guia_largo"], y0 + 1.2, "#444444", alpha=0.8, lw=0.3, z=3)
# globos
globo(ax, 1, (esp_x0 + 12, -6), (12, -33))
globo(ax, 2, (0.5, -3), (-10, -33))
globo(ax, 3, (mpu_x + 4, -5), (70, -33))
globo(ax, 4, (P["motor_x"], yin - lp * 1.7), (P["motor_x"], -33))
globo(ax, 5, (P["int_x"], yi - li * 1.5), (P["int_x"], 33))
globo(ax, 6, (xg, -P["gat_ancho"] / 2 + 2), (xg, -33))
globo(ax, 7, (P["torres"][2][0], P["torres"][2][1]), (152, 33))
globo(ax, 8, (P["postes_bandeja"][4][0], P["postes_bandeja"][4][1]), (84, 33))
globo(ax, 9, (P["guia1_x"] + 5, P["guia_y"] + 3), (62, 33))
globo(ax, 20, (postes_pg[1][0], postes_pg[1][1]), (116, 33))
# cotas
cota_h(ax, 0, L, -45, "largo total = %g" % L, y_ref=-ancho_en(80) / 2)
cota_h(ax, 0, mpu_x, 44, "%g (centro del MPU = centro del control)" % mpu_x, y_ref=mpu_hw)
cota_v(ax, -16, -P["ancho_trasero"] / 2, P["ancho_trasero"] / 2, "%g" % P["ancho_trasero"], x_ref=5)
cota_v(ax, L + 12, -P["ancho_cabeza"] / 2, P["ancho_cabeza"] / 2, "%g" % P["ancho_cabeza"], x_ref=L - 5)
ax.text(L + 3, -49, "PUNTA →", fontsize=FS, ha="right", color="#333333")

# ======================= VISTA 2: NIVEL SUPERIOR ===========================
ax = fig.add_subplot(gs[1, :])
preparar(ax, "B. Vista superior — nivel superior (bandeja separadora y elementos de la tapa)", XL, (-52, 52),
         "Y [mm]")
dibujar_carcasa_planta(ax)
# bandeja
bx = [(x, y) for (x, y) in contorno_planta(-t - P["bandeja_holgura"]) if x <= P["bandeja_x_fin"]]
bx = [(P["bandeja_x_fin"], bx[0][1])] + bx + [(P["bandeja_x_fin"], bx[-1][1])]
poly(ax, bx, COL["band"], alpha=0.6, z=1.8)
rect(ax, P["pase_x"] - P["pase_largo"] / 2, -P["pase_ancho"] / 2, P["pase_x"] + P["pase_largo"] / 2,
     P["pase_ancho"] / 2, "white", alpha=1, z=2)
# TP4056, MT3608, batería
rect(ax, tp_x0, tp_y0, tp_x1, tp_y1, COL["placa"], alpha=0.5, z=3)
ax.text((tp_x0 + tp_x1) / 2, P["tp_y"], "TP4056\nUSB-C", ha="center", va="center", fontsize=FS - 1, zorder=7)
rect(ax, mt_x0, mt_y0, mt_x1, mt_y1, COL["placa"], alpha=0.35, z=3)
ax.text((mt_x0 + mt_x1) / 2, P["mt_y"], "MT3608 (5 V)", ha="center", va="center", fontsize=FS - 1, zorder=7)
rect(ax, bat_x0, -bat_hw, bat_x1, bat_hw, COL["bat"], alpha=0.7, z=3)
ax.text(77, 1, "Batería LiPo\n503450 · 1000 mAh\n50 × 34 × 5.5", ha="center", va="center",
        fontsize=FS, zorder=7)
rect(ax, -0.8, tp_y0 + (P["tp_ancho"] + hol - P["ranura_tp_ancho"]) / 2, t + 0.4,
     tp_y1 - (P["tp_ancho"] + hol - P["ranura_tp_ancho"]) / 2, COL["usb"], ec=COL["usb"], alpha=0.9, z=4)
# nervios de la tapa
for nx in (P["nervio_x1"], P["nervio_x2"]):
    rect(ax, nx - P["nervio_esp"] / 2, -P["nervio_largo"] / 2, nx + P["nervio_esp"] / 2, P["nervio_largo"] / 2,
         "#555555", ls="--", alpha=0.8, lw=0.5, z=5)
# botones del pulgar, placa y postes
rect(ax, x_pp - P["pp_largo"] / 2, -P["pp_ancho"] / 2, x_pp + P["pp_largo"] / 2, P["pp_ancho"] / 2, COL["perf"],
     ls="--", alpha=0.35, z=2)
for (bxx, d) in P["botones_pulgar"]:
    rect(ax, bxx - P["boton_tam"] / 2, -P["boton_tam"] / 2, bxx + P["boton_tam"] / 2, P["boton_tam"] / 2,
         "#222222", alpha=0.25, lw=0.4, z=2.5)
    poly(ax, triangulo(bxx, 0, P["tri_radio"], d), COL["boton"], alpha=0.85, z=4)
for (px, py) in postes_pp:
    circ(ax, px, py, P["poste_d"], COL["poste"], alpha=0.7)
# LED y torres
circ(ax, P["led_x"], P["led_y"], P["led_d"] + 2.4, "#ffffff", alpha=1, z=5)
circ(ax, P["led_x"], P["led_y"], P["led_d"], COL["led"], alpha=1, z=6)
for (tx, ty) in P["torres"]:
    circ(ax, tx, ty, P["torre_d"], COL["torre"], alpha=0.75, z=4)
    circ(ax, tx, ty, P["tornillo_paso"], "white", alpha=1, z=5)
# globos
globo(ax, 12, (0.5, P["tp_y"]), (-12, 33))
globo(ax, 11, (tp_x1 - 3, tp_y1 - 2), (26, 33))
globo(ax, 17, (P["led_x"], P["led_y"] + 1), (46, 33))
globo(ax, 18, (P["nervio_x1"], P["nervio_largo"] / 2 - 1), (64, 33))
globo(ax, 14, (bat_x1 - 8, bat_hw - 3), (92, 33))
globo(ax, 19, (postes_pp[1][0] + 2, P["pp_ancho"] / 2 - 1), (112, 33))
globo(ax, 16, (xd + 3, 0), (140, 33))
globo(ax, 13, ((mt_x0 + mt_x1) / 2, mt_y0 + 2), (24, -33))
globo(ax, 10, (P["pase_x"] + 4.5, -P["pase_ancho"] / 2 - 3), (48, -33))
globo(ax, 15, (xa - 3, 0), (117, -33))
globo(ax, 7, (P["torres"][3][0], P["torres"][3][1]), (152, -33))
# cotas
cota_h(ax, xd, L, 44, "%g" % (L - xd), y_ref=4)
cota_h(ax, xa, xd, 44, "%g" % (xd - xa), y_ref=4)
cota_h(ax, bat_x0, P["bandeja_x_fin"], -45, "batería x = %g … %g · bandeja hasta x = %g"
       % (bat_x0, bat_x1, P["bandeja_x_fin"]), y_ref=-bat_hw)
cota_v(ax, 91, -P["ancho_cintura"] / 2, P["ancho_cintura"] / 2, "cintura %g" % P["ancho_cintura"])
ax.text(L + 3, -49, "PUNTA →", fontsize=FS, ha="right", color="#333333")

# ======================= VISTA 3: CORTE LATERAL ============================
ax = fig.add_subplot(gs[2, 0])
preparar(ax, "C. Corte longitudinal esquemático (Y = 0, visto desde +Y)", (-14, L + 30), (-18, 52), "Z [mm]")
ax.set_xlabel("X [mm]", fontsize=FS)
poly(ax, rect_redondeado_pts(0, 0, L, H, r), "#f4f6f8", ec=COL["cuerpo"], lw=1.5, alpha=1, z=1)
poly(ax, rect_redondeado_pts(t, t, L - t, H - t, r - t), "none", ec=COL["pared"], lw=0.7, ls="--", alpha=1,
     z=1.5, fill=False)
ab = P["alto_base"]
ax.plot([-4, L + 4], [ab, ab], ls="-.", lw=0.9, color="#7b4fa0", zorder=6)
ax.text(-13, ab + 1.0, "unión", fontsize=FS - 1, color="#7b4fa0", ha="left", zorder=7)
# ESP32
ez = P["esp_z"]
rect(ax, esp_x0, ez - 8.5, esp_x1, ez, "#dddddd", alpha=0.6, lw=0.4, z=2, hatch="||||")
rect(ax, esp_x0, ez, esp_x1, ez + P["esp_pcb"], COL["esp"], alpha=0.7, z=3)
rect(ax, esp_x1 - 26, ez + P["esp_pcb"], esp_x1 - 0.5, P["esp_tope"], "#c0c0c0", alpha=0.9, z=3)
rect(ax, esp_x0 - 0.6, ez + P["esp_pcb"], esp_x0 + 5, ez + P["esp_pcb"] + 2.8, "#c0c0c0", alpha=0.9, z=3)
# bandeja + placas + batería
b0, b1 = P["bandeja_z0"], P["bandeja_z1"]
rect(ax, t + 0.5, b0, P["bandeja_x_fin"], b1, COL["band"], alpha=0.9, z=3)
rect(ax, tp_x0, P["tp_z"], tp_x1, P["tp_z"] + 1.6, COL["placa"], alpha=0.7, z=4)
rect(ax, tp_x0 - 0.6, P["tp_z"] + 1.6, tp_x0 + 7, P["tp_z"] + 1.6 + P["tp_usb_alto"], "#c0c0c0", alpha=0.9, z=4)
rect(ax, mt_x0, b1 + P["cinta"], mt_x1, b1 + P["cinta"] + P["mt_alto"], COL["placa"], ls="--", alpha=0.2, z=3)
rect(ax, bat_x0, b1, bat_x1, b1 + P["bat_alto"], COL["bat"], alpha=0.8, z=4)
for nx in (P["nervio_x1"], P["nervio_x2"]):
    rect(ax, nx - P["nervio_esp"] / 2, P["z_bat_sup"] + P["espuma"], nx + P["nervio_esp"] / 2, H - t, "#555555",
         alpha=0.8, lw=0.4, z=4)
# MPU
mz = t + P["mpu_poste_alto"]
rect(ax, mpu_x - mpu_hl, mz, mpu_x + mpu_hl, mz + P["mpu_alto"], COL["mpu"], alpha=0.7, z=4)
for sx in (-1, 1):
    rect(ax, mpu_x + sx * P["mpu_sep_agujeros"] / 2 - 2.5, t, mpu_x + sx * P["mpu_sep_agujeros"] / 2 + 2.5, mz,
         COL["poste"], alpha=0.6, lw=0.4, z=3)
# motor e interruptor (en las paredes laterales, proyectados)
ax.add_patch(Circle((P["motor_x"], P["motor_z"]), P["motor_d"] / 2, fc=COL["motor"], ec="k", ls="--", lw=0.7,
                    alpha=0.35, zorder=3))
rect(ax, P["int_x"] - P["int_largo"] / 2, P["int_z"] - P["int_ancho"] / 2, P["int_x"] + P["int_largo"] / 2,
     P["int_z"] + P["int_ancho"] / 2, COL["int"], ls="--", alpha=0.35, z=3)
# botones del pulgar
zpp = P["z_pp_sup"]
rect(ax, x_pp - P["pp_largo"] / 2, zpp - P["pp_esp"], x_pp + P["pp_largo"] / 2, zpp, COL["perf"], alpha=0.8, z=4)
zc = P["z_pestana_pulgar"]
for (bxx, d) in P["botones_pulgar"]:
    rect(ax, bxx - P["boton_tam"] / 2, zpp, bxx + P["boton_tam"] / 2, zpp + P["boton_cuerpo_alto"], "#222222",
         alpha=0.8, z=4)
    rect(ax, bxx - 2, zpp + P["boton_cuerpo_alto"], bxx + 2, zpp + P["boton_alto"], "#666666", alpha=0.9, z=4)
    xs = [bxx + P["tri_radio"] * math.cos(math.radians(a)) for a in ((0, 120, 240) if d > 0 else (180, 300, 60))]
    x0c, x1c = min(xs), max(xs)
    rect(ax, x0c - P["pestana_ancho"], zc, x1c + P["pestana_ancho"], zc + P["pestana_esp"], COL["boton"], alpha=0.9,
         z=5)
    rect(ax, x0c, zc + P["pestana_esp"], x1c, H + P["cabeza_saliente"], COL["boton"], alpha=0.9, z=5)
    rect(ax, x0c - P["holgura_boton"] - P["manga_pared"], H - t - P["manga_alto"], x0c - P["holgura_boton"], H - t,
         "#8a99a8", alpha=0.9, lw=0.3, z=4)
    rect(ax, x1c + P["holgura_boton"], H - t - P["manga_alto"], x1c + P["holgura_boton"] + P["manga_pared"], H - t,
         "#8a99a8", alpha=0.9, lw=0.3, z=4)
for (px, py) in postes_pp[::2]:
    rect(ax, px - 2.5, zpp, px + 2.5, H - t, COL["poste"], alpha=0.5, lw=0.4, z=3)
# gatillo
zg = P["z_pg_inf"]
rect(ax, xg - P["pg_largo"] / 2, zg, xg + P["pg_largo"] / 2, zg + P["pg_esp"], COL["perf"], alpha=0.8, z=4)
rect(ax, xg - P["boton_tam"] / 2, zg - P["boton_cuerpo_alto"], xg + P["boton_tam"] / 2, zg, "#222222", alpha=0.8, z=4)
rect(ax, xg - 2, zg - P["boton_alto"], xg + 2, zg - P["boton_cuerpo_alto"], "#666666", alpha=0.9, z=4)
zgp = P["z_pestana_gat"]
rect(ax, xg - P["gat_largo"] / 2 - P["pestana_ancho"], zgp - P["pestana_esp"], xg + P["gat_largo"] / 2 +
     P["pestana_ancho"], zgp, COL["gat"], alpha=0.9, z=5)
rect(ax, xg - P["gat_largo"] / 2, -P["gat_saliente"], xg + P["gat_largo"] / 2, zgp - P["pestana_esp"], COL["gat"],
     alpha=0.9, z=5)
for (px, py) in postes_pg[::2]:
    rect(ax, px - 2.5, t, px + 2.5, zg, COL["poste"], alpha=0.5, lw=0.4, z=3)
# torres y tornillos
for tx in (P["torre_x_tras"], P["torre_x_del"]):
    rect(ax, tx - P["torre_d"] / 2, 0.3, tx + P["torre_d"] / 2, z_torre_base(tx), COL["torre"], alpha=0.35, lw=0.5)
    rect(ax, tx - P["torre_d"] / 2, z_torre_tapa(tx), tx + P["torre_d"] / 2, H - 0.3, COL["torre"], alpha=0.35,
         lw=0.5)
    rect(ax, tx - 1.5, 0, tx + 1.5, P["tornillo_largo"], "#333333", ls="--", alpha=0.5, lw=0.5, z=5)
# LED
rect(ax, P["led_x"] - P["led_d"] / 2, H - t - P["led_manga"] - 1, P["led_x"] + P["led_d"] / 2, H + 0.3, COL["led"],
     alpha=0.9, z=5)
# ranuras traseras
for (zc_, h_) in ((P["z_usb_esp"], P["usb_esp_alto"]), (P["z_usb_tp"], P["ranura_tp_alto"])):
    rect(ax, -0.3, zc_ - h_ / 2, t + 0.3, zc_ + h_ / 2, "white", ec=COL["usb"], alpha=1, lw=1.0, z=6)
# globos
globo(ax, 11, (tp_x0 + 12, P["tp_z"] + 1), (18, 46))
globo(ax, 17, (P["led_x"], H), (46, 46))
globo(ax, 18, (P["nervio_x1"], H - 4), (62, 46))
globo(ax, 14, (bat_x0 + 30, b1 + 3), (80, 46))
globo(ax, 10, (P["bandeja_x_fin"] - 4, b0 + 1), (98, 46))
globo(ax, 15, (xa - 2, H + 1), (116, 46))
globo(ax, 16, (xd + 2, H + 1), (136, 46))
globo(ax, 7, (P["torre_x_del"], 30), (154, 46))
globo(ax, 2, (0.8, P["z_usb_esp"]), (-8, -12))
globo(ax, 1, (esp_x0 + 16, ez + 0.8), (14, -12))
globo(ax, 3, (mpu_x - 5, mz + 1.5), (62, -12))
globo(ax, 4, (P["motor_x"], P["motor_z"] - 3), (84, -12))
globo(ax, 19, (x_pp - 12, zpp - 0.8), (104, -12))
globo(ax, 6, (xg + 3, -P["gat_saliente"] + 1), (128, -12))
globo(ax, 20, (xg - P["pg_largo"] / 2 + 2, zg + 0.8), (144, -12))
# cotas
cota_v(ax, L + 9, 0, H, "alto %g" % H, x_ref=L - 3)
cota_v(ax, L + 20, 0, ab, "base %g" % ab, x_ref=L - 3)
cota_v(ax, L + 20, ab, H, "tapa %g" % (H - ab), x_ref=L - 3)

# ======================= VISTA 4: TRASERA ==================================
ax = fig.add_subplot(gs[2, 1])
W = P["ancho_trasero"]
preparar(ax, "D. Vista trasera (pomo)", (-W / 2 - 14, W / 2 + 6), (-18, 52), "")
ax.set_xlabel("← +Y (izq. usuario)      −Y →", fontsize=FS - 0.5)
poly(ax, rect_redondeado_pts(-W / 2, 0, W / 2, H, r), "#f4f6f8", ec=COL["cuerpo"], lw=1.5, alpha=1, z=1)
ax.plot([-W / 2 - 2, W / 2 + 2], [ab, ab], ls="-.", lw=0.9, color="#7b4fa0", zorder=6)


def u(y):  # visto desde atrás: +Y queda a la izquierda
    return -y


for (yc, zc_, w_, h_, txt, dy) in ((0, P["z_usb_esp"], P["usb_esp_ancho"], P["usb_esp_alto"], "2", -11),
                                   (P["tp_y"], P["z_usb_tp"], P["ranura_tp_ancho"], P["ranura_tp_alto"], "12", 17)):
    poly(ax, rect_redondeado_pts(u(yc) - w_ / 2, zc_ - h_ / 2, u(yc) + w_ / 2, zc_ + h_ / 2, 1.5), "white",
         ec=COL["usb"], lw=1.2, alpha=1, z=4)
globo(ax, 2, (u(0) + 3, P["z_usb_esp"] - 2), (8, -11))
globo(ax, 12, (u(P["tp_y"]), P["z_usb_tp"] + 2), (u(P["tp_y"]), 45))
ax.text(u(0), P["z_usb_esp"], "USB\nprog.", ha="center", va="center", fontsize=FS - 2, zorder=6)
ax.text(u(P["tp_y"]), P["z_usb_tp"], "USB-C\ncarga", ha="center", va="center", fontsize=FS - 2, zorder=6)
# ventana del interruptor en el costado (+Y queda a la izquierda)
ax.plot([u(li * W / 2)] * 2, [P["int_z"] - 3, P["int_z"] + 3], lw=3, color=COL["int"], zorder=6,
        solid_capstyle="butt")
globo(ax, 5, (u(li * W / 2), P["int_z"]), (u(li * W / 2) + 8 * li, -11))
cota_h(ax, -W / 2, W / 2, -5.5, "%g" % W)
cota_v(ax, -W / 2 - 8, 0, H, "%g" % H, x_ref=-W / 2 + 3)

# ======================= LEYENDA ===========================================
ax = fig.add_subplot(gs[3, :])
ax.axis("off")
items = [
    "1  ESP32 DevKit V1 en esquineros en L (PCB a z = %.1f; pines abajo)" % P["esp_z"],
    "2  Ranura USB de programación %g × %g (cara trasera)" % (P["usb_esp_ancho"], P["usb_esp_alto"]),
    "3  MPU6050 GY-521 plano, 2 tornillos M2.5, centro x = %g, y = 0" % mpu_x,
    "4  Motor vibrador Ø10 × 3 en anillo, pared del lado de la palma",
    "5  Interruptor SS12D00 en marco + ventana lateral",
    "6  Gatillo AGARRE (capuchón con pestaña, cara inferior)",
    "7  Torres M3 (4): tornillo avellanado M3 × %g desde abajo" % P["tornillo_largo"],
    "8  Postes de la bandeja con pasador de centrado (8)",
    "9  Guías de cables en el piso (2 pares)",
    "10 Bandeja separadora %g mm (aprisionada por las torres traseras)" % P["bandeja_esp"],
    "11 TP4056 USB-C con protección (sobre la bandeja)",
    "12 Ranura USB-C de carga %g × %g" % (P["ranura_tp_ancho"], P["ranura_tp_alto"]),
    "13 MT3608 elevador a 5 V (sobre la bandeja)",
    "14 Batería LiPo 503450, 1000 mAh (sobre la bandeja)",
    "15 Botón ATRÁS (triángulo hacia atrás, liso)",
    "16 Botón ADELANTE (triángulo hacia la punta, con punto)",
    "17 LED de estado Ø3 en tubo bajo la tapa",
    "18 Nervios de la tapa que sujetan la batería (con espuma)",
    "19 Placa perforada de los botones del pulgar (%g × %g, 4 × M2)" % (P["pp_largo"], P["pp_ancho"]),
    "20 Placa perforada del gatillo (%g × %g, 4 × M2)" % (P["pg_largo"], P["pg_ancho"]),
]
ncol = 2
filas = int(math.ceil(len(items) / float(ncol)))
for i, s in enumerate(items):
    c, f = divmod(i, filas)
    ax.text(0.0 + c * 0.37, 0.98 - f * 0.098, s, fontsize=FS + 0.5, va="top", transform=ax.transAxes)

# niveles Z y centro de masa estimado
masas = [  # (g, x) valores típicos
    (75, L / 2),                            # carcasa impresa (aprox.)
    (10, (esp_x0 + esp_x1) / 2),            # ESP32
    (3, (tp_x0 + tp_x1) / 2), (4, (mt_x0 + mt_x1) / 2),
    (20, (bat_x0 + bat_x1) / 2),            # batería
    (2, mpu_x), (1.5, P["motor_x"]),
    (9, x_pp), (4, xg),                     # botones, placas y capuchones
    (5, 70), (5, (P["torre_x_tras"] + P["torre_x_del"]) / 2),  # cables, tornillos
]
m_tot = sum(m for m, _ in masas)
x_cm = sum(m * x for m, x in masas) / m_tot
niveles = ("Niveles Z (desde la cara inferior):\n"
           "  piso interior %.1f · PCB ESP32 %.1f · tope ESP32 %.1f\n"
           "  bandeja %.1f–%.1f · batería hasta %.1f · unión %.1f\n"
           "  placa gatillo %.1f · placa pulgar %.1f · techo interior %.1f\n\n"
           "Masa estimada ≈ %.0f g · centro de masa ≈ x = %.0f mm\n"
           "(MPU en x = %g: dentro de la mano, sobre el eje de roll)"
           % (t, P["esp_z"], P["esp_tope"], b0, b1, P["z_bat_sup"], ab, zg, zpp, H - t, m_tot, x_cm, mpu_x))
ax.text(0.745, 0.98, niveles, fontsize=FS + 0.5, va="top", ha="left", transform=ax.transAxes,
        bbox=dict(boxstyle="round,pad=0.5", fc="#f4f6f8", ec="#8a99a8"))
ax.text(0.745, 0.02, "Pared %.1f mm · holgura de componentes %.1f mm · labio %.1f mm\n"
        "Líneas discontinuas: pared interior / piezas ocultas o en otro nivel"
        % (t, hol, P["labio_alto"]), fontsize=FS - 0.5, va="bottom", ha="left", transform=ax.transAxes,
        color="#444444")

fig.savefig(SALIDA, dpi=120)
print("Plano guardado en", SALIDA)
print("Dimensiones exteriores: %g x %g x %g mm" % (L, P["ancho_max"], H))
print("Espacio libre entre placas de botones: %.2f mm" % P["hueco_placas"])
print("Masa estimada %.0f g, centro de masa x = %.1f mm" % (m_tot, x_cm))
