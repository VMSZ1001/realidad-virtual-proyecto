# Especificación del sistema — Teleoperación de robot móvil con control háptico

Esta es la referencia única del proyecto. Firmware (`Firmware/`), Unity (`Unity/TeleopRV/`),
carcasa (`CAD/`) e informe (`Informe/`) siguen lo que dice este archivo.

## 1. Arquitectura

```
 [Control háptico]                         [Celular Android + visor Cardboard]
  MPU6050 --I2C--> ESP32 ---Bluetooth SPP--->  App Unity (TeleopRV)
  Joystick --ADC/GPIO-->| (en shield) <--vibración-- |- Cabeza: giroscopio del celular (3DOF)
  Módulo vibrador <--PWM--|                         |- Avatar: joystick (adelante/atrás, lateral)
  Powerbank --USB 5 V-->|                           |- Robot: Pitch -> v, Roll -> w, botón del joystick = Recolectar
                                                    |- Colisiones -> patrón de vibración
```

- Visor: celular con giroscopio en visor tipo Cardboard, pantalla dividida estéreo, orientación horizontal.
- Enlace: Bluetooth Classic, perfil SPP (puerto serie). El celular se empareja una vez con `HapticRV`
  desde los ajustes de Android; la app se conecta sola al dispositivo emparejado con ese nombre.
- En el editor de Unity (o en Windows) se puede usar el mismo control por el puerto COM que crea Windows
  al emparejar, o el teclado como simulador.

## 2. Pines del ESP32 DevKit (ESP32-WROOM-32 clásico) sobre la shield expansora

El ESP32 va enchufado en una shield expansora: cada GPIO tiene su fila **G-V-S** (tierra, alimentación, señal)
y cada módulo se conecta con cables Dupont hembra-hembra, sin soldar. El puente de la shield que elige la
tensión de las filas V va en **3.3 V**.

| Señal                | GPIO | Fila de la shield | Notas                                                  |
|----------------------|------|-------------------|--------------------------------------------------------|
| MPU6050 SDA          | 21   | G-V-S 21 (VCC, GND, SDA) | I2C 400 kHz, dirección 0x68 (AD0 a GND o libre) |
| MPU6050 SCL          | 22   | S 22              |                                                        |
| Joystick VRx         | 32   | G-V-S 32 (GND, +5V, VRx) | ADC1, 0–3.3 V; eje X (izquierda/derecha)         |
| Joystick VRy         | 33   | S 33              | ADC1, 0–3.3 V; eje Y (adelante/atrás)                    |
| Joystick SW (RECOLECTAR) | 25 | S 25            | A GND, `INPUT_PULLUP`, activo en bajo (presionar el joystick) |
| Módulo vibrador IN   | 18   | G-V-S 18 (GND, VCC, IN) | LEDC 20 kHz, 8 bits; el módulo trae su transistor |
| LED de estado        | 2    | S 2 (opcional)    | LED integrado + LED externo 3 mm con 330 Ω en la tapa   |
| Medición batería     | 34   | —                 | Sin uso con powerbank (`BATTERY_ENABLED 0`)            |

Joystick HW-504 (equivalente al KY-023: dos potenciómetros + pulsador). Su pin "+5V" va a la fila V de la
shield, es decir a **3.3 V** (el ADC del ESP32 admite máximo 3.3 V). Se usan pines ADC1 porque los de ADC2
no se pueden leer con la radio activa.

Módulo motor vibrador (23 × 20.8 mm, pines IN-VCC-GND): trae el transistor y el diodo, así que el GPIO solo
entrega la señal. Conexión: G → GND, V → VCC, S → IN (el módulo tiene los pines en orden IN-VCC-GND, al
revés que la fila G-V-S: revisa el cable antes de encender).

## 3. Alimentación

Powerbank de 5000 mAh (99 × 61 × 15 mm, 114 g) alojada en el compartimento inferior de la carcasa.
Un cable USB corto por la cara trasera la une con la entrada USB de 5 V de la shield (o con el USB del ESP32).
La shield regula 3.3 V para las filas V (puente en 3.3 V): MPU6050, joystick y módulo vibrador quedan a 3.3 V.

- Encender/apagar: conectar o desconectar el cable en la cara trasera.
- Cargar: por el puerto de entrada de la powerbank, que queda a ras de la cara trasera (o sacándola).
- El ESP32 no puede medir la carga de la powerbank: el campo `bat_mV` del paquete D va en 0 (Unity lo
  interpreta como "sin dato de batería"). Las luces de la powerbank indican su carga.
- Consumo estimado del control ≈ 110–150 mA con Bluetooth conectado: una powerbank de 5000 mAh
  (≈ 3000–3500 mAh útiles a 5 V) da muchas horas de uso. Si la powerbank se apaga sola por "carga baja",
  ver `CAD/README.md`.
- Programar: por el USB del ESP32 a través de la ventana trasera de la carcasa (desconectar la powerbank).

## 4. Protocolo (texto ASCII, una línea por mensaje, fin de línea `\n`)

### ESP32 -> Unity

| Mensaje | Formato | Frecuencia |
|---------|---------|------------|
| Saludo  | `H,HapticRV,<versión>` | al conectar |
| Datos   | `D,<seq>,<pitch×100>,<roll×100>,<botones>,<bat_mV>,<joyX>,<joyY>` | 50 Hz |
| Eco     | `P,<id>` | respuesta inmediata a `P,<id>` |
| Calibración | `K,<offPitch×100>,<offRoll×100>` | tras `C` o `G` |

- `pitch`, `roll` en grados después del filtro complementario y del cero calibrado. Enteros ×100.
- `botones`: máscara de bits. bit0 = RECOLECTAR (botón del joystick). Los demás bits quedan libres.
- `joyX`, `joyY`: joystick normalizado a −1000…1000 (centro calibrado en 0), +X = derecha, +Y = adelante.
  La zona muerta la aplica Unity. Unity acepta también paquetes sin estos dos campos (joystick en 0).
- `seq`: contador 0–65535, sirve para contar paquetes perdidos.

### Unity -> ESP32

| Comando | Formato | Efecto |
|---------|---------|--------|
| Vibrar  | `V,<patrón>,<intensidad 0-255>` | 0 = parar, 1 = objeto manipulable, 2 = pared/límite, 3 = confirmación de agarre |
| Ping    | `P,<id>` | el ESP32 responde `P,<id>`; Unity mide el tiempo de ida y vuelta (RTT) |
| Cero    | `C` | toma la inclinación actual como cero (control en reposo) y la guarda en memoria |
| Giro    | `G` | recalibra el sesgo del giroscopio (dejar quieto 2 s) |

### Patrones de vibración (PWM)

| Patrón | Evento | Forma |
|--------|--------|-------|
| 1 OBJETO | robot choca con objeto manipulable | 2 pulsos de 120 ms al 100 %, separados 100 ms |
| 2 PARED  | robot, objeto sujeto o avatar en contacto con pared/límite/obstáculo | pulso de 250 ms al 100 % que Unity reenvía cada 0.1 s mientras dura el contacto → vibración sostenida que se apaga ≈250 ms después de separarse |
| 3 AGARRE | objeto recogido (y recentrado) | 1 pulso de 150 ms al 100 %; soltar no vibra |

Cada vez que el motor arranca recibe 25 ms al 100 % para vencer la inercia. Con el módulo a 3.3 V
(`MOTOR_ON_3V3 1`, puente de la shield en 3.3 V) el ciclo útil va de 150 a 255; si el módulo se alimenta
a 5 V (`MOTOR_ON_3V3 0`) va de 80 a 170 (≈3.3 V promedio para el ERM de 3 V).
El contacto sostenido con una pared solo se mantiene mientras el usuario siga empujando hacia ella.

## 5. Mapeo de control

Robot (tracción diferencial):

- f(θ) = signo(θ) · clamp((|θ| − θ_z) / (θ_max − θ_z), 0, 1)^γ
- v = v_max · f(pitch)   (pitch positivo = control inclinado hacia adelante = avanza)
- ω = ω_max · f(roll)    (roll positivo = inclinado a la derecha = gira a la derecha)
- Valores por defecto: θ_z = 5°, θ_max = 35°, γ = 1.5, v_max = 1.2 m/s, ω_max = 90 °/s.
- Suavizado adicional en Unity: filtro exponencial de primer orden con τ = 0.12 s.

Avatar:

- Orientación de la cabeza = giroscopio del celular (3DOF).
- Joystick, relativo a la dirección horizontal de la mirada: Y = adelante/atrás, X = lateral (opción: giro por pasos de 30°).
  Velocidad máxima 1.5 m/s; zona muerta radial 0.15 y curva γ = 1.5.
- Botón del joystick (RECOLECTAR):
  - clic (< 0.5 s) = agarrar el objeto resaltado / soltarlo;
  - mantener 2 s = recentrar la vista y enviar `C` (cero del control);
  - mantener 5 s = reiniciar la tarea.

## 6. Métricas que registra la app (CSV en el almacenamiento de la app)

- `latencia_*.csv`: RTT de cada ping (1 por segundo) -> latencia ≈ RTT/2.
- `sesion_*.csv`: a 10 Hz: tiempo, pitch, roll, v, ω, botón, joystick X/Y, estado de agarre, paquetes perdidos.
- `eventos_*.csv`: colisiones (tipo, velocidad de impacto, patrón), agarres/sueltas, inicio/fin de tarea.
- Tarea de prueba: llevar los 3 cubos rojos a la zona verde. Se mide el tiempo de tarea y las colisiones.
