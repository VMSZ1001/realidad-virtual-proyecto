"""
Análisis de las métricas que guarda la app TeleopRV (MetricsLogger.cs).

Uso:
    python analizar_metricas.py <carpeta_con_csv> [--salida <carpeta>]

Copia la carpeta Metricas del celular (Android/data/com.umng.teleoprv/files/Metricas) al PC
y pásala como argumento. El script genera:
  - resumen.md               tabla con latencia, pérdida de paquetes, tareas y colisiones
  - latencia.png             histograma y serie temporal de la latencia
  - control.png              pitch/roll vs. velocidades del robot (mapeo y estabilidad)
  - tareas.png               tiempo de tarea y colisiones por intento
Requiere: numpy, matplotlib (sin pandas, para que funcione en cualquier instalación).
"""
import argparse
import csv
import glob
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def col(rows, name, cast=float):
    out = []
    for r in rows:
        try:
            out.append(cast(r[name]))
        except (ValueError, KeyError, TypeError):
            out.append(np.nan)
    return np.array(out, dtype=float)


def latest(folder, prefix):
    files = sorted(glob.glob(os.path.join(folder, prefix + "_*.csv")))
    return files


def analyze_latency(files, out):
    rtt = np.concatenate([col(read_csv(f), "rtt_ms") for f in files]) if files else np.array([])
    rtt = rtt[~np.isnan(rtt)]
    if rtt.size == 0:
        return None
    lat = rtt / 2.0
    stats = {
        "muestras": int(lat.size),
        "media_ms": float(np.mean(lat)),
        "mediana_ms": float(np.median(lat)),
        "p95_ms": float(np.percentile(lat, 95)),
        "max_ms": float(np.max(lat)),
        "desv_ms": float(np.std(lat)),
    }
    fig, ax = plt.subplots(1, 2, figsize=(11, 3.8))
    ax[0].hist(lat, bins=30, color="#2b6cb0", edgecolor="white")
    ax[0].axvline(stats["media_ms"], color="#c53030", ls="--", label=f"media {stats['media_ms']:.1f} ms")
    ax[0].axvline(stats["p95_ms"], color="#dd6b20", ls=":", label=f"p95 {stats['p95_ms']:.1f} ms")
    ax[0].set_xlabel("Latencia estimada RTT/2 (ms)")
    ax[0].set_ylabel("Muestras")
    ax[0].legend()
    ax[0].set_title("Distribución de la latencia")
    ax[1].plot(lat, color="#2b6cb0", lw=1)
    ax[1].set_xlabel("Ping (1 por segundo)")
    ax[1].set_ylabel("Latencia (ms)")
    ax[1].set_title("Latencia en el tiempo")
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(out, "latencia.png"), dpi=200)
    plt.close(fig)
    return stats


def analyze_session(files, out):
    if not files:
        return None
    rows = []
    for f in files:
        rows += read_csv(f)
    rows = [r for r in rows if r.get("fuente") == "control"] or rows
    t = col(rows, "t_s")
    pitch, roll = col(rows, "pitch_deg"), col(rows, "roll_deg")
    v, w = col(rows, "v_ms"), col(rows, "w_dps")
    rate = col(rows, "tasa_hz")
    lost = col(rows, "perdidos")

    # Estabilidad: ruido del control en reposo (|pitch| y |roll| dentro de la zona muerta)
    rest = (np.abs(pitch) < 5) & (np.abs(roll) < 5)
    fig, ax = plt.subplots(2, 2, figsize=(11, 6.5))
    ax[0, 0].plot(t - t[0], pitch, lw=0.8, label="pitch (°)")
    ax[0, 0].plot(t - t[0], v * 20, lw=0.8, label="v ×20 (m/s)")
    ax[0, 0].set_title("Pitch y velocidad lineal")
    ax[0, 0].legend(); ax[0, 0].grid(alpha=0.3)
    ax[0, 1].plot(t - t[0], roll, lw=0.8, color="#2f855a", label="roll (°)")
    ax[0, 1].plot(t - t[0], w / 3, lw=0.8, color="#805ad5", label="ω /3 (°/s)")
    ax[0, 1].set_title("Roll y velocidad angular")
    ax[0, 1].legend(); ax[0, 1].grid(alpha=0.3)
    ax[1, 0].scatter(pitch, v, s=3, alpha=0.4)
    ax[1, 0].set_xlabel("pitch (°)"); ax[1, 0].set_ylabel("v (m/s)")
    ax[1, 0].set_title("Mapeo medido pitch → v"); ax[1, 0].grid(alpha=0.3)
    ax[1, 1].scatter(roll, w, s=3, alpha=0.4, color="#2f855a")
    ax[1, 1].set_xlabel("roll (°)"); ax[1, 1].set_ylabel("ω (°/s)")
    ax[1, 1].set_title("Mapeo medido roll → ω"); ax[1, 1].grid(alpha=0.3)
    for a in ax[0]:
        a.set_xlabel("t (s)")
    fig.tight_layout()
    fig.savefig(os.path.join(out, "control.png"), dpi=200)
    plt.close(fig)

    return {
        "duracion_s": float(np.nanmax(t) - np.nanmin(t)),
        "tasa_media_hz": float(np.nanmean(rate[rate > 0])) if np.any(rate > 0) else float("nan"),
        "paquetes_perdidos": int(np.nanmax(lost)) if lost.size else 0,
        "ruido_pitch_reposo_deg": float(np.nanstd(pitch[rest])) if rest.any() else float("nan"),
        "ruido_roll_reposo_deg": float(np.nanstd(roll[rest])) if rest.any() else float("nan"),
        "deriva_v_reposo_ms": float(np.nanmean(np.abs(v[rest]))) if rest.any() else float("nan"),
    }


def analyze_events(files, out):
    if not files:
        return None
    rows = []
    for f in files:
        rows += read_csv(f)
    kinds = {}
    for r in rows:
        if r["tipo"] in ("colision", "colision_avatar"):
            key = r["tipo"] + ":" + r["detalle"]
            kinds[key] = kinds.get(key, 0) + 1
    tasks = []
    for r in rows:
        if r["tipo"] == "tarea_fin":
            detail = r["detalle"]
            coll = int(detail.split("colisiones")[-1].strip()) if "colisiones" in detail else 0
            tasks.append((float(r["valor"]), coll))
    grabs = sum(1 for r in rows if r["tipo"] == "agarre")

    if tasks:
        times = [x[0] for x in tasks]
        colls = [x[1] for x in tasks]
        fig, ax = plt.subplots(figsize=(7, 3.6))
        idx = np.arange(1, len(tasks) + 1)
        ax.bar(idx, times, color="#2b6cb0", label="tiempo (s)")
        ax2 = ax.twinx()
        ax2.plot(idx, colls, "o-", color="#c53030", label="colisiones")
        ax.set_xlabel("Intento completado")
        ax.set_ylabel("Tiempo de tarea (s)")
        ax2.set_ylabel("Colisiones")
        ax.set_xticks(idx)
        ax.set_title("Tarea: llevar los cubos a la zona verde")
        fig.legend(loc="upper right", bbox_to_anchor=(0.88, 0.88))
        fig.tight_layout()
        fig.savefig(os.path.join(out, "tareas.png"), dpi=200)
        plt.close(fig)

    return {"colisiones_por_tipo": kinds, "tareas": tasks, "agarres": grabs}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")   # la consola de Windows usa cp1252
    ap = argparse.ArgumentParser()
    ap.add_argument("carpeta")
    ap.add_argument("--salida", default=None)
    a = ap.parse_args()
    out = a.salida or os.path.join(a.carpeta, "analisis")
    os.makedirs(out, exist_ok=True)

    lat = analyze_latency(latest(a.carpeta, "latencia"), out)
    ses = analyze_session(latest(a.carpeta, "sesion"), out)
    ev = analyze_events(latest(a.carpeta, "eventos"), out)

    lines = ["# Resumen de métricas", ""]
    if lat:
        lines += ["## Latencia (RTT/2)", "", "| Métrica | Valor |", "|---|---|"]
        lines += [f"| Muestras | {lat['muestras']} |",
                  f"| Media | {lat['media_ms']:.1f} ms |",
                  f"| Mediana | {lat['mediana_ms']:.1f} ms |",
                  f"| Percentil 95 | {lat['p95_ms']:.1f} ms |",
                  f"| Máximo | {lat['max_ms']:.1f} ms |",
                  f"| Desviación estándar | {lat['desv_ms']:.1f} ms |", ""]
    if ses:
        lines += ["## Enlace y estabilidad del control", "", "| Métrica | Valor |", "|---|---|"]
        lines += [f"| Duración registrada | {ses['duracion_s']:.0f} s |",
                  f"| Tasa media de paquetes | {ses['tasa_media_hz']:.1f} Hz |",
                  f"| Paquetes perdidos | {ses['paquetes_perdidos']} |",
                  f"| Ruido del pitch en reposo (σ) | {ses['ruido_pitch_reposo_deg']:.2f}° |",
                  f"| Ruido del roll en reposo (σ) | {ses['ruido_roll_reposo_deg']:.2f}° |",
                  f"| Velocidad residual en reposo | {ses['deriva_v_reposo_ms']:.3f} m/s |", ""]
    if ev:
        lines += ["## Colisiones y tareas", "", "| Evento | Cantidad |", "|---|---|"]
        for k, n in sorted(ev["colisiones_por_tipo"].items()):
            lines.append(f"| {k} | {n} |")
        lines.append(f"| Agarres | {ev['agarres']} |")
        lines.append("")
        if ev["tareas"]:
            lines += ["| Intento | Tiempo (s) | Colisiones |", "|---|---|---|"]
            for i, (tt, cc) in enumerate(ev["tareas"], 1):
                lines.append(f"| {i} | {tt:.1f} | {cc} |")
            times = [x[0] for x in ev["tareas"]]
            lines.append(f"| **Media** | **{np.mean(times):.1f}** | **{np.mean([x[1] for x in ev['tareas']]):.1f}** |")
    with open(os.path.join(out, "resumen.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines))
    print(f"\nArchivos en: {out}")


if __name__ == "__main__":
    sys.exit(main())
