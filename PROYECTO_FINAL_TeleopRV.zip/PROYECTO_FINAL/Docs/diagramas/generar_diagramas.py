# -*- coding: utf-8 -*-
"""
Genera los diagramas del informe técnico del proyecto
"Teleoperación de robot móvil virtual con control háptico inalámbrico"
(UMNG · Realidad Virtual · Ingeniería Mecatrónica).

Todos los pines, valores y mensajes siguen Docs/ESPECIFICACION.md.

Uso:
    python generar_diagramas.py            # genera los 5 diagramas
    python generar_diagramas.py 1 3        # genera solo los diagramas 1 y 3

Salida (en la misma carpeta del script), PNG a 200 dpi, fondo blanco:
    diagrama_bloques.png, diagrama_electrico.png, diagrama_comunicacion.png,
    diagrama_mapeo.png, diagrama_flujo_firmware.png

Los lienzos de los diagramas 1, 2, 3 y 5 usan un sistema de coordenadas en
pulgadas (1 unidad = 1 in al tamaño de impresión, ancho 6.5 in), de modo que
un texto de 9 pt en el script mide 9 pt en el informe impreso a ancho de texto.
"""
import os
import sys

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.patches import (FancyBboxPatch, Rectangle, Circle,  # noqa: E402
                                Polygon)
from matplotlib.gridspec import GridSpec  # noqa: E402

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
DPI = 200
W = 6.5  # ancho de impresión (in) = ancho de texto de una página carta

plt.rcParams.update({
    "font.family": "Arial",
    "font.size": 9,
    "mathtext.fontset": "custom",
    "mathtext.rm": "Arial",
    "mathtext.it": "Arial:italic",
    "mathtext.bf": "Arial:bold",
    "axes.unicode_minus": False,
    "savefig.facecolor": "white",
})

# ---------------------------------------------------------------------------
# Paleta común (la misma en todos los diagramas)
# ---------------------------------------------------------------------------
PAL = {
    "ctrl": dict(edge="#2B5C8A", fill="#DCE9F5", bg="#F3F8FC"),   # control háptico
    "cel": dict(edge="#2D7A4B", fill="#DCEFE2", bg="#F3FAF5"),    # celular / Unity
    "ener": dict(edge="#B3620B", fill="#FBE6CF", bg="#FDF5EC"),   # energía
    "user": dict(edge="#5B4A86", fill="#EAE5F3", bg="#F6F4FA"),   # usuario / visor
    "neu": dict(edge="#555555", fill="#EFEFEF", bg="#F7F7F7"),    # neutro
}
INK = "#1E1E1E"
MUTED = "#4A4A4A"
LINK = "#2B2B2B"
MONO = "Consolas"


# ---------------------------------------------------------------------------
# Utilidades de dibujo (coordenadas en pulgadas)
# ---------------------------------------------------------------------------
def canvas(h, w=W):
    fig = plt.figure(figsize=(w, h))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, w)
    ax.set_ylim(0, h)
    ax.set_aspect("equal")
    ax.axis("off")
    return fig, ax


def rbox(ax, x0, y0, x1, y1, style="ctrl", kind="fill", lw=1.1, r=0.06,
         ls="-", z=2):
    """Caja redondeada. kind: 'fill' (bloque), 'bg' (grupo), 'white'."""
    p = PAL[style]
    face = {"fill": p["fill"], "bg": p["bg"], "white": "white"}[kind]
    patch = FancyBboxPatch((x0, y0), x1 - x0, y1 - y0,
                           boxstyle="round,pad=0,rounding_size=%g" % r,
                           fc=face, ec=p["edge"], lw=lw, ls=ls, zorder=z)
    ax.add_patch(patch)
    return patch


def btext(ax, cx, cy, title=None, sub=None, fs=9, color=INK, sub_color=MUTED,
          title_fs=None, z=5, mono_sub=False):
    """Texto de bloque: título en negrita + subtítulo, centrados en (cx, cy)."""
    title_fs = title_fs or fs
    lh_t = title_fs * 1.22 / 72.0
    lh_s = fs * 1.22 / 72.0
    nt = title.count("\n") + 1 if title else 0
    ns = sub.count("\n") + 1 if sub else 0
    total = nt * lh_t + ns * lh_s
    top = cy + total / 2.0
    if title:
        ax.text(cx, top - nt * lh_t / 2.0, title, ha="center", va="center",
                fontsize=title_fs, fontweight="bold", color=color, zorder=z,
                linespacing=1.1)
    if sub:
        ax.text(cx, top - nt * lh_t - ns * lh_s / 2.0, sub, ha="center",
                va="center", fontsize=fs, color=sub_color, zorder=z,
                linespacing=1.1, family=MONO if mono_sub else None)


def arrow(ax, pts, color=LINK, lw=1.2, both=False, ls="-", ms=9, z=3):
    """Flecha ortogonal por los puntos dados; punta en el último punto."""
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    if len(pts) > 2:
        ax.plot(xs[:-1], ys[:-1], color=color, lw=lw, ls=ls, zorder=z,
                solid_capstyle="butt")
    style = "<|-|>" if both else "-|>"
    ax.annotate("", xy=pts[-1], xytext=pts[-2],
                arrowprops=dict(arrowstyle=style, color=color, lw=lw, ls=ls,
                                shrinkA=0, shrinkB=0, mutation_scale=ms),
                zorder=z)


def label(ax, x, y, s, ha="center", va="center", fs=9, color=MUTED,
          weight="normal", style="normal", mono=False, z=6, bg=None, **kw):
    t = ax.text(x, y, s, ha=ha, va=va, fontsize=fs, color=color,
                fontweight=weight, fontstyle=style, zorder=z,
                family=MONO if mono else None, linespacing=1.15, **kw)
    if bg:
        t.set_bbox(dict(fc=bg, ec="none", pad=0.6))
    return t


def check_overlaps(fig, name):
    """Informa pares de textos cuyos rectángulos se solapan (control de calidad)."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    texts = [t for t in fig.findobj(matplotlib.text.Text)
             if t.get_visible() and t.get_text().strip()]
    boxes = [(t, t.get_window_extent(r)) for t in texts]
    n = 0
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i][1], boxes[j][1]
            ov_x = min(a.x1, b.x1) - max(a.x0, b.x0)
            ov_y = min(a.y1, b.y1) - max(a.y0, b.y0)
            if ov_x > 1 and ov_y > 1:
                n += 1
                print("  [solape] %s: %r <-> %r" % (
                    name, boxes[i][0].get_text()[:30], boxes[j][0].get_text()[:30]))
    fw, fh = fig.canvas.get_width_height()
    for t, b in boxes:
        if b.x0 < 0 or b.y0 < 0 or b.x1 > fw or b.y1 > fh:
            print("  [cortado] %s: %r" % (name, t.get_text()[:30]))
            n += 1
    return n


def save(fig, fname):
    path = os.path.join(OUT_DIR, fname)
    n = check_overlaps(fig, fname)
    fig.savefig(path, dpi=DPI, facecolor="white")
    plt.close(fig)
    print("OK  %s  (%d avisos)" % (path, n))


# ===========================================================================
# 1. Diagrama de bloques
# ===========================================================================
def diagrama_bloques():
    H = 5.6
    fig, ax = canvas(H)

    # --- Usuario -----------------------------------------------------------
    rbox(ax, 0.1, 5.1, 6.4, 5.5, "user", "fill", r=0.08)
    btext(ax, 2.62, 5.3, "Usuario (operador)", title_fs=10)

    # --- Grupo control háptico --------------------------------------------
    rbox(ax, 0.1, 2.95, 4.5, 4.8, "ctrl", "bg", lw=1.3, r=0.1, z=1)
    label(ax, 2.62, 4.62, "Control háptico", fs=10, weight="bold",
          color=PAL["ctrl"]["edge"])

    rbox(ax, 0.3, 3.85, 1.0, 4.4, "ctrl")
    btext(ax, 0.65, 4.125, "IMU", "MPU6050")
    rbox(ax, 1.12, 3.85, 2.08, 4.4, "ctrl")
    btext(ax, 1.6, 4.125, "Joystick", "HW-504")
    rbox(ax, 3.0, 3.85, 4.35, 4.4, "ctrl")
    btext(ax, 3.675, 4.125, "Módulo vibrador", "transistor · ERM 3 V")
    rbox(ax, 0.3, 3.05, 1.95, 3.6, "ctrl")
    btext(ax, 1.125, 3.325, "ESP32 + shield",
          "filtro complementario\nBluetoothSerial · LEDC")
    rbox(ax, 2.55, 3.05, 4.35, 3.6, "ener")
    btext(ax, 3.45, 3.325, "Energía",
          "powerbank 5000 mAh\ncable USB 5 V")

    c_ctrl = PAL["ctrl"]["edge"]
    c_en = PAL["ener"]["edge"]
    arrow(ax, [(0.65, 3.85), (0.65, 3.6)], c_ctrl)
    label(ax, 0.695, 3.725, "I2C", ha="left")
    arrow(ax, [(1.6, 3.85), (1.6, 3.6)], c_ctrl)
    label(ax, 1.645, 3.725, "ADC", ha="left")
    arrow(ax, [(1.95, 3.5), (2.25, 3.5), (2.25, 4.12), (3.0, 4.12)], c_ctrl)
    label(ax, 2.62, 4.16, "PWM", va="bottom")
    arrow(ax, [(2.55, 3.15), (1.95, 3.15)], c_en)
    label(ax, 2.25, 3.2, "5 V", va="bottom")
    arrow(ax, [(3.675, 3.6), (3.675, 3.85)], c_en)
    label(ax, 3.72, 3.725, "3.3 V", ha="left")

    # Usuario <-> control
    c_u = PAL["user"]["edge"]
    arrow(ax, [(0.65, 5.1), (0.65, 4.4)], c_u)
    label(ax, 0.695, 4.95, "inclinación", ha="left")
    arrow(ax, [(1.6, 5.1), (1.6, 4.4)], c_u)
    label(ax, 1.645, 4.95, "pulgar", ha="left")
    arrow(ax, [(3.675, 4.4), (3.675, 5.1)], c_u)
    label(ax, 3.72, 4.95, "vibración", ha="left")

    # --- Visor ---------------------------------------------------------------
    rbox(ax, 5.1, 3.45, 6.4, 4.3, "user")
    btext(ax, 5.75, 3.875, "Visor Cardboard", "lentes · vista\ndividida")

    # --- Grupo celular ------------------------------------------------------
    rbox(ax, 0.1, 0.1, 6.4, 2.6, "cel", "bg", lw=1.3, r=0.1, z=1)
    label(ax, 2.75, 2.38, "Celular Android", fs=10, weight="bold",
          color=PAL["cel"]["edge"])
    rbox(ax, 3.45, 2.08, 4.5, 2.44, "cel")
    btext(ax, 3.975, 2.26, "Giroscopio")
    rbox(ax, 5.0, 2.08, 6.05, 2.44, "cel")
    btext(ax, 5.525, 2.26, "Pantalla")

    # App Unity
    rbox(ax, 0.2, 0.17, 6.25, 1.95, "cel", "white", lw=1.0, r=0.08, ls=(0, (4, 2)),
         z=1.5)
    label(ax, 3.2, 1.8, "App Unity (TeleopRV)", fs=9, weight="bold",
          color=PAL["cel"]["edge"])

    cols = [(0.35, 1.4), (1.9, 2.95), (3.45, 4.5), (5.0, 6.05)]
    r1 = (1.1, 1.62)
    r2 = (0.27, 0.75)
    mods = {
        (0, 1): ("Comunicación", "SPP · RTT"),
        (1, 1): ("Mapeo de\ncontrol", None),
        (2, 1): ("Avatar", "cabeza 3DOF"),
        (3, 1): ("Render", "estéreo"),
        (0, 2): ("Háptica", "patrones 1–3"),
        (1, 2): ("Física y\ncolisiones", None),
        (2, 2): ("Robot móvil", "tracción dif."),
        (3, 2): ("Registro de", "métricas (CSV)"),
    }
    for (ci, ri), (t, s) in mods.items():
        x0, x1 = cols[ci]
        y0, y1 = r1 if ri == 1 else r2
        rbox(ax, x0, y0, x1, y1, "cel")
        btext(ax, (x0 + x1) / 2, (y0 + y1) / 2, t, s)

    c_c = PAL["cel"]["edge"]
    ym1 = sum(r1) / 2
    ym2 = sum(r2) / 2
    arrow(ax, [(1.4, ym1), (1.9, ym1)], c_c)
    label(ax, 1.65, ym1 + 0.05, "pitch\nroll\njoystick", va="bottom")
    arrow(ax, [(2.95, ym1), (3.45, ym1)], c_c)
    label(ax, 3.2, ym1 + 0.05, "avance\n1.5 m/s", va="bottom")
    arrow(ax, [(4.5, ym1), (5.0, ym1)], c_c)
    label(ax, 4.75, ym1 + 0.05, "cámara", va="bottom")
    arrow(ax, [(5.525, r1[1]), (5.525, 2.08)], c_c)
    arrow(ax, [(3.975, 2.08), (3.975, r1[1])], c_c)
    label(ax, 4.02, 1.85, "orientación", ha="left")
    ylane = (r1[0] + r2[1]) / 2
    arrow(ax, [(2.6, r1[0]), (2.6, ylane), (3.8, ylane), (3.8, r2[1])], c_c)
    label(ax, 3.2, ylane + 0.03, "v, ω", va="bottom")
    arrow(ax, [(3.45, ym2), (2.95, ym2)], c_c)
    label(ax, 3.2, ym2 + 0.04, "colisión", va="bottom")
    arrow(ax, [(1.9, ym2), (1.4, ym2)], c_c)
    label(ax, 1.65, ym2 + 0.04, "impacto", va="bottom")
    arrow(ax, [(0.875, r2[1]), (0.875, r1[0])], c_c)
    label(ax, 0.92, ylane, "patrón", ha="left")
    arrow(ax, [(4.5, ym2), (5.0, ym2)], c_c)
    label(ax, 4.75, ym2 + 0.04, "datos", va="bottom")

    # --- Enlace Bluetooth ---------------------------------------------------
    arrow(ax, [(0.7, 3.05), (0.7, r1[1])], LINK, lw=1.5)
    label(ax, 0.65, 2.3, "D 50 Hz\nH, P, K", ha="right", color=INK)
    arrow(ax, [(1.1, r1[1]), (1.1, 3.05)], LINK, lw=1.5)
    label(ax, 1.15, 2.3, "V, P, C, G", ha="left", color=INK)
    label(ax, 1.15, 2.78, "Bluetooth Classic SPP", ha="left", color=INK,
          weight="bold")

    # --- Cabeza, visor ----------------------------------------------------
    arrow(ax, [(4.8, 5.1), (4.8, 2.26), (4.5, 2.26)], c_u)
    label(ax, 4.85, 4.95, "giro de la\ncabeza", ha="left", va="center")
    arrow(ax, [(5.525, 2.44), (5.525, 3.45)], c_u)
    label(ax, 5.57, 2.95, "imagen\nestéreo", ha="left")
    arrow(ax, [(5.75, 4.3), (5.75, 5.1)], c_u)
    label(ax, 5.8, 4.7, "vista 3D", ha="left")

    save(fig, "diagrama_bloques.png")


# ===========================================================================
# 2. Diagrama eléctrico (esquemático)
# ===========================================================================
C_PWR = PAL["ener"]["edge"]      # redes de potencia (VBAT, 5 V, 3V3)
C_SIG = PAL["ctrl"]["edge"]      # señales
C_GND = "#222222"                # tierra
WLW = 1.2


def wire(ax, pts, color=C_SIG, lw=WLW, z=3):
    ax.plot([p[0] for p in pts], [p[1] for p in pts], color=color, lw=lw,
            zorder=z, solid_capstyle="round", solid_joinstyle="miter")


def dot(ax, x, y, color=INK):
    ax.add_patch(Circle((x, y), 0.028, fc=color, ec=color, zorder=6))


def gnd(ax, x, y, lead=0.1):
    """Símbolo de tierra colgando del punto (x, y)."""
    wire(ax, [(x, y), (x, y - lead)], C_GND)
    yb = y - lead
    for i, w_ in enumerate((0.18, 0.11, 0.045)):
        ax.plot([x - w_ / 2, x + w_ / 2], [yb - i * 0.035] * 2, color=C_GND,
                lw=1.3, zorder=3)


def res_v(ax, x, y0, y1, color=C_SIG):
    ax.add_patch(Rectangle((x - 0.05, y0), 0.1, y1 - y0, fc="white", ec=color,
                           lw=WLW, zorder=4))


def res_h(ax, x0, x1, y, color=C_SIG):
    ax.add_patch(Rectangle((x0, y - 0.05), x1 - x0, 0.1, fc="white", ec=color,
                           lw=WLW, zorder=4))


def cap_v(ax, x, yc, color=C_SIG, gap=0.03, w_=0.18):
    """Condensador vertical (placas horizontales); cubre la línea de fondo."""
    ax.add_patch(Rectangle((x - w_ / 2, yc - gap), w_, 2 * gap, fc="white",
                           ec="none", zorder=4))
    for s in (-1, 1):
        ax.plot([x - w_ / 2, x + w_ / 2], [yc + s * gap] * 2, color=color,
                lw=1.6, zorder=5)


def diode_v(ax, x, yc, color=C_SIG, s=0.09, cathode_up=True):
    d = 1 if cathode_up else -1
    tri = Polygon([(x - s, yc - d * s * 0.8), (x + s, yc - d * s * 0.8),
                   (x, yc + d * s * 0.8)], closed=True, fc="white", ec=color,
                  lw=WLW, zorder=5)
    ax.add_patch(tri)
    ax.plot([x - s, x + s], [yc + d * s * 0.8] * 2, color=color, lw=1.5, zorder=5)


def motor(ax, x, yc, r=0.17, color=C_PWR):
    ax.add_patch(Circle((x, yc), r, fc="white", ec=color, lw=WLW, zorder=5))
    ax.text(x, yc, "M", ha="center", va="center", fontsize=9.5,
            fontweight="bold", color=INK, zorder=6)


def npn(ax, xb, yb, color=C_SIG):
    """Transistor NPN. (xb, yb) = extremo del terminal de base.
    Devuelve (colector, emisor) como puntos (x, y)."""
    cx, cy, r = xb + 0.3, yb, 0.2
    ax.add_patch(Circle((cx, cy), r, fc="white", ec=color, lw=WLW, zorder=4))
    xbar = cx - 0.07
    wire(ax, [(xb, yb), (xbar, yb)], color, z=5)
    ax.plot([xbar, xbar], [yb - 0.1, yb + 0.1], color=color, lw=2.0, zorder=5)
    xc = cx + 0.08
    col = (xc, cy + 0.26)
    emi = (xc, cy - 0.26)
    wire(ax, [(xbar, yb + 0.05), (xc, cy + 0.13), col], color, z=5)
    wire(ax, [(xbar, yb - 0.05), (xc, cy - 0.13), emi], color, z=5)
    ax.annotate("", xy=(xc, cy - 0.13), xytext=(xbar + 0.02, yb - 0.06),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=1.0,
                                mutation_scale=7, shrinkA=0, shrinkB=0),
                zorder=6)
    return col, emi


def switch_h(ax, x0, x1, y, color=C_PWR):
    for xx in (x0, x1):
        ax.add_patch(Circle((xx, y), 0.028, fc="white", ec=color, lw=1.1,
                            zorder=6))
    ax.plot([x0 + 0.02, x1 - 0.03], [y + 0.01, y + 0.13], color=color, lw=1.4,
            zorder=5)


def button_h(ax, x0, x1, y, color=C_SIG):
    for xx in (x0, x1):
        ax.add_patch(Circle((xx, y), 0.025, fc="white", ec=color, lw=1.1,
                            zorder=6))
    ya = y + 0.09
    ax.plot([x0 - 0.01, x1 + 0.01], [ya, ya], color=color, lw=1.4, zorder=5)
    xm = (x0 + x1) / 2
    ax.plot([xm, xm], [ya, ya + 0.07], color=color, lw=1.4, zorder=5)
    ax.plot([xm - 0.05, xm + 0.05], [ya + 0.07, ya + 0.07], color=color,
            lw=1.4, zorder=5)


def battery_v(ax, x, yc, color=C_PWR):
    """Batería de una celda: placa larga (+) arriba."""
    ax.add_patch(Rectangle((x - 0.13, yc - 0.05), 0.26, 0.1, fc="white",
                           ec="none", zorder=4))
    ax.plot([x - 0.13, x + 0.13], [yc + 0.04] * 2, color=color, lw=1.6, zorder=5)
    ax.plot([x - 0.07, x + 0.07], [yc - 0.04] * 2, color=color, lw=2.6, zorder=5)
    ax.text(x + 0.16, yc + 0.09, "+", ha="left", va="center", fontsize=9,
            color=INK, zorder=6)


def netflag(ax, x, y, text, color=C_PWR, up=True):
    """Etiqueta de red: barra en T con el nombre encima."""
    ax.plot([x - 0.08, x + 0.08], [y, y], color=color, lw=1.6, zorder=5)
    ax.text(x, y + (0.04 if up else -0.04), text, ha="center",
            va="bottom" if up else "top", fontsize=9, color=INK,
            fontweight="bold", zorder=6)


def module(ax, x0, y0, x1, y1, style):
    ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fc=PAL[style]["fill"],
                           ec=PAL[style]["edge"], lw=1.3, zorder=2))


def pin_l(ax, x, y, s):   # etiqueta de pin en el borde izquierdo (dentro)
    ax.text(x + 0.05, y, s, ha="left", va="center", fontsize=9, color=INK,
            zorder=6)


def pin_r(ax, x, y, s):   # etiqueta de pin en el borde derecho (dentro)
    ax.text(x - 0.05, y, s, ha="right", va="center", fontsize=9, color=INK,
            zorder=6)


def diagrama_electrico():
    H = 5.4
    fig, ax = canvas(H)

    def cable(x0, x1, y, color):
        wire(ax, [(x0, y), (x1, y)], color)

    # ------------------------------------------------------------ Shield + ESP32
    sx0, sx1, sy0, sy1 = 2.0, 4.0, 0.55, 5.15
    module(ax, sx0, sy0, sx1, sy1, "neu")
    label(ax, (sx0 + sx1) / 2, 4.97, "Shield expansora", fs=9, color=INK, weight="bold")
    label(ax, (sx0 + sx1) / 2, 4.55, "AMS1117 → 3.3 V\npuente V = 3.3 V", fs=9, color=MUTED)
    ex0, ex1, ey0, ey1 = 2.68, 3.32, 1.35, 4.1
    module(ax, ex0, ey0, ex1, ey1, "ctrl")
    label(ax, (ex0 + ex1) / 2, 3.95, "ESP32\nDevKit", fs=9, color=INK, weight="bold", va="top")
    label(ax, (ex0 + ex1) / 2, 1.65, "USB:\nprogramar", fs=9, color=MUTED)
    label(ax, (sx0 + sx1) / 2, 0.85, "filas G-V-S\nde cada GPIO", fs=9, color=MUTED)

    # ------------------------------------------------------------ Powerbank
    module(ax, 0.15, 4.5, 1.35, 5.15, "ener")
    label(ax, 0.75, 4.95, "Powerbank", fs=9, color=INK, weight="bold")
    label(ax, 0.75, 4.7, "5000 mAh", fs=9, color=MUTED)
    cable(1.35, sx0, 4.82, C_PWR)
    label(ax, 1.67, 4.87, "cable USB", fs=9, color=INK, va="bottom")
    label(ax, 1.67, 4.77, "5 V", fs=9, color=MUTED, va="top")

    # ------------------------------------------------------------ MPU6050
    mx0, mx1, my0, my1 = 0.15, 1.2, 3.32, 4.1
    module(ax, mx0, my0, mx1, my1, "ctrl")
    label(ax, (mx0 + mx1) / 2, my1 + 0.04, "MPU6050 GY-521", fs=9, color=INK,
          weight="bold", va="bottom")
    filas = [("VCC", "V", C_PWR, 3.97), ("GND", "G", C_GND, 3.8),
             ("SDA", "S21", C_SIG, 3.63), ("SCL", "S22", C_SIG, 3.46)]
    for pm, ps, col, y in filas:
        pin_r(ax, mx1, y, pm)
        pin_l(ax, sx0, y, ps)
        cable(mx1, sx0, y, col)
    label(ax, mx0, my0 - 0.06, "AD0 a GND → 0x68", fs=9, color=MUTED, ha="left", va="top")

    # ------------------------------------------------------------ Joystick
    jx0, jx1, jy0, jy1 = 0.15, 1.2, 1.75, 2.85
    module(ax, jx0, jy0, jx1, jy1, "ctrl")
    label(ax, (jx0 + jx1) / 2, jy1 + 0.04, "Joystick HW-504", fs=9, color=INK,
          weight="bold", va="bottom")
    filas = [("+5V", "V", C_PWR, 2.7), ("GND", "G", C_GND, 2.5), ("VRx", "S32", C_SIG, 2.3),
             ("VRy", "S33", C_SIG, 2.1), ("SW", "S25", C_SIG, 1.9)]
    for pm, ps, col, y in filas:
        pin_r(ax, jx1, y, pm)
        pin_l(ax, sx0, y, ps)
        cable(jx1, sx0, y, col)
    label(ax, jx0, jy0 - 0.06, "Su pin +5V va a 3.3 V:\nel ADC admite 3.3 V\n"
          "como máximo. SW con\nINPUT_PULLUP.", fs=9, color=MUTED, ha="left", va="top")

    # ------------------------------------------------------------ Módulo vibrador
    vx0, vx1, vy0, vy1 = 4.75, 5.95, 3.15, 4.05
    module(ax, vx0, vy0, vx1, vy1, "ctrl")
    label(ax, (vx0 + vx1) / 2, vy1 + 0.04, "Módulo vibrador", fs=9, color=INK,
          weight="bold", va="bottom")
    filas = [("VCC", "V", C_PWR, 3.9), ("GND", "G", C_GND, 3.7), ("IN", "S18", C_SIG, 3.5)]
    for pm, ps, col, y in filas:
        pin_l(ax, vx0, y, pm)
        pin_r(ax, sx1, y, ps)
        cable(sx1, vx0, y, col)
    motor(ax, 5.65, 3.62, r=0.15)
    label(ax, (vx0 + vx1) / 2, 3.28, "transistor + ERM", fs=9, color=MUTED)
    label(ax, 4.38, 3.45, "PWM", fs=9, color=MUTED, va="top")

    # ------------------------------------------------------------ LED opcional
    yl = 2.9
    pin_r(ax, sx1, yl, "S2")
    wire(ax, [(sx1, yl), (5.0, yl), (5.0, 2.52)], C_SIG)
    res_h(ax, 4.3, 4.7, yl)
    label(ax, 4.5, yl + 0.08, "330 Ω", fs=9, color=INK, va="bottom")
    diode_v(ax, 5.0, 2.72, C_SIG, s=0.07, cathode_up=False)
    gnd(ax, 5.0, 2.52)
    label(ax, 5.12, 2.75, "LED 3 mm\n(tapa, opcional)", fs=9, color=INK, ha="left")

    # ------------------------------------------------------------ Tabla
    rows = [("GPIO", "Conexión"),
            ("21 / 22", "MPU6050 SDA / SCL"),
            ("32 / 33", "Joystick VRx / VRy"),
            ("25", "Joystick SW"),
            ("18", "Módulo vibrador IN"),
            ("2", "LED de estado"),
            ("V", "3.3 V (puente)")]
    tx0, tx1, tcol = 4.25, 6.45, 4.95
    rh = 0.22
    ty = 1.92
    for i, (a, b) in enumerate(rows):
        y1 = ty - i * rh
        y0 = y1 - rh
        fc = PAL["ctrl"]["fill"] if i == 0 else ("#F4F4F4" if i % 2 == 0 else "white")
        ax.add_patch(Rectangle((tx0, y0), tx1 - tx0, rh, fc=fc, ec="#9A9A9A",
                               lw=0.6, zorder=2))
        wgt = "bold" if i == 0 else "normal"
        label(ax, (tx0 + tcol) / 2, (y0 + y1) / 2, a, fs=9, color=INK, weight=wgt)
        label(ax, tcol + 0.06, (y0 + y1) / 2, b, fs=9, color=INK, weight=wgt, ha="left")
    ax.plot([tcol, tcol], [ty - len(rows) * rh, ty], color="#9A9A9A", lw=0.6, zorder=3)
    label(ax, tx0, ty - len(rows) * rh - 0.06, "Cables Dupont hembra-hembra;\nGND común.",
          fs=9, color=MUTED, ha="left", va="top")

    save(fig, "diagrama_electrico.png")


# ===========================================================================
# 3. Diagrama de secuencia (comunicación)
# ===========================================================================
def diagrama_comunicacion():
    H = 5.8
    fig, ax = canvas(H)
    xe, xu = 0.75, 3.35          # líneas de vida
    top = H - 0.1
    hb = 0.42
    rbox(ax, xe - 0.65, top - hb, xe + 0.65, top, "ctrl")
    btext(ax, xe, top - hb / 2, "ESP32", "control háptico")
    rbox(ax, xu - 0.65, top - hb, xu + 0.65, top, "cel")
    btext(ax, xu, top - hb / 2, "App Unity", "celular Android")
    for x, st in ((xe, "ctrl"), (xu, "cel")):
        ax.plot([x, x], [0.05, top - hb], color=PAL[st]["edge"], lw=1.0,
                ls=(0, (4, 3)), zorder=1)

    ce = PAL["ctrl"]["edge"]
    cu = PAL["cel"]["edge"]
    xm = (xe + xu) / 2

    def msg(y, text, direction, color, note=None, mono=True, side=None):
        if direction == "e2u":
            arrow(ax, [(xe, y), (xu, y)], color, lw=1.2)
        else:
            arrow(ax, [(xu, y), (xe, y)], color, lw=1.2)
        label(ax, xm, y + 0.03, text, va="bottom", color=INK, mono=mono,
              fs=9.5 if mono else 9)
        if note and side:
            label(ax, xu + 0.15, y, note, ha="left", va="center", color=MUTED)
        elif note:
            label(ax, xm, y - 0.035, note, va="top", color=MUTED)

    def frame(y1, y0, tag, x1=3.95):
        x0 = 0.12
        ax.add_patch(Rectangle((x0, y0), x1 - x0, y1 - y0, fc="none",
                               ec="#8A8A8A", lw=0.9, zorder=1.5))
        t = label(ax, x0 + 0.05, y1 - 0.035, tag, ha="left", va="top",
                  color=INK, fs=9, weight="bold")
        t.set_bbox(dict(fc="#EDEDED", ec="#8A8A8A", lw=0.8, pad=1.2))

    def activation(y1, y0, x=xe):
        ax.add_patch(Rectangle((x - 0.05, y0), 0.1, y1 - y0,
                               fc=PAL["ctrl"]["fill"], ec=ce, lw=0.9,
                               zorder=2.5))

    # --- Conexión -----------------------------------------------------------
    y = top - hb - 0.1
    rbox(ax, 0.12, y - 0.36, 3.95, y, "neu", "fill", r=0.05)
    btext(ax, xm + 0.03, y - 0.18, "Emparejamiento (una sola vez)",
          "Ajustes Bluetooth de Android → «HapticRV»")
    y -= 0.58
    msg(y, "Conexión RFCOMM / SPP", "u2e", cu,
        "la app abre el puerto serie con «HapticRV»", mono=False)
    y -= 0.4
    msg(y, "H,HapticRV,1.2", "e2u", ce, "saludo al conectar")

    # --- Flujo periódico ------------------------------------------------------
    y -= 0.25
    f1 = y
    y -= 0.4
    msg(y, "D,seq,p,r,b,mV,jx,jy", "e2u", ce,
        "ej.: D,1532,1250,-340,0,0,120,-870")
    y -= 0.21
    frame(f1, y, "loop  cada 20 ms (50 Hz)")

    # --- Ping ---------------------------------------------------------------
    y -= 0.07
    f2 = y
    y -= 0.4
    ya = y
    msg(y, "P,17", "u2e", cu)
    label(ax, xu + 0.08, y, "$t_0$", ha="left", color=INK)
    y -= 0.32
    msg(y, "P,17", "e2u", ce, "RTT = $t_1 - t_0$ ;  latencia ≈ RTT / 2")
    label(ax, xu + 0.08, y, "$t_1$", ha="left", color=INK)
    activation(ya, y)
    y -= 0.21
    frame(f2, y, "loop  cada 1 s (latencia)")

    # --- Eventos (marcos anchos, notas a la derecha de Unity) ----------------
    xr = 6.45
    y -= 0.07
    f3 = y
    y -= 0.4
    msg(y, "V,2,255", "u2e", cu,
        "patrón 2 PARED: pulso de 250 ms\nque Unity renueva cada 0,1 s", side=True)
    activation(y, y - 0.16)
    y -= 0.2
    frame(f3, y, "evento  el robot choca con una pared u obstáculo", xr)

    y -= 0.07
    f4 = y
    y -= 0.4
    msg(y, "V,3,180", "u2e", cu, "patrón 3 AGARRE: pulso de 150 ms\nintensidad 180",
        side=True)
    activation(y, y - 0.1)
    y -= 0.2
    frame(f4, y, "evento  clic en el botón del joystick", xr)

    y -= 0.07
    f5 = y
    y -= 0.4
    ya = y
    msg(y, "C", "u2e", cu, "toma la inclinación actual como cero", side=True)
    y -= 0.32
    msg(y, "K,offPitch,offRoll", "e2u", ce, "offsets ×100, guardados en NVS",
        side=True)
    activation(ya, y)
    y -= 0.12
    frame(f5, y, "evento  mantener el botón del joystick 2 s", xr)
    print("   (seq) y final =", round(y, 2))

    # ---------------- Tabla de formato de tramas
    tx0, tx1, tc = 4.2, 6.45, 5.28
    rows = [
        ("hdr", "ESP32 → Unity", None),
        ("r", "H,nombre,ver", "saludo"),
        ("r", "D,…,jx,jy", "datos, 50 Hz"),
        ("r", "P,id", "eco del ping"),
        ("r", "K,oP,oR", "tras C o G"),
        ("hdr", "Unity → ESP32", None),
        ("r", "V,patrón,int", "vibrar"),
        ("r", "P,id", "ping (RTT)"),
        ("r", "C", "fijar cero"),
        ("r", "G", "recalibrar giro"),
    ]
    rh = 0.235
    ty = top - 0.2
    label(ax, (tx0 + tx1) / 2, ty + 0.04, "Formato de tramas (ASCII, fin \\n)",
          fs=9, color=INK, weight="bold", va="bottom")
    for i, (kind, a, b) in enumerate(rows):
        y1 = ty - i * rh
        y0 = y1 - rh
        if kind == "hdr":
            st = "ctrl" if a.startswith("ESP32") else "cel"
            ax.add_patch(Rectangle((tx0, y0), tx1 - tx0, rh, fc=PAL[st]["fill"],
                                   ec="#9A9A9A", lw=0.6, zorder=2))
            label(ax, (tx0 + tx1) / 2, (y0 + y1) / 2, a, color=INK,
                  weight="bold")
        else:
            ax.add_patch(Rectangle((tx0, y0), tx1 - tx0, rh, fc="white",
                                   ec="#9A9A9A", lw=0.6, zorder=2))
            ax.plot([tc, tc], [y0, y1], color="#9A9A9A", lw=0.6, zorder=3)
            label(ax, tx0 + 0.05, (y0 + y1) / 2, a, ha="left", color=INK,
                  mono=True)
            label(ax, tc + 0.05, (y0 + y1) / 2, b, ha="left", color=INK)
    yb = ty - len(rows) * rh - 0.08
    notes = ("D,seq,p,r,b,mV,jx,jy · seq: 0–65535\n"
             "p, r: grados ×100 · b: bit0 = botón\n"
             "mV: 0 (powerbank) · jx, jy: ±1000\n"
             "patrón: 0–3 · int: 0–255")
    label(ax, tx0, yb, notes, ha="left", va="top", color=MUTED, fs=9)

    save(fig, "diagrama_comunicacion.png")


# ===========================================================================
# 4. Mapeo de control y filtro complementario
# ===========================================================================
def f_map(theta, tz=5.0, tmax=35.0, g=1.5):
    x = np.clip((np.abs(theta) - tz) / (tmax - tz), 0.0, 1.0)
    return np.sign(theta) * x ** g


def diagrama_mapeo():
    Hf = 5.9
    fig = plt.figure(figsize=(W, Hf))

    def axin(x, y, w, h):          # posición en pulgadas
        return fig.add_axes([x / W, y / Hf, w / W, h / Hf])

    ax_f = axin(0.62, 3.2, 2.93, 1.85)
    ax_v = axin(4.35, 4.45, 2.05, 0.6)
    ax_w = axin(4.35, 3.2, 2.05, 0.6)
    ax_c = axin(0.62, 0.55, 5.78, 1.85)

    c1 = PAL["ctrl"]["edge"]    # γ = 1.5 (curva usada)
    c2 = "#C27012"              # γ = 1
    c3 = "#6E6E6E"              # umbral
    grid_kw = dict(color="#E2E2E2", lw=0.6)
    th = np.linspace(-45, 45, 1801)
    tz, tmax = 5.0, 35.0

    # Ecuación y parámetros (encabezado de la figura)
    fig.text(0.1 / W, 1 - 0.08 / Hf,
             r"$f(\theta)=\mathrm{signo}(\theta)\cdot\mathrm{clamp}"
             r"\left(\dfrac{|\theta|-\theta_z}{\theta_{max}-\theta_z},\,0,\,1\right)^{\gamma}$",
             ha="left", va="top", fontsize=10.5, color=INK)
    fig.text(3.9 / W, 1 - 0.1 / Hf,
             r"$\theta_z=5°,\ \theta_{max}=35°,\ \gamma=1.5$" "\n"
             r"$v=1.2\cdot f(\mathrm{pitch})$ m/s,  $\omega=90\cdot f(\mathrm{roll})$ °/s",
             ha="left", va="top", fontsize=9.5, color=INK, linespacing=1.5)

    def dead_zone(a):
        a.axvspan(-tz, tz, color="#E4E4E4", zorder=0, lw=0)
        for s in (-1, 1):
            a.axvspan(s * tmax, s * 45, color="#F2F2F2", zorder=0, lw=0)

    # (a) función de mapeo
    a = ax_f
    dead_zone(a)
    a.plot(th, np.where(np.abs(th) > tz, np.sign(th), 0.0), color=c3, lw=1.4,
           ls=(0, (4, 2)), label="Todo o nada", zorder=2)
    a.plot(th, f_map(th, g=1.0), color=c2, lw=1.6, ls=(0, (7, 2, 1.5, 2)),
           label="Lineal, γ = 1", zorder=3)
    a.plot(th, f_map(th, g=1.5), color=c1, lw=2.2, label="Usado, γ = 1.5",
           zorder=4)
    a.set_xlim(-45, 45)
    a.set_ylim(-1.15, 1.15)
    a.set_xticks([-45, -35, -20, -5, 5, 20, 35, 45])
    a.set_yticks([-1, -0.5, 0, 0.5, 1])
    a.set_xlabel("Inclinación θ (°)")
    a.set_ylabel("Salida normalizada f(θ)")
    a.set_title("(a) Función de mapeo", fontsize=10, loc="left",
                fontweight="bold")
    a.grid(True, **grid_kw)
    a.axhline(0, color="#9A9A9A", lw=0.8, zorder=1)
    a.annotate("zona muerta\n|θ| < 5°", xy=(1.5, -0.06), xytext=(20, -0.3),
               ha="center", va="center", fontsize=9, color=MUTED,
               arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=0.8,
                               mutation_scale=7, shrinkA=2, shrinkB=0))
    a.annotate("saturación\n|θ| ≥ 35°", xy=(39, -0.72), xytext=(20, -0.8),
               ha="center", va="center", fontsize=9, color=MUTED,
               arrowprops=dict(arrowstyle="-|>", color=MUTED, lw=0.8,
                               mutation_scale=7, shrinkA=2, shrinkB=0))
    a.legend(loc="upper left", fontsize=9, frameon=True, framealpha=1,
             edgecolor="#CCCCCC", handlelength=2.6)

    # (b) velocidad lineal, (c) velocidad angular
    for a, k, unit, ttl, eq in (
            (ax_v, 1.2, "v (m/s)", "(b) Velocidad lineal vs. pitch",
             "v = 1.2·f(pitch)"),
            (ax_w, 90.0, "ω (°/s)", "(c) Velocidad angular vs. roll",
             "ω = 90·f(roll)")):
        dead_zone(a)
        a.plot(th, k * f_map(th), color=c1, lw=2.0)
        a.set_xlim(-45, 45)
        a.set_ylim(-1.2 * k, 1.2 * k)
        a.set_yticks([-k, 0, k])
        a.set_yticklabels(["%g" % -k, "0", "%g" % k])
        a.set_xticks([-35, -5, 5, 35])
        a.set_ylabel(unit)
        a.set_title(ttl, fontsize=10, loc="left", fontweight="bold")
        a.grid(True, **grid_kw)
        a.axhline(0, color="#9A9A9A", lw=0.8, zorder=1)
        a.text(-42, 0.62 * k, eq, fontsize=9, color=INK, va="center")
    ax_v.set_xlabel("Pitch (°)")
    ax_w.set_xlabel("Roll (°)")

    # (d) filtro complementario con datos simulados
    rng = np.random.default_rng(7)
    dt, alpha = 0.01, 0.98
    t = np.arange(0, 10 + dt / 2, dt)
    true = np.zeros_like(t)
    true += 20 * np.clip((t - 1.0) / 1.0, 0, 1)                       # sube a 20°
    true -= 35 * np.clip((t - 3.5) / 1.5, 0, 1)                       # baja a −15°
    true += 15 * np.clip((t - 6.0) / 0.8, 0, 1)                       # vuelve a 0°
    true += 8 * np.sin(2 * np.pi * 0.8 * (t - 7.5)) * (t > 7.5)       # oscilación
    rate = np.gradient(true, dt)
    acc = true + rng.normal(0, 2.5, t.size)                           # ruido
    for tc_ in (2.6, 5.3, 8.8):                                       # sacudidas
        m = np.abs(t - tc_) < 0.15
        acc[m] += rng.normal(0, 8, m.sum())
    gyro = rate + 0.8 + rng.normal(0, 0.6, t.size)                    # sesgo 0.8 °/s
    ang_g = np.cumsum(gyro) * dt
    comp = np.zeros_like(t)
    for i in range(1, t.size):
        comp[i] = alpha * (comp[i - 1] + gyro[i] * dt) + (1 - alpha) * acc[i]

    a = ax_c
    a.plot(t, acc, color="#E3AE72", lw=0.8, label="Solo acelerómetro (ruidoso)",
           zorder=2)
    a.plot(t, ang_g, color=PAL["cel"]["edge"], lw=1.5, ls=(0, (5, 2)),
           label="Solo giroscopio integrado (deriva)", zorder=3)
    a.plot(t, comp, color=c1, lw=2.2, label="Filtro complementario, α = 0.98",
           zorder=4)
    a.plot(t, true, color="#111111", lw=1.1, ls=(0, (1, 1.6)),
           label="Ángulo real", zorder=5)
    a.set_xlim(0, 10)
    a.set_ylim(-30, 50)
    a.set_yticks([-30, -15, 0, 15, 30])
    a.set_xlabel("Tiempo (s)  —  datos simulados: ruido del acelerómetro σ = 2.5°, "
                 "sesgo del giroscopio 0.8 °/s")
    a.set_ylabel("Pitch (°)")
    a.set_title(r"(d) Filtro complementario: $\theta_k=\alpha\,(\theta_{k-1}+\omega\,dt)"
                r"+(1-\alpha)\,\theta_{acel}$,  dt = 0.01 s",
                fontsize=10, loc="left", fontweight="bold")
    a.grid(True, **grid_kw)
    a.legend(loc="upper right", fontsize=9, ncol=2, frameon=True,
             framealpha=1, edgecolor="#CCCCCC", columnspacing=1.5,
             handlelength=2.4, borderaxespad=0.3)
    for ax_ in (ax_f, ax_v, ax_w, ax_c):
        ax_.tick_params(labelsize=9)
        for s in ("top", "right"):
            ax_.spines[s].set_visible(False)

    save(fig, "diagrama_mapeo.png")


# ===========================================================================
# 5. Diagrama de flujo del firmware
# ===========================================================================
def stadium(ax, cx, cy, w, h, text, style="neu"):
    rbox(ax, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, style, "fill",
         r=h / 2 - 0.001, lw=1.2)
    btext(ax, cx, cy, text)


def pbox(ax, cx, cy, w, h, title, sub=None, style="ctrl"):
    rbox(ax, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, style, "fill",
         r=0.04)
    btext(ax, cx, cy, title, sub)


def diamond(ax, cx, cy, w, h, text, style="ctrl"):
    p = PAL[style]
    ax.add_patch(Polygon([(cx - w / 2, cy), (cx, cy + h / 2), (cx + w / 2, cy),
                          (cx, cy - h / 2)], closed=True, fc="white",
                         ec=p["edge"], lw=1.2, zorder=2))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=9, color=INK,
            zorder=5, linespacing=1.1)


def diagrama_flujo_firmware():
    H = 5.7
    fig, ax = canvas(H)
    c = PAL["ctrl"]["edge"]

    # ------------------------------------------------ setup()
    xs, ws = 1.1, 2.0
    label(ax, xs, H - 0.08, "setup()", fs=10, weight="bold", color=c,
          va="top", mono=True)
    steps = [
        ("stadium", "Encendido", None, 0.3),
        ("box", "Serial USB 115 200 baudios", "SW INPUT_PULLUP · centro joystick", 0.4),
        ("box", "LEDC del motor", "GPIO18 · 20 kHz · 8 bits", 0.4),
        ("box", "NVS (Preferences)", "abrir espacio «haptic»", 0.4),
        ("box", "I2C 400 kHz · MPU6050", "SDA 21 · SCL 22 · 0x68", 0.4),
        ("box", "Cero desde NVS", "offPitch, offRoll", 0.4),
        ("box", "Calibrar giroscopio", "control quieto → sesgo a NVS", 0.4),
        ("box", "BluetoothSerial", "begin(\"HapticRV\")", 0.4),
        ("box", "Toque de encendido", "patrón AGARRE", 0.4),
        ("stadium", "ir a loop()", None, 0.3),
    ]
    gap = 0.14
    y = H - 0.4
    prev_bottom = None
    for kind, t, s, h in steps:
        cy = y - h / 2
        if prev_bottom is not None:
            arrow(ax, [(xs, prev_bottom), (xs, cy + h / 2)], c)
        if kind == "stadium":
            stadium(ax, xs, cy, 1.3, h, t)
        else:
            pbox(ax, xs, cy, ws, h, t, s,
                 "ener" if t.startswith("Leer bat") else "ctrl")
        prev_bottom = cy - h / 2
        y = cy - h / 2 - gap

    # ------------------------------------------------ loop()
    xl = 3.35              # eje principal
    wd, hd = 1.9, 0.46     # rombos
    xa, wa = 5.5, 1.9      # cajas de acción (rama "sí")
    label(ax, xl, H - 0.08, "loop()", fs=10, weight="bold", color=c, va="top",
          mono=True)
    y_loop = H - 0.55
    stadium(ax, xl, y_loop, 1.5, 0.3, "inicio de loop()")
    cur = y_loop - 0.15
    blocks = [
        ("¿pasaron 10 ms?", "Leer MPU6050 (100 Hz)",
         "filtro complementario α = 0.98", 0.42),
        ("¿conexión nueva?", "Enviar H,HapticRV,1.2", None, 0.3),
        ("¿llegó una línea?", "Despachar comando",
         "V → iniciar patrón\nP → responder P,id\nC → cero, NVS, enviar K\n"
         "G → calibrar giro, enviar K", 0.86),
        ("¿pasaron 20 ms?", "Leer joystick · enviar D",
         "seq, pitch, roll, b, mV, jx, jy", 0.42),
        ("¿pasó 1 s?", "Batería", "powerbank: mV = 0", 0.42),
    ]
    for q, t, s, hbx in blocks:
        cy = cur - 0.14 - max(hd, hbx) / 2
        arrow(ax, [(xl, cur), (xl, cy + hd / 2)], c)
        diamond(ax, xl, cy, wd, hd, q)
        pbox(ax, xa, cy, wa, hbx, t, s,
             "ener" if t.startswith("Bater") else "ctrl")
        arrow(ax, [(xl + wd / 2, cy), (xa - wa / 2, cy)], c)
        label(ax, xl + wd / 2 + 0.04, cy + 0.03, "sí", ha="left", va="bottom",
              fs=9, color=INK, weight="bold")
        yj = min(cy - hd / 2, cy - hbx / 2) - 0.12
        # la rama "sí" regresa al eje principal
        ax.plot([xa, xa, xl + 0.35], [cy - hbx / 2, yj, yj], color=c, lw=1.2,
                zorder=3)
        ax.annotate("", xy=(xl + 0.03, yj), xytext=(xl + 0.36, yj),
                    arrowprops=dict(arrowstyle="-|>", color=c, lw=1.2,
                                    mutation_scale=9, shrinkA=0, shrinkB=0),
                    zorder=3)
        # rama "no"
        ax.plot([xl, xl], [cy - hd / 2, yj], color=c, lw=1.2, zorder=3)
        label(ax, xl - 0.06, cy - hd / 2 - 0.01, "no", ha="right", va="top",
              fs=9, color=INK, weight="bold")
        dot(ax, xl, yj, c)
        cur = yj
    # motor de patrones -> LED de estado (lado a lado)
    h = 0.42
    cy = cur - 0.14 - h / 2
    arrow(ax, [(xl, cur), (xl, cy + h / 2)], c)
    pbox(ax, xl, cy, wd, h, "Motor de patrones", "no bloqueante (millis)")
    pbox(ax, xa, cy, wa, h, "LED de estado", "espera · conectado · error")
    arrow(ax, [(xl + wd / 2, cy), (xa - wa / 2, cy)], c)
    # retorno al inicio de loop()
    xr = 2.28
    yr = cy - h / 2 - 0.13
    arrow(ax, [(xa, cy - h / 2), (xa, yr), (xr, yr), (xr, y_loop),
               (xl - 0.75, y_loop)], c)
    label(ax, xr + 0.05, (yr + y_loop) / 2, "repetir", ha="left", va="center",
          fs=9, color=MUTED, rotation=90)
    print("   (flujo) y final =", round(yr, 2), " setup y final =", round(y, 2))

    save(fig, "diagrama_flujo_firmware.png")


# ===========================================================================
if __name__ == "__main__":
    todos = {
        "1": diagrama_bloques,
        "2": diagrama_electrico,
        "3": diagrama_comunicacion,
        "4": diagrama_mapeo,
        "5": diagrama_flujo_firmware,
    }
    sel = sys.argv[1:] or sorted(todos)
    for k in sel:
        todos[k]()
