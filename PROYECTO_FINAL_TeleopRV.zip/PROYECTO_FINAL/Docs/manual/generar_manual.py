"""
Genera el manual de conexiones y puesta en marcha del control háptico (Word) con python-docx.
    python Docs/manual/generar_manual.py
Luego se exporta a PDF con Word (ver el final de este archivo). Los datos salen de Docs/ESPECIFICACION.md
y de Firmware/HapticController/config.h: si cambian los pines, actualizar aquí también.
"""
import os
import re

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(ROOT, "Docs", "manual", "Manual_de_conexiones.docx")
DIAG = os.path.join(ROOT, "Docs", "diagramas", "diagrama_electrico.png")
CAD_IMG = os.path.join(ROOT, "CAD", "SolidWorks", "imagenes", "Ensamblaje_sin_tapa.png")

BLUE = RGBColor(0x1F, 0x3A, 0x5F)
RED = RGBColor(0xB0, 0x1E, 0x1E)


def shade(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def runs(p, text, size=None):
    """**negrita**, *cursiva* (menús), `código` y !!aviso en rojo!!"""
    for part in re.split(r"(\*\*.+?\*\*|!!.+?!!|`[^`]+`|\*[^*]+\*)", text):
        if not part:
            continue
        if part.startswith("**"):
            r = p.add_run(part[2:-2]); r.bold = True
        elif part.startswith("!!"):
            r = p.add_run(part[2:-2]); r.bold = True; r.font.color.rgb = RED
        elif part.startswith("`"):
            r = p.add_run(part[1:-1]); r.font.name = "Consolas"
            r._element.rPr.rFonts.set(qn("w:eastAsia"), "Consolas")
        elif part.startswith("*"):
            r = p.add_run(part[1:-1]); r.italic = True
        else:
            r = p.add_run(part)
        if size:
            r.font.size = Pt(size)
    return p


def para(doc, text, after=6, style=None):
    p = doc.add_paragraph(style=style)
    runs(p, text)
    p.paragraph_format.space_after = Pt(after)
    return p


def bullets(doc, items, style="List Bullet"):
    for it in items:
        p = doc.add_paragraph(style=style)
        runs(p, it)
        p.paragraph_format.space_after = Pt(2)


def steps(doc, items):
    for i, it in enumerate(items, 1):
        p = doc.add_paragraph()
        runs(p, f"**{i}.** {it}")
        p.paragraph_format.left_indent = Cm(0.5)
        p.paragraph_format.space_after = Pt(3)


def table(doc, header, rows, widths, font=9.5, head_color="1F3A5F"):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(h)
        r.bold = True; r.font.size = Pt(font); r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        shade(c, head_color)
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            runs(cells[i].paragraphs[0], str(v), size=font)
    for row in t.rows:
        for i, w in enumerate(widths):
            row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)
    return t


def callout(doc, text, color="FDECEC"):
    t = doc.add_table(rows=1, cols=1)
    t.style = "Table Grid"
    c = t.rows[0].cells[0]
    c.text = ""
    runs(c.paragraphs[0], text, size=10)
    c.width = Cm(16.5)
    shade(c, color)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def image(doc, path, caption, width=16):
    if not os.path.exists(path):
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(path, width=Cm(width))
    p.paragraph_format.keep_with_next = True
    c = doc.add_paragraph()
    c.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = c.add_run(caption); r.italic = True; r.font.size = Pt(9)


def build():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    sec.left_margin = sec.right_margin = Cm(2.2)
    sec.top_margin, sec.bottom_margin = Cm(2), Cm(2)
    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    st.font.size = Pt(10.5)
    for lvl, size in ((1, 15), (2, 12)):
        h = doc.styles[f"Heading {lvl}"]
        h.font.name = "Arial"; h.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
        h.font.size = Pt(size); h.font.bold = True; h.font.color.rgb = BLUE
        h.paragraph_format.space_before = Pt(12 if lvl == 1 else 8)
        h.paragraph_format.space_after = Pt(4)
    fp = sec.footer.paragraphs[0]
    fp.text = "TeleopRV · Manual de conexiones del control háptico · UMNG Realidad Virtual"
    fp.runs[0].font.size = Pt(8); fp.runs[0].font.color.rgb = RGBColor(0x77, 0x77, 0x77)

    # ------------------------------------------------------------ portada breve
    p = doc.add_paragraph()
    r = p.add_run("Manual de conexiones y puesta en marcha")
    r.bold = True; r.font.size = Pt(22); r.font.color.rgb = BLUE
    p = doc.add_paragraph()
    r = p.add_run("Control háptico inalámbrico · Proyecto TeleopRV")
    r.font.size = Pt(13); r.font.color.rgb = RGBColor(0x55, 0x55, 0x55)
    para(doc, "Este manual explica cómo conectar el ESP32, el MPU6050, el joystick y el módulo vibrador, "
              "cómo cargar el programa, cómo comprobar que todo funciona y cómo enlazar el control con la "
              "aplicación de Unity (en el celular o en el computador). Firmware 1.2.", after=10)

    # ------------------------------------------------------------ 1 materiales
    doc.add_heading("1. Materiales", level=1)
    table(doc, ["Componente", "Cant.", "Nota"], [
        ("ESP32 DevKit (ESP32-WROOM-32 clásico)", "1", "Debe ser ESP32 clásico: los S2/S3/C3 no tienen Bluetooth Classic"),
        ("Shield expansora para ESP32 (filas G-V-S)", "1", "Con puente de selección 3.3 V / 5 V"),
        ("MPU6050 GY-521", "1", "Acelerómetro + giroscopio (mide la inclinación)"),
        ("Joystick HW-504 (o KY-023)", "1", "Dos ejes + botón al presionarlo"),
        ("Módulo motor vibrador (pines IN, VCC, GND)", "1", "Ya trae el transistor: no hace falta circuito extra"),
        ("Cables Dupont hembra-hembra", "≈ 14", "Sin soldar"),
        ("Powerbank USB 5000 mAh + cable USB corto", "1", "Alimentación del control ya armado"),
        ("Cable USB de datos (micro-USB o USB-C según la placa)", "1", "Para programar desde el PC"),
    ], [6.3, 1.2, 9.2])

    # ------------------------------------------------------------ 2 seguridad
    doc.add_heading("2. Antes de conectar", level=1)
    callout(doc,
            "!!Desconecta el USB y la powerbank mientras cableas.!!  "
            "**Pon el puente de la shield en 3.3 V** antes de conectar los módulos: así todas las filas V entregan "
            "3.3 V. !!Nunca alimentes el joystick con 5 V!!: su salida iría directo a las entradas analógicas del "
            "ESP32, que solo aguantan 3.3 V.")
    bullets(doc, [
        "En la shield cada GPIO tiene tres pines en fila: **G** (tierra), **V** (alimentación, 3.3 V con el puente) "
        "y **S** (señal). Cuando la tabla dice «G-V-S 21» significa «la fila del GPIO 21».",
        "Un módulo con varios pines usa **una sola fila** para G y V, y el resto de sus señales van solo a los pines "
        "**S** de los otros GPIO.",
        "El orden de pines de cada módulo casi nunca coincide con el orden G-V-S: conecta **por nombre**, no por posición.",
    ])

    # ------------------------------------------------------------ 3 diagrama
    doc.add_heading("3. Diagrama de conexiones", level=1)
    image(doc, DIAG, "Figura 1. Conexiones del control háptico sobre la shield expansora.", width=15.5)

    # ------------------------------------------------------------ 4 tablas
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
    doc.add_heading("4. Conexión pin por pin", level=1)

    doc.add_heading("4.1 MPU6050 (GY-521)", level=2)
    table(doc, ["Pin del MPU6050", "Pin de la shield", "Cable sugerido"], [
        ("VCC", "V de la fila 21", "Rojo"),
        ("GND", "G de la fila 21", "Negro"),
        ("SDA", "S 21", "Azul"),
        ("SCL", "S 22", "Amarillo"),
        ("XDA, XCL, AD0, INT", "Sin conectar", "—"),
    ], [5, 6, 5.7])
    para(doc, "AD0 sin conectar deja el sensor en la dirección 0x68 (la que usa el firmware). Móntalo **plano** y "
              "con sus ejes alineados con el control: el lado donde quede la «punta» define qué es inclinar hacia adelante.")

    doc.add_heading("4.2 Joystick HW-504", level=2)
    table(doc, ["Pin del joystick", "Pin de la shield", "Cable sugerido"], [
        ("GND", "G de la fila 32", "Negro"),
        ("+5V  (!!va a 3.3 V!!)", "V de la fila 32 (puente en 3.3 V)", "Rojo"),
        ("VRx", "S 32", "Verde"),
        ("VRy", "S 33", "Blanco"),
        ("SW", "S 25", "Morado"),
    ], [5, 6, 5.7])
    para(doc, "Los pines 32 y 33 son del ADC1, que funciona con el Bluetooth encendido (los del ADC2 no). "
              "**No toques el joystick al encender**: en ese momento el ESP32 mide su posición de reposo.")

    doc.add_heading("4.3 Módulo motor vibrador", level=2)
    table(doc, ["Pin del módulo", "Pin de la shield", "Cable sugerido"], [
        ("IN", "S 18", "Naranja"),
        ("VCC", "V de la fila 18", "Rojo"),
        ("GND", "G de la fila 18", "Negro"),
    ], [5, 6, 5.7])
    callout(doc, "!!Ojo con el orden!!: el módulo tiene los pines en orden **IN – VCC – GND**, al revés que la fila "
                 "**G – V – S** de la shield. Un cable «derecho» pondría GND en IN y la señal en GND. "
                 "Conéctalo cruzado: G→GND, V→VCC, S→IN.", color="FFF4DB")

    doc.add_heading("4.4 LED de estado (opcional)", level=2)
    para(doc, "El LED integrado de la placa (GPIO 2) ya indica el estado. Si quieres uno visible en la tapa: "
              "S 2 → resistencia de 330 Ω → ánodo (pata larga) del LED; cátodo → G.")
    table(doc, ["LED", "Significado"], [
        ("Parpadeo lento (1 por segundo)", "Encendido, esperando conexión Bluetooth"),
        ("Fijo", "Conectado a la app"),
        ("Parpadeo rápido", "Calibrando el giroscopio: no mover el control"),
        ("Doble destello repetido", "Error: el MPU6050 no responde (revisar SDA/SCL/VCC/GND)"),
    ], [6.5, 10.2])

    doc.add_heading("4.5 Resumen de pines", level=2)
    table(doc, ["GPIO", "Conexión", "GPIO", "Conexión"], [
        ("21", "MPU6050 SDA", "33", "Joystick VRy"),
        ("22", "MPU6050 SCL", "25", "Joystick SW (recolectar)"),
        ("32", "Joystick VRx", "18", "Vibrador IN"),
        ("V", "3.3 V (puente)", "2", "LED de estado"),
    ], [2, 6.3, 2, 6.4])

    # ------------------------------------------------------------ 5 alimentación
    doc.add_heading("5. Alimentación", level=1)
    bullets(doc, [
        "**Para programar o probar en el PC:** el cable USB del ESP32 al computador alimenta todo.",
        "**Control terminado:** cable USB corto de la powerbank a la entrada USB de 5 V de la shield (o al USB del ESP32). "
        "Conectar el cable enciende el control; desconectarlo lo apaga. La shield regula los 3.3 V de los módulos.",
        "El ESP32 no puede medir la carga de la powerbank: el HUD de la app no muestra batería; mira las luces de la powerbank.",
        "Consumo ≈ 110–150 mA con Bluetooth conectado: una powerbank de 5000 mAh dura muchas horas. Si se apaga sola "
        "por «carga baja», prueba con otro de sus puertos.",
    ])

    # ------------------------------------------------------------ 6 programar
    doc.add_heading("6. Cargar el programa (firmware)", level=1)
    para(doc, "Solo hay que hacerlo si el ESP32 es nuevo o si se cambia el programa. El firmware queda guardado en el ESP32.")
    steps(doc, [
        "Instala **Arduino IDE 2** y en *Herramientas → Placa → Gestor de placas* instala **esp32 by Espressif Systems** (versión 3.x).",
        "Abre `Firmware/HapticController/HapticController.ino` (los demás archivos de la carpeta se abren solos).",
        "Elige la placa **ESP32 Dev Module** y el puerto COM del ESP32 (*Herramientas → Puerto*). Si no aparece "
        "ningún puerto, instala el driver **CH340** o **CP2102** (según el chip USB de tu placa).",
        "Pulsa **Subir** (→). Si se queda en «Connecting…», mantén presionado el botón **BOOT** de la placa hasta que empiece a escribir.",
        "No hace falta instalar librerías: todo lo que usa viene con el paquete del ESP32.",
    ])

    # ------------------------------------------------------------ 7 verificar
    doc.add_heading("7. Verificar que todo funciona", level=1)
    para(doc, "Abre el **Monitor Serie** de Arduino a **115200 baudios**, con el fin de línea en **«Nueva línea»**, "
              "y pulsa el botón **EN/RST** de la placa con el control **quieto** sobre la mesa. Debe aparecer:")
    table(doc, ["Mensaje", "Qué significa"], [
        ("# MPU6050 detectado (WHO_AM_I=0x68 / 0x70 / 0x72 / 0x98)", "El sensor responde. Los clones dan valores distintos de 0x68 y funcionan igual"),
        ("# Giroscopio: sesgo … dispersión 0.07 °/s -> OK", "Calibración correcta. Si dice «rechazada», se movió: reinicia sin tocarlo"),
        ("# Bluetooth listo como \"HapticRV\"", "Ya se puede emparejar"),
        ("D,seq,pitch,roll,botón,0,joyX,joyY  (50 por segundo)", "Datos: ángulos en grados ×100 y joystick de −1000 a 1000"),
        ("# ERROR: no responde el MPU6050 + lista I2C", "Revisa SDA/SCL (quizás invertidos), VCC y GND. Si lista 0x69, conecta AD0 a GND"),
    ], [7.8, 8.9], font=9)
    para(doc, "**Prueba de signos** (mira los números de la línea D):")
    table(doc, ["Acción", "Debe dar", "Si sale al revés, en config.h cambia"], [
        ("Inclinar la punta hacia abajo", "pitch (3er número) positivo", "IMU_PITCH_SIGN"),
        ("Inclinar hacia la derecha", "roll (4º número) positivo", "IMU_ROLL_SIGN"),
        ("Joystick hacia adelante", "joyY (último) ≈ +1000", "JOY_Y_SIGN"),
        ("Joystick a la derecha", "joyX (penúltimo) ≈ +1000", "JOY_X_SIGN"),
        ("Presionar el joystick", "botón (5º número) = 1", "Revisar el cable SW → S 25"),
    ], [5.5, 5.4, 5.8], font=9)
    para(doc, "Con la placa montada en la protoboard del equipo ya se verificaron: IMU_PITCH_SIGN = −1, "
              "IMU_ROLL_SIGN = +1, JOY_X_SIGN = +1, JOY_Y_SIGN = +1. Si el montaje en la carcasa cambia la orientación, repite la prueba.")
    para(doc, "**Prueba del vibrador**: escribe en el Monitor Serie y pulsa Enter:")
    table(doc, ["Comando", "Debe hacer"], [
        ("T,2000", "Motor al 100 % durante 2 s (prueba de cableado)"),
        ("V,1,255", "Dos pulsos (choque con un objeto)"),
        ("V,2,255", "Un pulso de 250 ms (en la app se repite mientras el robot empuja una pared)"),
        ("V,3,255", "Un pulso (objeto recogido)"),
        ("C", "Toma la inclinación actual como cero"),
    ], [3.5, 13.2], font=9)
    para(doc, "Si T vibra pero los patrones casi no se sienten, revisa que `MOTOR_ON_3V3` en config.h coincida con el "
              "puente de la shield (1 = 3.3 V). Si vibra al revés (siempre encendido y se apaga con los comandos), "
              "pon `MOTOR_ACTIVE_LOW` en 1.")

    # ------------------------------------------------------------ 8 enlazar
    doc.add_heading("8. Enlazar el control con Unity", level=1)
    doc.add_heading("8.1 Con el celular (uso normal, visor Cardboard)", level=2)
    steps(doc, [
        "En el celular: *Ajustes → Bluetooth → buscar* **HapticRV** → emparejar (solo la primera vez).",
        "Instala la app: `Unity/TeleopRV/Builds/TeleopRV.apk` (activa «instalar apps de origen desconocido» si lo pide).",
        "Enciende el control, abre la app y acepta el permiso de **Dispositivos cercanos**.",
        "La app se conecta sola en unos segundos: el HUD dice **«Control: Bluetooth»** y el LED del ESP32 queda fijo.",
    ])
    doc.add_heading("8.2 Con Unity en el computador (pruebas en el editor)", level=2)
    steps(doc, [
        "Averigua el puerto COM: **por cable USB**, en *Administrador de dispositivos → Puertos (COM y LPT)* "
        "(p. ej. «USB-SERIAL CH340 (COM3)»); **por Bluetooth**, empareja HapticRV en Windows y mira en "
        "*Más opciones de Bluetooth → Puertos COM* el puerto **saliente** de HapticRV.",
        "En Unity: en la *Hierarchy* selecciona **Sistema** → componente **Haptic Link** → campo **Serial Port** → escribe el puerto (p. ej. `COM3`).",
        "Cierra el Monitor Serie de Arduino (el puerto solo lo puede usar un programa) y dale **Play**.",
        "El HUD debe decir **«Control: Serie COMx»** con la latencia. Si dice «Teclado (simulado)», revisa la pestaña *Console*.",
    ])
    callout(doc, "El Bluetooth del ESP32 acepta **una sola conexión a la vez**: si el celular está conectado, el PC no "
                 "podrá conectarse por Bluetooth (y al revés). Apaga el Bluetooth del que no uses.", color="EAF2FB")

    # ------------------------------------------------------------ 9 uso
    doc.add_heading("9. Cómo se usa el control", level=1)
    table(doc, ["Acción en el control", "Efecto en el entorno virtual"], [
        ("Inclinar hacia adelante / atrás", "El robot avanza / retrocede (más inclinación = más velocidad)"),
        ("Inclinar a la derecha / izquierda", "El robot gira"),
        ("Mover el joystick", "El avatar camina hacia donde mira el usuario (adelante/atrás y a los lados)"),
        ("Clic en el joystick", "Agarra el objeto resaltado en amarillo frente a la pinza; otro clic lo suelta"),
        ("Mantener el joystick presionado 2 s", "Recentra la vista y toma la posición actual del control como reposo"),
        ("Mantener el joystick presionado 5 s", "Reinicia la tarea"),
    ], [6.5, 10.2])
    table(doc, ["Vibración", "Cuándo"], [
        ("Sostenida al 100 %", "Mientras el robot (o el objeto que lleva, o el avatar) empuja una pared u obstáculo"),
        ("Dos pulsos", "El robot choca con un objeto manipulable"),
        ("Un pulso", "Se recoge un objeto (y al recentrar)"),
    ], [5, 11.7])
    para(doc, "Al encender, deja el control quieto 2 s (calibración) y el joystick sin tocar. Si al soltar el control el "
              "robot se sigue moviendo solo, mantén el joystick presionado 2 s con el control en la posición de reposo.")

    # ------------------------------------------------------------ 10 problemas
    doc.add_heading("10. Solución de problemas", level=1)
    table(doc, ["Síntoma", "Causa probable", "Solución"], [
        ("No aparece el puerto COM", "Falta el driver o el cable es solo de carga", "Instalar CH340/CP2102; probar otro cable"),
        ("«no responde el MPU6050»", "SDA/SCL invertidos o sueltos", "SDA → S 21, SCL → S 22; revisar VCC/GND"),
        ("Calibración «rechazada»", "El control se movió al encender", "Reiniciar (EN/RST) sin tocarlo"),
        ("Los ángulos derivan lentamente", "Calibración fallida o mala", "Reiniciar quieto; en la app mantener el botón 2 s"),
        ("Joystick marca ±1000 fijo", "Pin VRx/VRy suelto o al aire", "Revisar S 32 / S 33 y el cable +5V → V"),
        ("El avatar camina solo", "Se tocó el joystick al encender", "Reiniciar el ESP32 sin tocar el joystick"),
        ("No vibra", "Orden IN-VCC-GND cruzado mal", "Ver 4.3; probar con el comando T,2000"),
        ("El celular no se conecta", "Otro dispositivo ya está conectado, o falta el permiso", "Desconectar el PC; aceptar «Dispositivos cercanos»; volver a emparejar"),
        ("Unity dice «Teclado (simulado)»", "Puerto equivocado u ocupado", "Poner el COM correcto en Serial Port; cerrar el Monitor Serie"),
        ("El ESP32 se reinicia al vibrar", "La fuente no da suficiente corriente", "Usar otro puerto USB o la powerbank"),
    ], [4.8, 5.4, 6.5], font=8.5)

    # ------------------------------------------------------------ 11 montaje
    doc.add_heading("11. Montaje en la carcasa", level=1)
    para(doc, "La carcasa está en `CAD/SolidWorks` (STL listos en `CAD/SolidWorks/STL`). Orden de armado: powerbank en el "
              "compartimento inferior → shield con el ESP32 atrás, con los conectores hacia la ventana trasera → joystick al "
              "frente → MPU6050 plano en su marco (regleta hacia el joystick) → módulo vibrador contra la pared donde va la "
              "palma → tapa. Medidas a verificar y detalles de impresión: `CAD/README.md`.")
    image(doc, CAD_IMG, "Figura 2. Distribución de los componentes dentro de la carcasa (sin tapa).", width=13)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    doc.save(OUT)
    print("Manual generado:", OUT)


if __name__ == "__main__":
    build()
