// =====================================================================
//  Control háptico inalámbrico — Teleoperación de robot móvil en RV
//  UMNG · Realidad Virtual · Ingeniería Mecatrónica
//
//  Placa: ESP32 Dev Module (ESP32 clásico: necesita Bluetooth Classic)
//  Core:  esp32 by Espressif 3.x
//
//  Hardware: ESP32 DevKit en shield expansora, MPU6050 GY-521, joystick HW-504,
//  módulo motor vibrador y powerbank USB de 5000 mAh (ver Docs/ESPECIFICACION.md).
//  Envía Pitch/Roll, joystick, botón y batería a 50 Hz por Bluetooth SPP (y por USB)
//  y recibe comandos de vibración. Protocolo en Docs/ESPECIFICACION.md.
// =====================================================================
#include <BluetoothSerial.h>
#include <Preferences.h>
#include <Wire.h>
#include "config.h"
#include "Imu.h"
#include "Haptics.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error "Bluetooth no está habilitado. Usa un ESP32 clásico (no S2/S3/C3) y la placa 'ESP32 Dev Module'."
#endif

BluetoothSerial SerialBT;
Preferences prefs;
Imu imu;
Haptics haptics;

volatile bool btConnected = false;
volatile bool sendHello = false;
bool imuOk = false;
uint16_t seq = 0;
uint16_t batteryMv = 0;

enum LedMode { LED_WAITING, LED_CONNECTED, LED_CALIBRATING, LED_ERROR };
LedMode ledMode = LED_WAITING;

// ------------------------- Salida por ambos canales -------------------------
void sendLine(const char *line) {
  Serial.println(line);
  if (btConnected) SerialBT.println(line);
}

void btCallback(esp_spp_cb_event_t event, esp_spp_cb_param_t *param) {
  if (event == ESP_SPP_SRV_OPEN_EVT) {
    btConnected = true;
    sendHello = true;
  } else if (event == ESP_SPP_CLOSE_EVT) {
    btConnected = false;
    haptics.play(HP_STOP, 0);
  }
}

// ------------------------- Botones con antirrebote -------------------------
struct Button {
  uint8_t pin;
  bool stable = false;
  bool lastRead = false;
  uint32_t changedAt = 0;
  bool read() {
    bool pressed = digitalRead(pin) == LOW;
    if (pressed != lastRead) { lastRead = pressed; changedAt = millis(); }
    if (millis() - changedAt >= DEBOUNCE_MS) stable = lastRead;
    return stable;
  }
};
Button btnCollect{PIN_BTN_COLLECT};

uint8_t readButtons() {
  return btnCollect.read() ? 0x01 : 0x00;   // bit0 = RECOLECTAR
}

// ------------------------- Joystick analógico -------------------------
struct JoyAxis {
  uint8_t pin;
  int sign;
  int center = 2048;
  float value = 0;          // -1000..1000 filtrado

  void calibrate() {
    uint32_t acc = 0;
    for (int i = 0; i < 64; i++) { acc += analogRead(pin); delay(2); }
    center = acc / 64;
  }

  // Normaliza cada lado por separado: el centro del KY-023 casi nunca está en la mitad exacta del ADC
  int read() {
    int raw = analogRead(pin);
    float v;
    if (raw >= center) v = (float)(raw - center) / max(1, 4095 - JOY_EDGE_MARGIN - center);
    else               v = (float)(raw - center) / max(1, center - JOY_EDGE_MARGIN);
    v = constrain(v, -1.0f, 1.0f) * 1000.0f * sign;
    value += JOY_FILTER * (v - value);
    return (int)lroundf(value);
  }
};
JoyAxis joyX{PIN_JOY_X, JOY_X_SIGN}, joyY{PIN_JOY_Y, JOY_Y_SIGN};

void readJoystick(int &x, int &y) {
#if JOY_SWAP_XY
  x = joyY.read(); y = joyX.read();
#else
  x = joyX.read(); y = joyY.read();
#endif
}

// ------------------------- Batería -------------------------
void updateBattery() {
#if BATTERY_ENABLED
  uint32_t acc = 0;
  for (int i = 0; i < 8; i++) acc += analogReadMilliVolts(PIN_BATTERY);
  float mv = (acc / 8.0f) * BATTERY_DIVIDER;
  if (mv < BATTERY_MIN_VALID) { batteryMv = 0; return; }   // sin batería (alimentado por USB)
  batteryMv = batteryMv == 0 ? (uint16_t)mv : (uint16_t)(0.8f * batteryMv + 0.2f * mv);
#else
  batteryMv = 0;                                  // powerbank: no se puede medir su carga
#endif
}

// ------------------------- LED de estado -------------------------
void updateLed() {
  uint32_t t = millis();
  bool on;
  switch (ledMode) {
    case LED_CONNECTED:   on = !(batteryMv > 0 && batteryMv < BATTERY_LOW_MV && (t % 2000) < 150); break;
    case LED_CALIBRATING: on = (t / 80) % 2; break;
    case LED_ERROR:       on = (t % 600) < 100 || ((t % 600) > 200 && (t % 600) < 300); break;
    default:              on = (t % 1000) < 500; break;
  }
  digitalWrite(PIN_LED, on);
}

// ------------------------- Calibración -------------------------
void saveCalibration() {
  prefs.putFloat("gbx", imu.biasX());
  prefs.putFloat("gby", imu.biasY());
  prefs.putFloat("gbz", imu.biasZ());
  prefs.putFloat("offP", imu.offsetPitch());
  prefs.putFloat("offR", imu.offsetRoll());
}

void reportCalibration() {
  char buf[40];
  snprintf(buf, sizeof(buf), "K,%d,%d", (int)lroundf(imu.offsetPitch() * 100), (int)lroundf(imu.offsetRoll() * 100));
  sendLine(buf);
}

bool calibrateGyroWithLed() {
  LedMode prev = ledMode;
  ledMode = LED_CALIBRATING;
  bool ok = false;
  for (int attempt = 0; attempt < 3 && !ok; attempt++) {
    Serial.println("# Calibrando giroscopio: deja el control quieto...");
    ok = imu.calibrateGyro(400);
    const float *m = imu.lastCalibMean();
    Serial.printf("# Giroscopio: sesgo %.2f %.2f %.2f °/s, dispersión %.2f °/s -> %s\n",
                  m[0], m[1], m[2], imu.lastCalibStd(), ok ? "OK" : "rechazada (se movió)");
    updateLed();
  }
  ledMode = prev;
  return ok;
}

// ------------------------- Comandos entrantes -------------------------
void handleCommand(char *cmd) {
  switch (cmd[0]) {
    case 'V': {                                   // V,<patrón>,<intensidad>
      int pattern = 0, intensity = 255;
      sscanf(cmd, "V,%d,%d", &pattern, &intensity);
      haptics.play((uint8_t)constrain(pattern, 0, 3), (uint8_t)constrain(intensity, 0, 255));
      Serial.printf("# Vibración: patrón %d, intensidad %d\n", pattern, intensity);
      break;
    }
    case 'T': {                                   // T,<ms>: prueba del motor al 100 % (diagnóstico de cableado)
      int ms = 2000;
      sscanf(cmd, "T,%d", &ms);
      ms = constrain(ms, 50, 5000);
      Serial.printf("# Prueba de motor: GPIO%d al 100 %% durante %d ms\n", PIN_MOTOR, ms);
      haptics.play(HP_STOP, 0);
      motorWrite((1 << MOTOR_PWM_BITS) - 1);
      delay(ms);
      motorWrite(0);
      break;
    }
    case 'P': {                                   // P,<id>  -> eco inmediato para medir latencia
      sendLine(cmd);
      break;
    }
    case 'C':                                     // cero de inclinación
      imu.setLevelHere();
      saveCalibration();
      reportCalibration();
      haptics.play(HP_GRAB, 200);
      break;
    case 'G':                                     // recalibrar sesgo del giroscopio
      if (calibrateGyroWithLed()) saveCalibration();
      reportCalibration();
      break;
    default:
      break;
  }
}

void pollInput(Stream &in, char *buf, uint8_t &len) {
  while (in.available()) {
    char c = in.read();
    if (c == '\r') continue;
    if (c == '\n') {
      buf[len] = '\0';
      if (len > 0) handleCommand(buf);
      len = 0;
    } else if (len < 31) {
      buf[len++] = c;
    } else {
      len = 0;                                    // línea demasiado larga: descartar
    }
  }
}

// ------------------------- setup / loop -------------------------
void setup() {
  Serial.begin(USB_BAUD);
  pinMode(PIN_LED, OUTPUT);
  pinMode(PIN_BTN_COLLECT, INPUT_PULLUP);
#if BATTERY_ENABLED
  analogSetPinAttenuation(PIN_BATTERY, ADC_11db);
#endif
  analogSetPinAttenuation(PIN_JOY_X, ADC_11db);   // rango completo 0–3.3 V
  analogSetPinAttenuation(PIN_JOY_Y, ADC_11db);
  joyX.calibrate();                                // no tocar el joystick al encender
  joyY.calibrate();

  haptics.begin();
  prefs.begin("haptic", false);

  imuOk = imu.begin();
  if (imuOk) {
    Serial.printf("# MPU6050 detectado (WHO_AM_I=0x%02X)\n", imu.whoAmI());
    imu.setLevelOffsets(prefs.getFloat("offP", 0), prefs.getFloat("offR", 0));
    if (calibrateGyroWithLed()) {
      saveCalibration();
    } else {
      Serial.println("# Control en movimiento: se usa el sesgo guardado");
      imu.setBias(prefs.getFloat("gbx", 0), prefs.getFloat("gby", 0), prefs.getFloat("gbz", 0));
    }
  } else {
    Serial.println("# ERROR: no responde el MPU6050 (revisa SDA=21, SCL=22, 3V3, GND)");
    // Diagnóstico: listar lo que sí responde en el bus I2C
    int found = 0;
    for (uint8_t a = 1; a < 127; a++) {
      Wire.beginTransmission(a);
      if (Wire.endTransmission() == 0) { Serial.printf("# I2C: dispositivo en 0x%02X\n", a); found++; }
    }
    if (found == 0) Serial.println("# I2C: no hay ningún dispositivo (cables SDA/SCL sueltos o invertidos, o sin alimentación)");
    else Serial.println("# Si aparece 0x69, el pin AD0 del MPU6050 está en alto: conéctalo a GND");
    ledMode = LED_ERROR;
  }

  SerialBT.register_callback(btCallback);
  SerialBT.begin(BT_DEVICE_NAME);
  Serial.printf("# Bluetooth listo como \"%s\"\n", BT_DEVICE_NAME);

  updateBattery();
  haptics.play(HP_GRAB, 255);                     // toque de encendido
}

void loop() {
  static uint32_t lastImuUs = 0, lastSendMs = 0, lastBattMs = 0;
  static char usbBuf[32], btBuf[32];
  static uint8_t usbLen = 0, btLen = 0;

  uint32_t nowUs = micros();
  if (imuOk && nowUs - lastImuUs >= IMU_PERIOD_US) {
    lastImuUs = nowUs;
    if (!imu.update()) ledMode = LED_ERROR;
  }

  if (sendHello) {
    sendHello = false;
    sendLine("H," BT_DEVICE_NAME "," FW_VERSION);
    reportCalibration();
  }

  pollInput(Serial, usbBuf, usbLen);
  if (btConnected) pollInput(SerialBT, btBuf, btLen);

  uint32_t nowMs = millis();
  if (nowMs - lastSendMs >= SEND_PERIOD_MS) {
    lastSendMs = nowMs;
    int jx, jy;
    readJoystick(jx, jy);
    char line[64];
    snprintf(line, sizeof(line), "D,%u,%d,%d,%u,%u,%d,%d",
             seq++,
             (int)lroundf(imu.pitch() * 100),
             (int)lroundf(imu.roll() * 100),
             readButtons(),
             batteryMv,
             jx, jy);
    sendLine(line);
  }

  if (nowMs - lastBattMs >= 1000) {
    lastBattMs = nowMs;
    updateBattery();
  }

  if (ledMode != LED_ERROR && ledMode != LED_CALIBRATING)
    ledMode = btConnected ? LED_CONNECTED : LED_WAITING;

  haptics.update();
  updateLed();
}
