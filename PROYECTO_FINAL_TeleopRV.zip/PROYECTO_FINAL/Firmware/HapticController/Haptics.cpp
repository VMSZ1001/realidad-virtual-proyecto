#include "Haptics.h"
#include "config.h"

struct Step { float level; uint16_t ms; };   // level 0..1, duración en ms

// Tablas de patrones (ver sección 4 de la especificación)
// PARED es un pulso corto que Unity repite mientras dura el contacto: así la vibración es sostenida
// y se apaga sola unos 250 ms después de separarse de la pared.
static const Step PAT_OBJECT[] = { {1.0f, 120}, {0, 100}, {1.0f, 120} };   // dos pulsos
static const Step PAT_WALL[]   = { {1.0f, 250} };                          // sostenido (se renueva)
static const Step PAT_GRAB[]   = { {1.0f, 150} };                          // un pulso

static const Step *patternSteps(uint8_t p, uint8_t &count) {
  switch (p) {
    case HP_OBJECT: count = sizeof(PAT_OBJECT) / sizeof(Step); return PAT_OBJECT;
    case HP_WALL:   count = sizeof(PAT_WALL)   / sizeof(Step); return PAT_WALL;
    case HP_GRAB:   count = sizeof(PAT_GRAB)   / sizeof(Step); return PAT_GRAB;
    default:        count = 0; return nullptr;
  }
}

// Un patrón en curso solo lo interrumpe otro de igual o mayor prioridad
static uint8_t priority(uint8_t p) {
  switch (p) {
    case HP_WALL:   return 3;
    case HP_OBJECT: return 2;
    case HP_GRAB:   return 1;
    default:        return 0;
  }
}

void motorWrite(uint32_t duty) {
#if MOTOR_ACTIVE_LOW
  ledcWrite(PIN_MOTOR, ((1 << MOTOR_PWM_BITS) - 1) - duty);
#else
  ledcWrite(PIN_MOTOR, duty);
#endif
}

void Haptics::begin() {
  ledcAttach(PIN_MOTOR, MOTOR_PWM_FREQ, MOTOR_PWM_BITS);
  motorWrite(0);
}

void Haptics::setLevel(float level) {
  uint32_t duty = 0;
  if (level > 0.0f && intensity > 0) {
    float k = level * (intensity / 255.0f);
    duty = MOTOR_MIN_DUTY + (uint32_t)((MOTOR_MAX_DUTY - MOTOR_MIN_DUTY) * k);
  }
  targetDuty = duty;
  if (duty > 0 && !motorOn) {
    // Arranque: un pulso corto al 100 % vence la inercia del ERM; luego update() baja al nivel pedido
    kickUntil = millis() + MOTOR_KICK_MS;
    motorWrite((1 << MOTOR_PWM_BITS) - 1);
  } else if (kickUntil == 0 || duty == 0) {
    kickUntil = 0;
    motorWrite(duty);
  }
  motorOn = duty > 0;
}

void Haptics::play(uint8_t pattern, uint8_t newIntensity) {
  if (pattern == HP_STOP) {
    active = HP_STOP;
    setLevel(0);
    return;
  }
  uint8_t count;
  if (!patternSteps(pattern, count)) return;
  if (active != HP_STOP && priority(pattern) < priority(active)) return;

  active = pattern;
  intensity = newIntensity;
  step = 0;
  stepStart = millis();
  setLevel(patternSteps(pattern, count)[0].level);
}

void Haptics::update() {
  if (kickUntil != 0 && (int32_t)(millis() - kickUntil) >= 0) {
    kickUntil = 0;
    motorWrite(targetDuty);
  }
  if (active == HP_STOP) return;
  uint8_t count;
  const Step *steps = patternSteps(active, count);
  uint32_t now = millis();
  if (now - stepStart < steps[step].ms) return;

  step++;
  stepStart = now;
  if (step >= count) {
    active = HP_STOP;
    setLevel(0);
  } else {
    setLevel(steps[step].level);
  }
}
