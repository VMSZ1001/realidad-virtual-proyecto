// Motor de patrones de vibración no bloqueante (PWM por LEDC).
#pragma once
#include <Arduino.h>

enum HapticPattern : uint8_t {
  HP_STOP   = 0,
  HP_OBJECT = 1,   // choque con objeto manipulable: dos pulsos
  HP_WALL   = 2,   // contacto con pared/límite: sostenido mientras Unity lo renueve
  HP_GRAB   = 3,   // objeto recogido: un pulso
};

// Escribe el ciclo útil al pin del motor respetando MOTOR_ACTIVE_LOW
void motorWrite(uint32_t duty);

class Haptics {
public:
  void begin();
  void play(uint8_t pattern, uint8_t intensity);
  void update();                 // llamar en cada vuelta del loop
  bool busy() const { return active != HP_STOP; }

private:
  void setLevel(float level);    // 0..1 del rango útil del motor

  uint8_t active = HP_STOP;
  uint8_t intensity = 255;
  uint8_t step = 0;
  uint32_t stepStart = 0;
  bool motorOn = false;
  uint32_t kickUntil = 0;    // fin del pulso de arranque (0 = sin pulso activo)
  uint32_t targetDuty = 0;
};
