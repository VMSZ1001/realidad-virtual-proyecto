#include "Imu.h"
#include "config.h"
#include <Wire.h>

// Registros del MPU6050
static const uint8_t REG_SMPLRT_DIV   = 0x19;
static const uint8_t REG_CONFIG       = 0x1A;
static const uint8_t REG_GYRO_CONFIG  = 0x1B;
static const uint8_t REG_ACCEL_CONFIG = 0x1C;
static const uint8_t REG_ACCEL_XOUT_H = 0x3B;
static const uint8_t REG_PWR_MGMT_1   = 0x6B;
static const uint8_t REG_WHO_AM_I     = 0x75;

static const float ACC_LSB_PER_G    = 8192.0f;  // ±4 g
static const float GYRO_LSB_PER_DPS = 65.5f;    // ±500 °/s

void Imu::writeReg(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(reg);
  Wire.write(val);
  Wire.endTransmission();
}

bool Imu::begin() {
  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);

  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_WHO_AM_I);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)1) != 1) return false;
  who = Wire.read();   // 0x68 en el original; algunos clones responden 0x70, 0x72 o 0x98

  writeReg(REG_PWR_MGMT_1, 0x01);    // despertar, reloj PLL del giroscopio X
  delay(50);
  writeReg(REG_SMPLRT_DIV, 0x00);    // 1 kHz con DLPF activo
  writeReg(REG_CONFIG, 0x03);        // DLPF ≈ 44 Hz: quita ruido de vibración del motor
  writeReg(REG_GYRO_CONFIG, 0x08);   // ±500 °/s
  writeReg(REG_ACCEL_CONFIG, 0x08);  // ±4 g
  delay(20);
  first = true;
  return true;
}

bool Imu::readRaw(float &ax, float &ay, float &az, float &gx, float &gy, float &gz) {
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(REG_ACCEL_XOUT_H);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((uint8_t)MPU_ADDR, (uint8_t)14) != 14) return false;

  int16_t v[7];
  for (int i = 0; i < 7; i++) v[i] = (int16_t)((Wire.read() << 8) | Wire.read());

  float rax = v[0] / ACC_LSB_PER_G, ray = v[1] / ACC_LSB_PER_G;
  float rgx = v[4] / GYRO_LSB_PER_DPS, rgy = v[5] / GYRO_LSB_PER_DPS;
#if IMU_SWAP_XY
  ax = ray;  ay = -rax;  gx = rgy;  gy = -rgx;
#else
  ax = rax;  ay = ray;   gx = rgx;  gy = rgy;
#endif
  az = v[2] / ACC_LSB_PER_G;
  gz = v[6] / GYRO_LSB_PER_DPS;
  return true;
}

bool Imu::calibrateGyro(uint16_t samples) {
  double sx = 0, sy = 0, sz = 0, sxx = 0, syy = 0, szz = 0;
  uint16_t n = 0;
  float ax, ay, az, gx, gy, gz;
  for (uint16_t i = 0; i < samples; i++) {
    if (readRaw(ax, ay, az, gx, gy, gz)) {
      sx += gx; sy += gy; sz += gz;
      sxx += gx * gx; syy += gy * gy; szz += gz * gz;
      n++;
    }
    delay(5);
  }
  if (n < samples / 2) { lastStd = -1; return false; }
  float mx = sx / n, my = sy / n, mz = sz / n;
  float sdx = sqrtf(fmaxf(0, sxx / n - mx * mx));
  float sdy = sqrtf(fmaxf(0, syy / n - my * my));
  float sdz = sqrtf(fmaxf(0, szz / n - mz * mz));
  lastStd = fmaxf(sdx, fmaxf(sdy, sdz));
  lastMean[0] = mx; lastMean[1] = my; lastMean[2] = mz;
  if (lastStd > GYRO_STILL_STD) return false;   // dispersión alta: el control se estaba moviendo
  gbx = mx; gby = my; gbz = mz;
  first = true;
  return true;
}

void Imu::setLevelHere() {
  offPitch = rawPitch;
  offRoll = rawRoll;
}

bool Imu::update() {
  float ax, ay, az, gx, gy, gz;
  if (!readRaw(ax, ay, az, gx, gy, gz)) return false;
  gx -= gbx; gy -= gby;

  // Ángulos absolutos según la gravedad (ruidosos pero sin deriva)
  float accPitch = atan2f(-ax, sqrtf(ay * ay + az * az)) * RAD_TO_DEG;
  float accRoll  = atan2f(ay, az) * RAD_TO_DEG;

  uint32_t now = micros();
  if (first) {
    rawPitch = accPitch * IMU_PITCH_SIGN;
    rawRoll  = accRoll  * IMU_ROLL_SIGN;
    lastUs = now;
    first = false;
    return true;
  }
  float dt = (now - lastUs) * 1e-6f;
  lastUs = now;
  if (dt <= 0 || dt > 0.1f) dt = IMU_PERIOD_US * 1e-6f;

  // Si ‖a‖ se aleja de 1 g, el acelerómetro mide movimiento y no solo gravedad: confiar más en el giroscopio
  float norm = sqrtf(ax * ax + ay * ay + az * az);
  float alpha = fabsf(norm - 1.0f) > SHAKE_TOL_G ? COMP_ALPHA_SHAKE : COMP_ALPHA;

  // Filtro complementario: θ = α·(θ + ω·dt) + (1−α)·θ_acc
  rawPitch = alpha * (rawPitch + IMU_PITCH_SIGN * gy * dt) + (1.0f - alpha) * accPitch * IMU_PITCH_SIGN;
  rawRoll  = alpha * (rawRoll  + IMU_ROLL_SIGN  * gx * dt) + (1.0f - alpha) * accRoll  * IMU_ROLL_SIGN;
  return true;
}
