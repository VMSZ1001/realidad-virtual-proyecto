// Lectura del MPU6050 por registros y filtro complementario para Pitch y Roll.
#pragma once
#include <Arduino.h>

class Imu {
public:
  bool begin();
  // Promedia el giroscopio con el control quieto. Devuelve false si detecta movimiento.
  bool calibrateGyro(uint16_t samples = 400);
  // Toma la inclinación actual como el cero del control.
  void setLevelHere();
  void setBias(float bx, float by, float bz) { gbx = bx; gby = by; gbz = bz; }
  void setLevelOffsets(float p, float r) { offPitch = p; offRoll = r; }

  // Llamar a IMU_PERIOD_US. Devuelve false si la lectura I2C falló.
  bool update();

  float pitch() const { return rawPitch - offPitch; }   // grados, + = inclinado hacia adelante
  float roll()  const { return rawRoll  - offRoll;  }   // grados, + = inclinado a la derecha
  float offsetPitch() const { return offPitch; }
  float offsetRoll()  const { return offRoll;  }
  float biasX() const { return gbx; }
  float biasY() const { return gby; }
  float biasZ() const { return gbz; }
  uint8_t whoAmI() const { return who; }
  // Resultado de la última calibración: mayor desviación estándar (°/s) y promedio de cada eje
  float lastCalibStd() const { return lastStd; }
  const float *lastCalibMean() const { return lastMean; }

private:
  bool readRaw(float &ax, float &ay, float &az, float &gx, float &gy, float &gz);
  void writeReg(uint8_t reg, uint8_t val);

  float gbx = 0, gby = 0, gbz = 0;      // sesgo del giroscopio (°/s)
  float rawPitch = 0, rawRoll = 0;      // ángulos filtrados sin el cero
  float offPitch = 0, offRoll = 0;
  uint32_t lastUs = 0;
  bool first = true;
  uint8_t who = 0;
  float lastStd = 0;
  float lastMean[3] = {0, 0, 0};
};
