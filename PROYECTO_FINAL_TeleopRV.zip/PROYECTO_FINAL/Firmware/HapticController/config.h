// =====================================================================
//  Configuración del control háptico (ver Docs/ESPECIFICACION.md)
// =====================================================================
#pragma once

#define FW_VERSION        "1.2"
#define BT_DEVICE_NAME    "HapticRV"     // Nombre Bluetooth que busca la app de Unity

// ---------------- Pines ----------------
// Montaje con shield expansora: cada módulo va a la fila G-V-S de su GPIO, con el puente de la shield en 3.3 V.
#define PIN_SDA           21
#define PIN_SCL           22
#define PIN_JOY_X         32   // Joystick HW-504 VRx (ADC1)
#define PIN_JOY_Y         33   // Joystick HW-504 VRy (ADC1)
#define PIN_BTN_COLLECT   25   // Joystick SW: RECOLECTAR (presionar el joystick)
#define PIN_MOTOR         18   // Entrada IN del módulo vibrador (trae su propio transistor)
#define PIN_BATTERY       34   // Solo si BATTERY_ENABLED = 1 (divisor 100k/100k desde una LiPo)
#define PIN_LED           2    // LED integrado (y LED de 3 mm opcional en la tapa)

// ---------------- IMU (MPU6050) ----------------
#define MPU_ADDR          0x68
#define IMU_PERIOD_US     10000   // 100 Hz de lectura y filtrado
#define COMP_ALPHA        0.98f   // Filtro complementario: peso del giroscopio
#define COMP_ALPHA_SHAKE  0.995f  // Peso cuando el acelerómetro no es confiable (sacudidas)
#define SHAKE_TOL_G       0.15f   // |‖a‖ - 1 g| por encima de esto = sacudida
#define GYRO_STILL_STD    1.5f    // °/s: dispersión máxima para aceptar la calibración del giroscopio

// Orientación del MPU6050 dentro de la carcasa.
// Por defecto: eje X del módulo hacia la punta del control, Y hacia la izquierda, Z hacia arriba.
// Si al inclinar el control hacia adelante el pitch sale negativo, cambia el signo aquí.
#define IMU_SWAP_XY       0       // 1 = el módulo está girado 90° (X a lo ancho)
#define IMU_PITCH_SIGN    (-1)    // verificado en la protoboard: adelante daba negativo
#define IMU_ROLL_SIGN     (+1)

// ---------------- Envío de datos ----------------
#define SEND_PERIOD_MS    20      // 50 Hz
#define USB_BAUD          115200  // También se envían los datos por USB (útil para pruebas en el PC)

// ---------------- Motor vibrador ----------------
#define MOTOR_PWM_FREQ    20000   // 20 kHz: fuera del rango audible
#define MOTOR_PWM_BITS    8
// Alimentación del módulo vibrador (pin VCC): 1 = 3.3 V (puente de la shield en 3.3 V, recomendado);
// 0 = 5 V (puente en 5 V): se limita el ciclo útil para no pasar de ≈3.3 V promedio en el motor de 3 V
#define MOTOR_ON_3V3      1
#define MOTOR_ACTIVE_LOW  0       // 1 si el módulo vibra con IN en bajo (algunos clones)
#if MOTOR_ON_3V3
#define MOTOR_MIN_DUTY    150     // con 3.3 V hace falta más ciclo útil para que arranque
#define MOTOR_MAX_DUTY    255
#else
#define MOTOR_MIN_DUTY    80      // Por debajo de esto un ERM de moneda no arranca
#define MOTOR_MAX_DUTY    170     // 67 % de 5 V -> ≈3.3 V promedio
#endif
#define MOTOR_KICK_MS     25      // pulso al 100 % al encender, para vencer la inercia del motor

// ---------------- Joystick (KY-023 alimentado a 3V3) ----------------
// Si al empujar el joystick hacia adelante joyY sale negativo, cambia el signo; igual para X (derecha = +).
#define JOY_SWAP_XY       0       // 1 = el módulo quedó girado 90° en la carcasa
#define JOY_X_SIGN        (+1)
#define JOY_Y_SIGN        (+1)    // verificado: con este montaje VRy sube al empujar hacia adelante
#define JOY_FILTER        0.35f   // filtro exponencial contra el ruido del ADC (0..1, 1 = sin filtro)
#define JOY_EDGE_MARGIN   60      // cuentas del ADC que se descartan en los extremos para llegar a ±1000

// ---------------- Botón y batería ----------------
#define DEBOUNCE_MS       20
// El control se alimenta con una powerbank USB de 5000 mAh: el ESP32 no puede medir su carga
// (la powerbank entrega 5 V fijos) y se envía bat_mV = 0. Poner 1 solo si se vuelve a usar una LiPo con divisor.
#define BATTERY_ENABLED   0
#define BATTERY_DIVIDER   2.0f    // 100k/100k
#define BATTERY_LOW_MV    3450
#define BATTERY_MIN_VALID 2500    // por debajo: no hay batería conectada (alimentado por USB) -> se envía 0
