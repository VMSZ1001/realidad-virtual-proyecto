"""
Genera Informe/Informe_Tecnico_TeleopRV.docx con python-docx.

Los datos del equipo y los resultados medidos se llenan en DATOS (abajo) y se vuelve a ejecutar:
    python Informe/generar_informe.py
Si existe Docs/analisis/resultados/*.png (salida de analizar_metricas.py), esas gráficas se insertan.
Todo lo que falta medir aparece resaltado en amarillo como [COMPLETAR ...].
"""
import os

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_COLOR_INDEX
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIAG = os.path.join(ROOT, "Docs", "diagramas")
RES = os.path.join(ROOT, "Docs", "analisis", "resultados")
CAD = os.path.join(ROOT, "CAD")
OUT = os.path.join(ROOT, "Informe", "Informe_Tecnico_TeleopRV.docx")

# ----------------------------------------------------------------------------- datos del equipo
DATOS = {
    "integrantes": ["[COMPLETAR: Nombre 1 – código]", "[COMPLETAR: Nombre 2 – código]", "[COMPLETAR: Nombre 3 – código]"],
    "docente": "Ing. Byron Alfonso Pérez Gutiérrez",
    "fecha": "[COMPLETAR: fecha de entrega]",
    "video": "[COMPLETAR: enlace del video en YouTube]",
    "repositorio": "[COMPLETAR: enlace al repositorio o carpeta compartida]",
}

BLUE = RGBColor(0x1F, 0x3A, 0x5F)
fig_n = [0]
tab_n = [0]


# ----------------------------------------------------------------------------- utilidades
def set_cell_bg(cell, hex_color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), hex_color)
    tcPr.append(shd)


def add_runs(p, text):
    """Texto con **negrita** y [COMPLETAR ...] resaltado."""
    import re
    for part in re.split(r"(\*\*.+?\*\*|\[COMPLETAR[^\]]*\])", text):
        if not part:
            continue
        if part.startswith("**"):
            r = p.add_run(part[2:-2])
            r.bold = True
        elif part.startswith("[COMPLETAR"):
            r = p.add_run(part)
            r.font.highlight_color = WD_COLOR_INDEX.YELLOW
            r.bold = True
        else:
            p.add_run(part)
    return p


def para(doc, text, style=None, align=None, space_after=6):
    p = doc.add_paragraph(style=style)
    add_runs(p, text)
    p.paragraph_format.space_after = Pt(space_after)
    if align == "j":
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    elif align == "c":
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p


def bullets(doc, items, style="List Bullet"):
    for it in items:
        p = doc.add_paragraph(style=style)
        add_runs(p, it)
        p.paragraph_format.space_after = Pt(2)


def equation(doc, text, label=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    r.italic = True
    r.font.name = "Cambria Math"
    r.font.size = Pt(11)
    if label:
        p.add_run(f"      ({label})")
    p.paragraph_format.space_after = Pt(6)


def caption(doc, kind, text):
    if kind == "Figura":
        fig_n[0] += 1
        n = fig_n[0]
    else:
        tab_n[0] += 1
        n = tab_n[0]
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(f"{kind} {n}. ")
    r.bold = True
    r.font.size = Pt(9.5)
    r2 = p.add_run(text)
    r2.font.size = Pt(9.5)
    p.paragraph_format.space_after = Pt(10)
    return n


def figure(doc, path, text, width_cm=15.5):
    if os.path.exists(path):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(path, width=Cm(width_cm))
        p.paragraph_format.keep_with_next = True
    else:
        para(doc, f"[COMPLETAR: insertar figura – {os.path.basename(path)}]", align="c")
    return caption(doc, "Figura", text)


def table(doc, header, rows, widths_cm, title=None, font=9):
    if title:
        caption(doc, "Tabla", title)
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        r = c.paragraphs[0].add_run(h)
        r.bold = True
        r.font.size = Pt(font)
        r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        set_cell_bg(c, "1F3A5F")
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            add_runs(cells[i].paragraphs[0], str(v))
            for r in cells[i].paragraphs[0].runs:
                r.font.size = Pt(font)
    for row in t.rows:
        for i, w in enumerate(widths_cm):
            row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def page_number_field(paragraph):
    run = paragraph.add_run()
    for tag, text in (("begin", None), (None, "PAGE"), ("end", None)):
        if tag:
            el = OxmlElement("w:fldChar")
            el.set(qn("w:fldCharType"), tag)
        else:
            el = OxmlElement("w:instrText")
            el.set(qn("xml:space"), "preserve")
            el.text = text
        run._r.append(el)


def toc(doc):
    # Campo complejo marcado como "sucio": Word lo regenera al abrir o al actualizar campos
    p = doc.add_paragraph()

    def fld(kind):
        el = OxmlElement("w:fldChar")
        el.set(qn("w:fldCharType"), kind)
        if kind == "begin":
            el.set(qn("w:dirty"), "true")
        p.add_run()._r.append(el)

    fld("begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = 'TOC \\o "1-2" \\h \\z \\u'
    p.add_run()._r.append(instr)
    fld("separate")
    p.add_run("Clic derecho → Actualizar campo para generar la tabla de contenido.")
    fld("end")


# ----------------------------------------------------------------------------- documento
def build():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.59), Cm(27.94)
    for side in ("left_margin", "right_margin"):
        setattr(sec, side, Cm(2.5))
    sec.top_margin, sec.bottom_margin = Cm(2.5), Cm(2.2)

    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
    st.font.size = Pt(11)
    st.paragraph_format.line_spacing = 1.15
    for lvl, size in ((1, 14), (2, 12), (3, 11)):
        h = doc.styles[f"Heading {lvl}"]
        h.font.name = "Arial"
        h.element.rPr.rFonts.set(qn("w:eastAsia"), "Arial")
        h.font.size = Pt(size)
        h.font.bold = True
        h.font.color.rgb = BLUE
        h.paragraph_format.space_before = Pt(14 if lvl == 1 else 10)
        h.paragraph_format.space_after = Pt(6)

    # ------------------------------------------------------------------ portada
    for _ in range(3):
        doc.add_paragraph()
    p = para(doc, "UNIVERSIDAD MILITAR NUEVA GRANADA", align="c")
    p.runs[0].bold = True
    p.runs[0].font.size = Pt(16)
    para(doc, "Facultad de Ingeniería · Programa de Ingeniería Mecatrónica", align="c")
    para(doc, "Asignatura: Realidad Virtual · Semestre IX", align="c")
    for _ in range(3):
        doc.add_paragraph()
    p = para(doc, "Teleoperación de Robot Móvil en Entorno Virtual Inmersivo con Control Háptico Inalámbrico", align="c")
    p.runs[0].bold = True
    p.runs[0].font.size = Pt(18)
    p.runs[0].font.color.rgb = BLUE
    para(doc, "Informe técnico – Proyecto final de laboratorio", align="c")
    for _ in range(4):
        doc.add_paragraph()
    para(doc, "**Integrantes:**", align="c")
    for n in DATOS["integrantes"]:
        para(doc, n, align="c", space_after=2)
    doc.add_paragraph()
    para(doc, f"**Docente:** {DATOS['docente']}", align="c")
    para(doc, f"**Fecha:** {DATOS['fecha']}", align="c")
    para(doc, f"**Video demostrativo:** {DATOS['video']}", align="c")
    para(doc, "Bogotá D.C.", align="c")

    # encabezado y pie para el resto
    new = doc.add_section(WD_SECTION.NEW_PAGE)
    new.header.is_linked_to_previous = False
    new.footer.is_linked_to_previous = False
    hp = new.header.paragraphs[0]
    hp.text = "UMNG · Realidad Virtual · Teleoperación con control háptico"
    hp.runs[0].font.size = Pt(8.5)
    hp.runs[0].font.color.rgb = RGBColor(0x66, 0x66, 0x66)
    fp = new.footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    page_number_field(fp)
    doc.sections[0].header.paragraphs[0].text = ""

    p = doc.add_paragraph()   # no es un título, para que no aparezca dentro de la propia tabla
    r = p.add_run("Contenido")
    r.bold = True
    r.font.size = Pt(14)
    r.font.color.rgb = BLUE
    toc(doc)
    doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)

    # ------------------------------------------------------------------ resumen
    doc.add_heading("Resumen", level=1)
    para(doc,
         "Se diseñó e implementó un sistema de teleoperación inmersivo en el que un usuario, con un celular en un visor "
         "tipo Cardboard, controla un robot móvil de tracción diferencial dentro de una sala virtual desarrollada en Unity 6. "
         "El mando es un dispositivo inalámbrico propio basado en un ESP32 y una IMU MPU6050: la inclinación longitudinal "
         "(pitch) fija la velocidad lineal del robot y la lateral (roll) su velocidad angular, mediante un mapeo proporcional "
         "con zona muerta, curva exponencial y filtrado. Un gatillo permite agarrar objetos con la pinza del robot "
         "(unión física attach/detach), dos botones de pulgar desplazan al avatar en primera persona y un motor vibrador "
         "controlado por PWM reproduce patrones distintos para choques con objetos manipulables y con paredes u obstáculos, "
         "con intensidad proporcional a la velocidad de impacto. La comunicación usa Bluetooth Classic (SPP) a 50 Hz con un "
         "protocolo de texto que incluye un ping para medir la latencia de extremo a extremo. La aplicación registra métricas "
         "de latencia, pérdida de paquetes, colisiones y tiempo de tarea, que se analizan con un script propio. "
         "[COMPLETAR: resumir en 2–3 frases los resultados medidos (latencia media, tiempo de tarea, valoración háptica).]",
         align="j")
    para(doc, "**Palabras clave:** realidad virtual, teleoperación, háptica vibrotáctil, ESP32, IMU, Unity, Bluetooth.")

    # ------------------------------------------------------------------ 1 introducción
    doc.add_heading("1. Introducción", level=1)
    para(doc,
         "La teleoperación permite que una persona controle un sistema remoto —real o simulado— a través de dispositivos "
         "de entrada; cuando además el operador recibe información sensorial de lo que ocurre en el sitio remoto, mejora su "
         "percepción de la tarea y la sensación de control [3], [6]. La realidad virtual (RV) aporta el componente visual "
         "inmersivo: el operador ve el entorno desde un punto de vista coherente con el movimiento de su cabeza [1], [2]. "
         "La combinación de ambos con retroalimentación háptica es la base de aplicaciones como la cirugía robótica, la "
         "exploración remota y el entrenamiento por simulación.",
         align="j")
    para(doc,
         "Este proyecto integra en un sistema funcional: (i) un entorno virtual inmersivo en Unity con un robot móvil, "
         "obstáculos, objetos manipulables y límites físicos; (ii) un control háptico inalámbrico diseñado y fabricado por el "
         "equipo, con carcasa por manufactura aditiva; (iii) comunicación Bluetooth con un microcontrolador ESP32; y "
         "(iv) retroalimentación vibrotáctil diferenciada por tipo de colisión. El informe describe la arquitectura, el "
         "diseño eléctrico y mecánico, el protocolo de comunicación, el mapeo matemático del control y las pruebas "
         "propuestas para verificar cada requerimiento.",
         align="j")

    # ------------------------------------------------------------------ 2 objetivos
    doc.add_heading("2. Objetivos", level=1)
    doc.add_heading("2.1 Objetivo general", level=2)
    para(doc, "Diseñar e implementar un sistema de teleoperación inmersivo en realidad virtual que permita controlar un "
              "robot móvil mediante un dispositivo háptico inalámbrico desarrollado por los estudiantes.", align="j")
    doc.add_heading("2.2 Objetivos específicos", level=2)
    bullets(doc, [
        "Diseñar e implementar en Unity 3D un entorno virtual inmersivo con navegación en primera persona, límites físicos, "
        "robot móvil funcional y un sistema de interacción para manipular objetos.",
        "Diseñar y construir un dispositivo inalámbrico con microcontrolador, IMU, botón de agarre, botones de navegación, "
        "actuador vibrotáctil controlado por PWM, batería integrada y carcasa fabricada por manufactura aditiva.",
        "Implementar la comunicación Bluetooth entre el control y el entorno virtual y el mapeo de pitch y roll hacia las "
        "variables de movimiento del robot, con estabilidad y respuesta adecuada.",
        "Validar el sistema con pruebas de implementación que midan el cumplimiento de los requerimientos.",
    ], style="List Number")

    # ------------------------------------------------------------------ 3 requerimientos y arquitectura
    doc.add_heading("3. Requerimientos y arquitectura del sistema", level=1)
    para(doc, "A partir de la guía de laboratorio se definieron los requerimientos de la Tabla 1; cada uno tiene una prueba "
              "asociada en la sección 9.", align="j")
    reqs = [
        ("R1", "Entorno con obstáculos, objetos manipulables y límites que impidan salir del área"),
        ("R2", "Navegación del avatar en primera persona; adelante/atrás con botones del control"),
        ("R3", "Visualización estéreo en celular con giroscopio y visor Cardboard"),
        ("R4", "Robot: avance/retroceso con pitch y giro con roll"),
        ("R5", "Detección de colisiones del robot"),
        ("R6", "Agarre y liberación de objetos con un botón"),
        ("R7", "Control inalámbrico con ESP32 (Bluetooth) e IMU para pitch y roll"),
        ("R8", "Actuador vibrotáctil con PWM y patrones distintos: objeto vs. pared/límite"),
        ("R9", "Batería integrada y carcasa por manufactura aditiva"),
        ("R10", "Comunicación estable y de baja latencia; control suave y proporcional"),
    ]
    table(doc, ["ID", "Requerimiento"], reqs, [1.5, 14.5], "Requerimientos del sistema.")
    para(doc,
         "La Figura 1 resume la arquitectura. El control háptico lee la IMU por I2C a 100 Hz, estima pitch y roll con un "
         "filtro complementario y envía un paquete de estado a 50 Hz por Bluetooth SPP. El celular ejecuta la aplicación "
         "Unity, que interpreta los paquetes, mapea los ángulos a velocidades del robot, simula la física, detecta colisiones "
         "y devuelve comandos de vibración. La orientación de la cabeza proviene del giroscopio del propio celular (3DOF) y "
         "la imagen se genera en estéreo, una mitad de pantalla por ojo.",
         align="j")
    figure(doc, os.path.join(DIAG, "diagrama_bloques.png"), "Diagrama de bloques del sistema.")

    # ------------------------------------------------------------------ 4 entorno virtual
    doc.add_heading("4. Entorno virtual en Unity", level=1)
    para(doc,
         "El proyecto usa Unity 6 (6000.0.84f1) con el pipeline de render integrado y se compila para Android (IL2CPP, ARM64, "
         "API 26+). La escena completa se genera por código (menú TeleopRV → Construir escena), lo que hace reproducible el "
         "entorno y facilita ajustar su distribución. Sus elementos se listan en la Tabla 2.",
         align="j")
    table(doc, ["Elemento", "Implementación", "Función"], [
        ("Sala", "Piso 20 × 16 m, techo a 4 m, franjas emisivas como la Figura 1 de la guía", "Contexto visual y referencia de escala"),
        ("Límites físicos", "4 paredes de 3 m con BoxCollider y componente HapticSurface (Wall)", "Impiden salir del área; patrón PARED"),
        ("Obstáculos", "6 pilares azules y 2 bloques bajos (HapticSurface Obstacle)", "Exigen maniobrar; patrón PARED"),
        ("Objetos manipulables", "3 cubos rojos de 0,25 m y una esfera (Rigidbody 0,4 kg, Grabbable)", "Se empujan o se agarran; patrón OBJETO"),
        ("Zona de entrega", "Área verde de 2,4 × 2,4 m con trigger (DeliveryZone)", "Define la tarea de prueba"),
        ("Robot móvil", "Rigidbody 20 kg, BoxCollider, pinza con trigger y FixedJoint", "Robot teleoperado (R4–R6)"),
        ("Avatar", "CharacterController de 1,7 m; cabeza a 1,6 m con dos cámaras", "Punto de vista en primera persona (R2–R3)"),
        ("HUD", "Panel 3D que sigue la mirada con retraso", "Estado del enlace, latencia, pitch/roll, tarea"),
    ], [3.2, 7.3, 5.5], "Elementos del entorno virtual.")
    doc.add_heading("4.1 Visualización estéreo y navegación", level=2)
    para(doc,
         "CardboardRig crea dos cámaras separadas por la distancia interpupilar (64 mm), cada una en media pantalla con un "
         "campo de visión vertical de 80°. La orientación de la cabeza se obtiene del cuaternión del giroscopio de Android, "
         "convertido del sistema de mano derecha del sensor al de mano izquierda de Unity. Cada imagen se pre-distorsiona en "
         "barril (r' = r·(1 + k1·r² + k2·r⁴), con k1 = 0,22 y k2 = 0,10) mediante un shader, para compensar la distorsión en "
         "cojín de los lentes del visor. El avatar avanza o retrocede a 1,5 m/s en la dirección horizontal de la mirada "
         "mientras se mantiene el botón correspondiente; su CharacterController impide atravesar paredes y obstáculos, y "
         "al chocar caminando contra ellos también se envía el patrón PARED.",
         align="j")
    doc.add_heading("4.2 Robot, colisiones y agarre", level=2)
    para(doc,
         "El robot se modela como un cuerpo rígido con rotación libre solo en el eje vertical. En cada paso de física se "
         "impone la velocidad lineal en su eje longitudinal y la velocidad angular vertical calculadas en la sección 7; la "
         "gravedad y el solver de contactos de PhysX siguen actuando, de modo que el robot empuja los objetos livianos y se "
         "detiene contra las paredes sin atravesarlas (detección continua). El colisionador del chasis tiene un material de "
         "baja fricción para deslizarse a lo largo de las paredes en vez de trabarse.",
         align="j")
    para(doc,
         "En OnCollisionEnter se clasifica el otro cuerpo: si tiene el componente Grabbable se envía el patrón OBJETO; si "
         "tiene HapticSurface se envía PARED. El piso no dispara vibración. La intensidad se escala con la velocidad relativa "
         "del impacto y un tiempo mínimo de 0,2 s entre repeticiones evita que un mismo contacto genere ráfagas. La pinza "
         "detecta los objetos dentro de un trigger frontal y resalta el más cercano; al presionar el gatillo lo lleva al punto "
         "de agarre y crea un FixedJoint con el robot (attach), y al soltarlo destruye la unión (detach). Como el objeto sigue "
         "siendo dinámico, sus choques con las paredes mientras está sujeto también producen vibración.",
         align="j")

    # ------------------------------------------------------------------ 5 control háptico
    doc.add_heading("5. Diseño mecatrónico del control háptico", level=1)
    doc.add_heading("5.1 Selección de componentes", level=2)
    table(doc, ["Componente", "Selección", "Justificación"], [
        ("Microcontrolador", "ESP32 DevKit V1 (WROOM-32)", "Bluetooth Classic SPP integrado (las variantes S3/C3 solo tienen BLE), 240 MHz, PWM por hardware (LEDC)"),
        ("IMU", "MPU6050 (GY-521)", "Acelerómetro y giroscopio de 3 ejes, I2C, filtro pasa-bajos digital configurable, bajo costo"),
        ("Actuador", "Motor ERM de moneda 10 mm, 3 V", "Plano, fácil de alojar junto a la palma, respuesta suficiente para patrones de decenas de ms"),
        ("Driver", "2N2222 + 1N4148 + 100 nF", "El GPIO no entrega la corriente del motor (≈70 mA); el diodo absorbe la fuerza contraelectromotriz"),
        ("Energía", "LiPo 1000 mAh + TP4056 + MT3608 (5 V)", "Recargable por USB-C con protección; el elevador alimenta el pin VIN del ESP32"),
        ("Entradas", "3 pulsadores 12 × 12 mm", "Gatillo de agarre bajo el índice y dos botones de pulgar de forma distinta"),
    ], [3.0, 4.3, 8.7], "Componentes del control háptico.")
    doc.add_heading("5.2 Diagrama eléctrico", level=2)
    para(doc,
         "La Figura 2 muestra el esquema. Los botones usan las resistencias de pull-up internas (activos en bajo). El motor se "
         "alimenta de la batería conmutada a través del transistor, con la base excitada desde GPIO18 por 1 kΩ. Un divisor "
         "100 kΩ/100 kΩ lleva la tensión de batería al ADC (GPIO34) para mostrarla en el HUD y avisar con el LED cuando baja "
         "de 3,45 V.",
         align="j")
    figure(doc, os.path.join(DIAG, "diagrama_electrico.png"), "Diagrama eléctrico del control háptico.")
    doc.add_heading("5.3 Presupuesto de energía (estimado)", level=2)
    table(doc, ["Carga", "Corriente estimada", "Observación"], [
        ("ESP32 con Bluetooth Classic conectado", "≈ 110–130 mA a 3,3 V", "Dominante"),
        ("MPU6050", "≈ 4 mA", "Continuo"),
        ("Motor ERM", "≈ 70 mA pico, < 10 mA promedio", "Solo durante los patrones"),
        ("Total en la batería (eficiencia del MT3608 ≈ 85 % y regulador lineal de la placa)", "≈ 190–220 mA", "Autonomía ≈ 3,5–4 h con 80 % de 1000 mAh"),
    ], [7.0, 4.2, 4.8], "Consumo estimado. [COMPLETAR: medir la corriente real con un multímetro en serie con la batería.]")
    doc.add_heading("5.4 Carcasa por manufactura aditiva", level=2)
    para(doc,
         "La carcasa se modeló en OpenSCAD de forma paramétrica (CAD/carcasa_control.scad): base y tapa unidas con cuatro "
         "tornillos M3 × 30 avellanados, una bandeja separadora de 2 mm y los capuchones de los botones. Mide 160 × 50 × 36 mm "
         "con una cintura de agarre de 45 mm y aristas redondeadas de 5 mm; paredes de 2,2 mm con labio de encastre, "
         "imprimible sin soportes. Como los componentes suman unos 191 mm de largo, se distribuyen en dos niveles: el ESP32 "
         "en el piso del pomo trasero y, sobre la bandeja, el TP4056, el MT3608 y la batería. El MPU6050 va plano en el piso, "
         "en el centro del control (x = 80 mm), con flechas X+ e Y+ en relieve para orientarlo, de modo que el pitch "
         "corresponda a inclinar la punta y el roll a rotar sobre el eje largo. El centro de masa estimado (x ≈ 78 mm, "
         "≈ 138 g) queda dentro de la mano, junto a la IMU. El motor vibrador se aloja en un anillo contra la pared del lado "
         "de la palma. Los botones de pulgar son triángulos que apuntan en su dirección (ADELANTE con un punto en relieve) "
         "para distinguirlos al tacto, y el gatillo va bajo el índice. En la cara trasera quedan las ranuras del USB de "
         "programación y del USB-C de carga; el interruptor va en el costado y un LED externo de 3 mm, en paralelo con el "
         "LED de GPIO2, asoma por la tapa.",
         align="j")
    figure(doc, os.path.join(CAD, "plano_carcasa.png"), "Plano de la carcasa y ubicación de componentes.")
    para(doc, "[COMPLETAR: agregar render del ensamble (pieza = \"ensamble\" en OpenSCAD) y foto del control impreso y armado.]")

    # ------------------------------------------------------------------ 6 comunicación
    doc.add_heading("6. Comunicación", level=1)
    para(doc,
         "Se eligió Bluetooth Classic con el perfil de puerto serie (SPP/RFCOMM): el ESP32 lo soporta con la librería "
         "BluetoothSerial y en Android basta un socket RFCOMM hacia un dispositivo emparejado, sin gestionar servicios y "
         "características como en BLE. En la aplicación, un plugin Java (BtSpp.java) abre el socket en un hilo aparte, lee "
         "líneas y las entrega a Unity en bloque una vez por cuadro, lo que minimiza las llamadas JNI. El protocolo es de "
         "texto ASCII, una línea por mensaje (Tabla 5), fácil de depurar con un monitor serie.",
         align="j")
    table(doc, ["Sentido", "Mensaje", "Contenido"], [
        ("ESP32 → App", "D,seq,pitch×100,roll×100,botones,bat_mV", "Estado a 50 Hz; botones: bit0 agarre, bit1 adelante, bit2 atrás"),
        ("ESP32 → App", "H,HapticRV,1.0", "Saludo al conectarse"),
        ("ESP32 → App", "K,offPitch×100,offRoll×100", "Cero de calibración vigente"),
        ("App → ESP32", "V,patrón,intensidad", "0 parar, 1 objeto, 2 pared, 3 agarre; intensidad 0–255"),
        ("App ↔ ESP32", "P,id", "Ping cada 1 s; el ESP32 lo devuelve de inmediato → RTT"),
        ("App → ESP32", "C  /  G", "Poner en cero la inclinación / recalibrar el giroscopio"),
    ], [2.6, 5.6, 7.8], "Protocolo de comunicación.")
    figure(doc, os.path.join(DIAG, "diagrama_comunicacion.png"), "Diagrama de comunicación entre el control y la aplicación.")
    para(doc,
         "El número de secuencia permite contar paquetes perdidos. La latencia se estima como la mitad del tiempo de ida y "
         "vuelta del ping medido en la aplicación; incluye el enlace Bluetooth, el procesamiento del ESP32 y hasta un cuadro de "
         "espera en Unity (≈ 16 ms a 60 Hz), por lo que representa la latencia que realmente percibe el usuario.",
         align="j")

    # ------------------------------------------------------------------ 7 mapeo
    doc.add_heading("7. Mapeo matemático de control", level=1)
    doc.add_heading("7.1 Estimación de pitch y roll", level=2)
    para(doc, "Con el eje x del sensor hacia la punta del control, y hacia la izquierda y z hacia arriba, los ángulos según la "
              "gravedad medida por el acelerómetro son:", align="j")
    equation(doc, "θ_acc = atan2(−aₓ, √(a_y² + a_z²))        φ_acc = atan2(a_y, a_z)", "1")
    para(doc, "Estos valores no derivan pero son ruidosos y se alteran con las aceleraciones de la mano; el giroscopio es "
              "suave pero su integración deriva. El filtro complementario combina ambos [4]:", align="j")
    equation(doc, "θₖ = α·(θₖ₋₁ + ω_y·Δt) + (1 − α)·θ_acc        φₖ = α·(φₖ₋₁ + ω_x·Δt) + (1 − α)·φ_acc", "2")
    para(doc,
         "con Δt = 10 ms y α = 0,98, que equivale a un filtro pasa-altos sobre el giroscopio y pasa-bajos sobre el acelerómetro "
         "con constante de tiempo τ = α·Δt/(1 − α) ≈ 0,49 s. Si la norma de la aceleración se aleja más de 0,15 g de 1 g "
         "(sacudida), se usa α = 0,995 para confiar casi solo en el giroscopio. Además, el sesgo del giroscopio se estima al "
         "encender (promedio de 400 muestras con el control quieto) y el filtro pasa-bajos digital del MPU6050 se configura en "
         "44 Hz para atenuar la vibración del propio motor. El usuario puede fijar el cero en su postura cómoda (comando C).",
         align="j")
    doc.add_heading("7.2 Del ángulo a la velocidad del robot", level=2)
    para(doc, "Cada ángulo se convierte en un comando normalizado con zona muerta θz, saturación θmax y exponente γ:", align="j")
    equation(doc, "f(θ) = sgn(θ) · [ clamp( (|θ| − θz) / (θmax − θz), 0, 1 ) ]^γ", "3")
    equation(doc, "v* = v_max · f(θ_pitch)        ω* = ω_max · f(φ_roll)", "4")
    para(doc,
         "con θz = 5°, θmax = 35°, γ = 1,5, v_max = 1,2 m/s y ω_max = 90 °/s. La zona muerta absorbe el temblor de la mano y el "
         "ruido residual; γ > 1 da más resolución cerca del reposo para maniobras finas sin perder la velocidad máxima. Luego "
         "se aplica un filtro de primer orden discreto y un límite de aceleración (a_max = 3 m/s²):",
         align="j")
    equation(doc, "vₖ = vₖ₋₁ + (v* − vₖ₋₁)·(1 − e^(−Δt/τ)),   τ = 0,12 s", "5")
    para(doc, "Finalmente, la cinemática diferencial del robot (trocha b = 0,42 m, radio de rueda r = 0,09 m) da la "
              "velocidad de cada lado, usada para animar las ruedas:", align="j")
    equation(doc, "v_izq = v − ω·b/2      v_der = v + ω·b/2      ẋ = v·sin ψ,   ż = v·cos ψ,   ψ̇ = ω", "6")
    figure(doc, os.path.join(DIAG, "diagrama_mapeo.png"),
           "Función de mapeo (proporcional vs. umbral) y respuesta del filtro complementario.")
    doc.add_heading("7.3 Intensidad háptica", level=2)
    para(doc, "La intensidad enviada al control crece con la velocidad relativa del impacto |v_rel| y el firmware la traduce "
              "a ciclo útil respetando el mínimo de arranque del motor:", align="j")
    equation(doc, "I = I_min + (255 − I_min)·clamp(|v_rel| / 1,5 m/s, 0, 1),   I_min = 110", "7")
    equation(doc, "D = D_min + (D_max − D_min)·nivel·I/255,   D_min = 90/255,  D_max = 204/255 (80 %)", "8")
    table(doc, ["Patrón", "Evento", "Forma de onda"], [
        ("1 – OBJETO", "Robot choca con un objeto manipulable", "3 pulsos de 60 ms separados 60 ms, nivel 0,55"),
        ("2 – PARED", "Robot, objeto sujeto o avatar contra pared/obstáculo", "Pulso de 300 ms a nivel 1,0 y cola de 150 ms a 0,5"),
        ("3 – AGARRE", "Objeto sujetado o soltado, recentrado", "Toque de 40 ms a nivel 0,7"),
    ], [2.8, 6.0, 7.2], "Patrones de vibración (PWM a 20 kHz).")
    para(doc,
         "Los patrones se diferencian a la vez en ritmo (pulsos cortos repetidos frente a un pulso largo), duración total "
         "(300 ms frente a 450 ms) y amplitud, porque la resolución humana para distinguir amplitudes de vibración es "
         "limitada y el ritmo es la señal más fácil de reconocer [5]. La frecuencia PWM de 20 kHz queda fuera del rango "
         "audible. Un patrón en curso solo lo interrumpe otro de mayor o igual prioridad (PARED > OBJETO > AGARRE).",
         align="j")

    # ------------------------------------------------------------------ 8 firmware
    doc.add_heading("8. Firmware del ESP32", level=1)
    para(doc,
         "El firmware (Arduino, core ESP32 3.x) está dividido en módulos: Imu (lectura por registros del MPU6050 y filtro), "
         "Haptics (máquina de estados no bloqueante de patrones sobre LEDC) y el programa principal (botones con antirrebote "
         "de 20 ms, batería, LED de estado, protocolo y almacenamiento de la calibración en memoria no volátil con "
         "Preferences). El lazo principal no usa esperas: la IMU se atiende cada 10 ms, el envío cada 20 ms y los comandos "
         "entrantes en cada vuelta, lo que mantiene baja la latencia de respuesta a V y P. Los mismos mensajes se replican por "
         "USB, lo que permite probar el control con el monitor serie o con el editor de Unity sin Bluetooth. Compilado para "
         "ESP32 Dev Module ocupa 1,12 MB de flash (85 %) y 41 kB de RAM (12 %).",
         align="j")
    figure(doc, os.path.join(DIAG, "diagrama_flujo_firmware.png"), "Diagrama de flujo del firmware.", width_cm=13)

    # ------------------------------------------------------------------ 9 pruebas
    doc.add_heading("9. Pruebas de implementación", level=1)
    para(doc,
         "Para evidenciar el cumplimiento de cada requerimiento y en qué grado se cumple, se proponen las pruebas de la "
         "Tabla 8. Las métricas cuantitativas las registra la aplicación en archivos CSV y se procesan con "
         "Docs/analisis/analizar_metricas.py.",
         align="j")
    tests = [
        ("P1", "R1", "Conducir el robot y caminar con el avatar contra cada pared y obstáculo durante 2 min", "N.º de veces que se sale del área", "0", "[COMPLETAR]"),
        ("P2", "R2", "Recorrer la sala con los botones mirando en distintas direcciones", "Dirección correcta, sin atravesar objetos", "100 % de los intentos", "[COMPLETAR]"),
        ("P3", "R3", "Girar la cabeza 360° y volver al frente; medir la deriva de la vista en 5 min", "Deriva de yaw (°) y FPS", "< 10° en 5 min; ≥ 50 FPS", "[COMPLETAR]"),
        ("P4", "R4, R10", "Inclinar el control a ±10°, ±20°, ±35° y comparar v, ω medidas con la ecuación (4)", "Error de mapeo", "< 5 % del máximo", "[COMPLETAR]"),
        ("P5", "R10", "Control en reposo sobre la mesa y en la mano 60 s", "σ de pitch/roll; velocidad residual", "σ < 0,5°; v = 0", "[COMPLETAR]"),
        ("P6", "R5, R8", "20 choques contra paredes y 20 contra cubos; contar vibraciones recibidas", "% de choques con vibración correcta", "≥ 95 %", "[COMPLETAR]"),
        ("P7", "R8", "Prueba ciega: 5 usuarios, 20 vibraciones aleatorias cada uno, identificar el tipo", "% de identificación correcta", "≥ 85 %", "[COMPLETAR]"),
        ("P8", "R6", "10 agarres y liberaciones de cada cubo", "% de éxito; caídas involuntarias", "≥ 90 %; 0 caídas", "[COMPLETAR]"),
        ("P9", "R7, R10", "Sesión de 10 min a 1, 3 y 6 m del celular", "Latencia media y p95, tasa (Hz), pérdida (%)", "Media < 50 ms; p95 < 100 ms; ≥ 45 Hz; < 1 %", "[COMPLETAR]"),
        ("P10", "R9", "Uso continuo con la batería cargada hasta que el LED avise", "Autonomía (h); corriente (mA)", "≥ 2 h", "[COMPLETAR]"),
        ("P11", "Global", "Tarea: llevar los 3 cubos a la zona verde, 3 intentos por usuario, 5 usuarios", "Tiempo de tarea, colisiones", "Mejora entre intentos", "[COMPLETAR]"),
        ("P12", "Global", "Cuestionario SUS [7] y escala de calidad háptica (anexo A)", "Puntaje SUS (0–100); Likert 1–5", "SUS ≥ 68", "[COMPLETAR]"),
    ]
    table(doc, ["ID", "Req.", "Procedimiento", "Métrica", "Criterio", "Resultado"], tests,
          [1.0, 1.4, 5.8, 3.3, 2.7, 1.8], "Plan de pruebas de implementación.", font=8)

    # ------------------------------------------------------------------ 10 resultados
    doc.add_heading("10. Resultados experimentales", level=1)
    para(doc, "[COMPLETAR: ejecutar las pruebas, copiar la carpeta Metricas del celular y correr "
              "python Docs/analisis/analizar_metricas.py <carpeta> --salida Docs/analisis/resultados. "
              "Luego volver a generar este informe: las gráficas se insertan solas.]")
    doc.add_heading("10.1 Latencia y enlace", level=2)
    table(doc, ["Métrica", "1 m", "3 m", "6 m"], [
        ("Latencia media (ms)", "[COMPLETAR]", "[COMPLETAR]", "[COMPLETAR]"),
        ("Latencia p95 (ms)", "[COMPLETAR]", "[COMPLETAR]", "[COMPLETAR]"),
        ("Tasa de paquetes (Hz)", "[COMPLETAR]", "[COMPLETAR]", "[COMPLETAR]"),
        ("Pérdida de paquetes (%)", "[COMPLETAR]", "[COMPLETAR]", "[COMPLETAR]"),
    ], [6.0, 3.3, 3.3, 3.4], "Desempeño del enlace Bluetooth.")
    figure(doc, os.path.join(RES, "latencia.png"), "Distribución y evolución de la latencia medida.")
    doc.add_heading("10.2 Mapeo y estabilidad del control", level=2)
    figure(doc, os.path.join(RES, "control.png"), "Pitch/roll medidos frente a las velocidades del robot.")
    doc.add_heading("10.3 Tarea de manipulación", level=2)
    table(doc, ["Usuario", "Intento 1 (s / choques)", "Intento 2 (s / choques)", "Intento 3 (s / choques)"],
          [(f"U{i}", "[COMPLETAR]", "[COMPLETAR]", "[COMPLETAR]") for i in range(1, 6)],
          [2.5, 4.5, 4.5, 4.5], "Tiempo de tarea y colisiones por intento.")
    figure(doc, os.path.join(RES, "tareas.png"), "Tiempo de tarea y colisiones por intento.")
    doc.add_heading("10.4 Percepción háptica y usabilidad", level=2)
    table(doc, ["Métrica", "Resultado"], [
        ("Identificación correcta del patrón OBJETO (%)", "[COMPLETAR]"),
        ("Identificación correcta del patrón PARED (%)", "[COMPLETAR]"),
        ("Claridad de la vibración (Likert 1–5, media)", "[COMPLETAR]"),
        ("Utilidad de la vibración para la tarea (Likert 1–5)", "[COMPLETAR]"),
        ("Puntaje SUS (media ± desviación)", "[COMPLETAR]"),
        ("Mareo reportado (ninguno / leve / fuerte)", "[COMPLETAR]"),
    ], [10.0, 6.0], "Resultados de percepción y usabilidad.")

    # ------------------------------------------------------------------ 11 análisis
    doc.add_heading("11. Análisis", level=1)
    doc.add_heading("11.1 Implementación del sistema", level=2)
    para(doc,
         "El sistema cubre todos los requerimientos de la guía con componentes de bajo costo. Las decisiones de diseño con "
         "mayor impacto fueron: generar la escena por código (reproducible y fácil de ajustar), usar SPP en lugar de BLE "
         "(menos complejidad en Android), replicar el protocolo por USB (depuración sin Bluetooth) y mantener todo el lazo "
         "del firmware sin esperas. [COMPLETAR: dificultades encontradas durante el montaje y cómo se resolvieron.]",
         align="j")
    doc.add_heading("11.2 Calidad percibida de la retroalimentación háptica", level=2)
    para(doc, "[COMPLETAR con P6, P7 y P12: porcentaje de identificación de cada patrón, confusiones más frecuentes, "
              "comentarios de los usuarios. Discutir si la intensidad proporcional al impacto se percibió y si la posición "
              "del motor junto a la palma fue adecuada.]", align="j")
    doc.add_heading("11.3 Estabilidad del control", level=2)
    para(doc, "[COMPLETAR con P4, P5 y P9: ruido en reposo después del filtro, efecto de la zona muerta, oscilaciones o "
              "sobrepasos del robot, efecto de la latencia medida. Comparar el modo proporcional con el modo por umbral "
              "(RobotController → Mode = Threshold) en tiempo de tarea y colisiones.]", align="j")
    doc.add_heading("11.4 Facilidad de uso", level=2)
    para(doc, "[COMPLETAR con P11 y P12: curva de aprendizaje entre intentos, puntaje SUS, ergonomía del agarre, fatiga, "
              "mareo. Relacionar con el diseño de la carcasa.]", align="j")
    doc.add_heading("11.5 Propuestas de mejora", level=2)
    bullets(doc, [
        "Reemplazar el elevador MT3608 y el regulador lineal de la placa por un regulador LDO de baja caída (p. ej. ME6211) "
        "directo a 3,3 V: menos pérdidas y más autonomía.",
        "Usar una IMU con fusión en el propio sensor (BNO085) o un filtro de Madgwick/Mahony para reducir la deriva y liberar al "
        "microcontrolador.",
        "Sustituir el motor ERM por un actuador LRA o de bobina de voz, con respuesta más rápida y control independiente de "
        "frecuencia y amplitud, para patrones más ricos.",
        "Medir la latencia de extremo a extremo con marcas de tiempo sincronizadas en lugar de RTT/2 (el enlace no es simétrico).",
        "Usar el Cardboard XR Plugin oficial para aprovechar los parámetros del visor escaneados con código QR.",
        "Añadir retroalimentación de fuerza (gatillo con servo que ofrezca resistencia al agarrar).",
    ])

    # ------------------------------------------------------------------ 12 conclusiones
    doc.add_heading("12. Conclusiones", level=1)
    bullets(doc, [
        "Se integró un sistema completo de teleoperación inmersiva: entorno virtual en Unity visualizado en un Cardboard, "
        "robot móvil con agarre físico y un control háptico inalámbrico propio con retroalimentación vibrotáctil diferenciada.",
        "El mapeo con zona muerta, curva exponencial y filtro de primer orden convierte la inclinación de la mano en comandos "
        "suaves y proporcionales, y el filtro complementario entrega pitch y roll estables sin deriva apreciable. "
        "[COMPLETAR: citar el ruido en reposo y el error de mapeo medidos.]",
        "La latencia del enlace Bluetooth SPP [COMPLETAR: valor medido] es compatible con la teleoperación de un robot a "
        "velocidades moderadas; su efecto se percibe más en los giros rápidos que en el avance.",
        "Diferenciar los patrones por ritmo y duración, no solo por intensidad, permitió que los usuarios identificaran el "
        "tipo de colisión [COMPLETAR: % medido], lo que refuerza la percepción de eventos fuera del campo visual.",
        "El proyecto evidenció la importancia de un mapeo adecuado entre las variables biomecánicas del usuario y las del "
        "robot, y de la calibración y el filtrado para lograr una interacción estable.",
    ])

    # ------------------------------------------------------------------ 13 preguntas
    doc.add_heading("13. Preguntas para la discusión", level=1)
    qa = [
        ("¿Cómo afecta la latencia del Bluetooth a la percepción de control en tiempo real?",
         "La latencia desplaza en el tiempo la consecuencia de cada movimiento de la mano. Por debajo de unos 50 ms el usuario "
         "la percibe poco; al crecer aparecen sobrecorrecciones —sobre todo en giros— porque el operador corrige con información "
         "vieja y el lazo humano-robot se vuelve oscilatorio [3], [6]. También desincroniza la vibración del choque que se ve, lo "
         "que reduce la sensación de causalidad. Bluetooth Classic suma varios ms por el intervalo de conexión y el búfer del "
         "puerto serie, más el cuadro de Unity. Se mitiga con paquetes cortos, envío a tasa fija, lectura sin bloqueo, "
         "velocidades máximas moderadas y suavizado con constantes de tiempo pequeñas. [COMPLETAR: relacionar con la latencia medida.]"),
        ("¿Qué tipo de filtro es más adecuado para estabilizar la IMU en este tipo de aplicación?",
         "Un filtro de fusión: el complementario es la opción más simple y eficaz para pitch y roll, porque une la estabilidad "
         "a largo plazo del acelerómetro con la suavidad a corto plazo del giroscopio con un solo parámetro y muy poco cómputo. "
         "El filtro de Kalman (o las variantes Madgwick/Mahony con cuaterniones [4]) estima además el sesgo del giroscopio y "
         "maneja mejor aceleraciones sostenidas, a cambio de más ajuste. Un simple promedio o pasa-bajos sobre el acelerómetro "
         "no sirve: introduce retardo y sigue afectado por la aceleración de la mano. Para el yaw haría falta magnetómetro."),
        ("¿Qué ventajas tendría implementar control proporcional en lugar de control por umbrales?",
         "Con control por umbrales el robot va detenido o a velocidad fija, lo que dificulta las maniobras finas, produce "
         "arranques bruscos y más colisiones. El control proporcional da una relación continua entre la inclinación y la "
         "velocidad: el usuario dosifica la velocidad, aproxima objetos con precisión y el movimiento se siente natural. Con "
         "zona muerta y curva exponencial conserva la robustez al temblor que buscaba el umbral. El modo por umbral quedó "
         "implementado para compararlos experimentalmente."),
        ("¿Cómo cambiaría el diseño si el robot fuera físico y no virtual?",
         "Habría que cerrar el lazo con sensores reales (encoders, IMU del robot, sensores de contacto o de fuerza en la pinza) "
         "y la vibración dependería de colisiones medidas, no simuladas. Aparecen la dinámica de motores, el deslizamiento de "
         "las ruedas, la latencia de la red y el video, la seguridad (parada de emergencia, límites de velocidad, watchdog que "
         "detenga el robot si se pierde la comunicación) y la necesidad de un entorno virtual o gemelo digital sincronizado con "
         "el robot real. Con retardos grandes se usarían técnicas de teleoperación con retardo (control supervisado, "
         "predicción, variables de onda) [6]."),
        ("¿Qué variables influyen en la percepción diferenciada de vibraciones?",
         "La frecuencia y amplitud de la vibración (los corpúsculos de Pacini son más sensibles alrededor de 200–250 Hz), la "
         "duración y el ritmo de los pulsos, el tiempo de subida del actuador, la ubicación y la forma de acople del motor con "
         "la piel, la presión con que se sujeta el control, la adaptación del usuario a estímulos repetidos y la atención que "
         "demanda la tarea visual [5]. En un motor ERM frecuencia y amplitud están acopladas, por eso aquí se diferenció sobre "
         "todo por ritmo y duración."),
        ("¿Cómo se podría implementar retroalimentación háptica más rica (fuerza, no solo vibración)?",
         "Con actuadores que ejerzan fuerza: un gatillo motorizado (servo o motor con reductora) que ofrezca resistencia al "
         "cerrar la pinza según la rigidez del objeto; frenos o embragues magnetoreológicos; un joystick con motores de "
         "realimentación de fuerza; o exoesqueletos de mano. También se puede enriquecer la vibración con LRA o actuadores de "
         "bobina de voz, que reproducen texturas y transitorios, y con varios actuadores para dar dirección al choque."),
        ("¿Qué implicaciones tendría este sistema en aplicaciones médicas o industriales?",
         "En medicina serviría para entrenamiento quirúrgico o rehabilitación con retroalimentación táctil, pero exigiría "
         "latencias muy bajas y deterministas, fiabilidad, esterilización, certificación y validación clínica. En la industria "
         "permitiría operar robots en zonas peligrosas (inspección, manipulación de materiales), capacitar operarios en "
         "simulación sin riesgo y reducir costos; requeriría comunicación robusta, seguridad funcional y ergonomía para "
         "jornadas largas. En ambos casos la háptica reduce la carga visual y los errores de contacto."),
        ("¿Cómo se podría mejorar la inmersión del sistema?",
         "Con seguimiento de posición de la cabeza (6DOF, por ejemplo con Meta Quest 3), mayor tasa de cuadros y menor "
         "latencia de movimiento a imagen, sonido espacial más rico (ya hay sonido 3D de impacto), texturas e iluminación "
         "realistas, un modelo visual del control dentro de la escena que siga su orientación, retroalimentación háptica más "
         "variada y la representación del cuerpo del avatar."),
    ]
    for q, a in qa:
        p = doc.add_paragraph()
        r = p.add_run(q)
        r.bold = True
        p.paragraph_format.space_after = Pt(2)
        p.paragraph_format.keep_with_next = True
        para(doc, a, align="j", space_after=8)

    # ------------------------------------------------------------------ 14 video
    doc.add_heading("14. Video demostrativo", level=1)
    para(doc, f"Enlace: {DATOS['video']}")
    para(doc, "Guion sugerido (3–5 min): muestre en pantalla dividida la vista estéreo del celular y una cámara externa del usuario.")
    bullets(doc, [
        "Presentación del equipo y del control: interior, componentes, carga por USB-C.",
        "Encendido, calibración y conexión (LED fijo, HUD mostrando Bluetooth y latencia).",
        "Avatar caminando con los botones y recentrado de la vista.",
        "Robot: avance/retroceso con pitch y giro con roll, velocidad proporcional a la inclinación.",
        "Choque con un cubo y con una pared, con un micrófono cerca del control para que se oiga la vibración distinta.",
        "Agarre de un cubo, transporte y entrega en la zona verde; tarea completa con cronómetro.",
        "Resumen de métricas y cierre.",
    ])

    # ------------------------------------------------------------------ bibliografía
    doc.add_heading("15. Bibliografía", level=1)
    refs = [
        "[1] S. M. LaValle, Virtual Reality. Cambridge, U.K.: Cambridge University Press, 2023.",
        "[2] W. R. Sherman y A. B. Craig, Understanding Virtual Reality: Interface, Application, and Design, 2.ª ed. "
        "Cambridge, MA, USA: Morgan Kaufmann, 2018.",
        "[3] T. B. Sheridan, Telerobotics, Automation, and Human Supervisory Control. Cambridge, MA, USA: MIT Press, 1992.",
        "[4] R. Mahony, T. Hamel y J.-M. Pflimlin, \"Nonlinear complementary filters on the special orthogonal group,\" "
        "IEEE Trans. Autom. Control, vol. 53, no. 5, pp. 1203–1218, 2008.",
        "[5] S. Choi y K. J. Kuchenbecker, \"Vibrotactile display: Perception, technology, and applications,\" "
        "Proc. IEEE, vol. 101, no. 9, pp. 2093–2104, 2013.",
        "[6] P. F. Hokayem y M. W. Spong, \"Bilateral teleoperation: An historical survey,\" Automatica, vol. 42, no. 12, "
        "pp. 2035–2057, 2006.",
        "[7] J. Brooke, \"SUS: A 'quick and dirty' usability scale,\" en Usability Evaluation in Industry, P. W. Jordan et al., "
        "Eds. London, U.K.: Taylor & Francis, 1996, pp. 189–194.",
        "[8] InvenSense, MPU-6000 and MPU-6050 Product Specification, rev. 3.4, 2013.",
        "[9] Espressif Systems, ESP32 Technical Reference Manual y documentación de Arduino-ESP32 (LEDC, BluetoothSerial).",
        "[10] Unity Technologies, Unity 6 Manual: Physics, Rigidbody, Joints y Android plug-ins.",
    ]
    for r in refs:
        para(doc, r, space_after=3)

    # ------------------------------------------------------------------ anexo
    doc.add_heading("Anexo A. Cuestionario de calidad háptica y usabilidad", level=1)
    para(doc, "Escala de 1 (totalmente en desacuerdo) a 5 (totalmente de acuerdo), aplicada después de la tarea de prueba:")
    for i, item in enumerate([
        "La vibración se sintió claramente cada vez que el robot chocaba.",
        "Pude distinguir sin mirar si el robot chocó con un objeto o con una pared.",
        "La fuerza de la vibración correspondía a la fuerza del choque.",
        "La vibración me ayudó a completar la tarea.",
        "El control fue cómodo de sostener durante toda la prueba.",
        "Mover el robot inclinando el control fue intuitivo.",
    ], 1):
        p = para(doc, f"{i}. {item}      1  2  3  4  5", space_after=3)
        p.paragraph_format.left_indent = Cm(0.6)
    para(doc, "Después, aplicar los 10 ítems estándar del SUS [7] y preguntar por mareo (ninguno / leve / fuerte).")

    doc.save(OUT)
    print("Informe generado:", OUT)


if __name__ == "__main__":
    build()
