# Teleoperación de robot móvil en RV con control háptico inalámbrico

UMNG · Realidad Virtual · Ingeniería Mecatrónica · Semestre IX

Celular Android en un visor Cardboard muestra una sala virtual hecha en Unity. Un control de mano
(ESP32 en shield expansora + MPU6050, alimentado por una powerbank) teleopera un robot móvil: al inclinarlo hacia adelante o atrás (pitch) el robot avanza o
retrocede, y al inclinarlo a los lados (roll) gira. Un joystick en el control mueve
al avatar, su botón recolecta objetos y el motor vibra con un patrón distinto según el robot choque con un objeto o con una pared.

## Contenido

| Carpeta | Qué hay |
|---|---|
| `MANUAL_DE_CONEXIONES.pdf` | **Empieza aquí:** cómo conectar, programar, probar y enlazar el control con Unity |
| `Docs/ESPECIFICACION.md` | Referencia única: pines, protocolo Bluetooth, patrones de vibración, mapeo |
| `Firmware/HapticController/` | Programa del ESP32 (Arduino) |
| `Unity/TeleopRV/` | Proyecto Unity 6 (6000.0.84f1) — la escena se genera con un menú |
| `CAD/` | Carcasa en SolidWorks 2026 (piezas, ensamblaje, STL, STEP) generada por un script paramétrico |
| `Docs/diagramas/` | Diagrama de bloques, eléctrico, de comunicación, mapeo y flujo del firmware |
| `Docs/analisis/analizar_metricas.py` | Convierte los CSV de la app en gráficas y tablas para el informe |
| `Informe/` | Informe técnico (.docx) con los espacios para los resultados medidos |

## Relación con la guía

| Requisito de la guía | Dónde se cumple |
|---|---|
| Entorno con obstáculos, objetos manipulables y límites físicos | `SceneBuilder.cs`: 4 paredes con collider, 6 pilares, 2 bloques, 3 cubos + 1 esfera |
| Navegación en primera persona (**cambio:** con joystick en vez de botones) | `AvatarController.cs` (joystick relativo a la mirada, CharacterController) |
| Visualización con celular + Cardboard | `CardboardRig.cs` (estéreo, giroscopio 3DOF) + `StereoCompositor.cs` (corrección de lentes) |
| Robot: pitch → avance/retroceso, roll → giro | `RobotController.cs` + `ControlMapping.cs` (zona muerta, curva γ, filtro) |
| Detección de colisiones | `RobotController.OnCollisionEnter`, `Grabbable`, `HapticSurface` |
| Agarre con botón (attach/detach) — botón del joystick | `RobotGripper.cs` (clic agarra/suelta, FixedJoint) |
| ESP32 con Bluetooth, IMU pitch/roll | `Firmware/.../Imu.cpp` (filtro complementario) + `HapticController.ino` (SPP) |
| Botón de agarre y navegación (joystick) | Joystick HW-504: VRx GPIO32, VRy GPIO33, SW GPIO25 (`HapticController.ino`) |
| Actuador vibrotáctil con PWM y patrones diferenciados | `Haptics.cpp` (LEDC 20 kHz; patrones OBJETO, PARED, AGARRE) |
| Batería integrada, carcasa impresa | Powerbank 5000 mAh dentro de la carcasa; `Docs/diagramas/diagrama_electrico.png`, `CAD/SolidWorks/` |
| Validar latencia, sensibilidad, háptica | `HapticLink` (ping cada 1 s), `MetricsLogger` (CSV), `analizar_metricas.py` |

## Paso a paso

### 1. Firmware del ESP32

1. Arduino IDE → Placa: **ESP32 Dev Module** (core "esp32 by Espressif" 3.x; ya lo tienes instalado).
2. Abre `Firmware/HapticController/HapticController.ino` y súbelo. No necesita librerías externas.
3. Abre el Monitor Serie a 115200: debe aparecer `# MPU6050 detectado` y líneas `D,...` 50 veces por segundo.
4. Deja el control **quieto sobre la mesa** los primeros 2 s después de encenderlo (calibra el giroscopio;
   el LED parpadea rápido).
5. Verifica los signos: al inclinar la punta hacia abajo el tercer número (pitch×100) debe ser **positivo**;
   al inclinar a la derecha el cuarto (roll×100) debe ser positivo. Si no, cambia `IMU_PITCH_SIGN` /
   `IMU_ROLL_SIGN` (o `IMU_SWAP_XY` si montaste el módulo girado 90°) en `config.h`.
6. Puedes probar la vibración escribiendo en el Monitor Serie: `V,1,255`, `V,2,255`, `V,3,200`.

LED: parpadeo lento = esperando conexión · fijo = conectado · rápido = calibrando · doble destello = error de IMU.

### 2. Emparejar el celular

Ajustes de Android → Bluetooth → buscar **HapticRV** → emparejar. Solo se hace una vez.

### 3. Unity

1. Instala **Unity Hub**, inicia sesión y activa una licencia **Personal** (gratuita). El editor 6000.0.84f1
   con el módulo Android ya está instalado en este PC; agrégalo a Hub con *Installs → Locate*.
2. Hub → *Add project from disk* → `Unity/TeleopRV`.
3. En el menú superior **TeleopRV**:
   - **1. Configurar proyecto** (cambia a Android, IL2CPP, ARM64, orientación horizontal).
   - **2. Construir escena** (crea `Assets/Scenes/Teleoperacion.unity` con todo armado).
   - **3. Compilar APK** → `Unity/TeleopRV/Builds/TeleopRV.apk`.
   - **4. Capturas para el informe** → `Unity/TeleopRV/Capturas/` (primera persona, tercera persona, vista aérea).
   - Pruebas automáticas: *Window → General → Test Runner → PlayMode → Run All* (12 pruebas: avance/giro del
     robot, zona muerta, paredes, vibraciones, agarre con clic, joystick del avatar, recentrado y tarea).
4. Instala el APK en el celular (cable USB con *Build And Run*, o copiando el archivo).
5. Abre la app, acepta el permiso de **Dispositivos cercanos** y ponla en el visor.

Probar en el PC sin celular: dale Play en el editor. Controles de teclado: flechas = inclinar el control,
WASD = joystick (mover el avatar), Espacio = botón del joystick (clic agarra/suelta, mantener 2 s recentra, 5 s reinicia), botón derecho del mouse = mirar, C = recentrar,
R = reiniciar la tarea. Para usar el control real en el editor, escribe el puerto COM del ESP32 (USB o el
"vínculo serie Bluetooth" de Windows) en el campo **Serial Port** del componente `HapticLink` (objeto *Sistema*).

### 4. Uso

- **Joystick:** adelante/atrás y a los lados mueven al avatar según hacia dónde miras.
- **Clic en el joystick:** agarra el objeto resaltado en amarillo frente a la pinza; otro clic lo suelta.
- **Mantener el joystick presionado 2 s** con el control en posición de reposo: recentra la vista y pone el control en cero (el HUD muestra la cuenta regresiva).
- Tarea de prueba: llevar los 3 cubos rojos a la zona verde. El cronómetro arranca al mover el robot.
- **Mantenerlo 5 s** (o la tecla R) reinicia la tarea.

### 5. Métricas y análisis

La app guarda CSV en `Android/data/com.umng.teleoprv/files/Metricas` del celular. Cópialos al PC y ejecuta:

```bash
python Docs/analisis/analizar_metricas.py ruta/a/Metricas
```

Genera `resumen.md`, `latencia.png`, `control.png` y `tareas.png` para la sección de resultados del informe.

### 6. Carcasa

Está en SolidWorks: abre `CAD/SolidWorks/Control_TeleopRV.SLDASM`. Para imprimir usa
`CAD/SolidWorks/STL/Carcasa_Base.STL` (sobre el piso, soportes solo dentro del compartimento de la powerbank)
y `Carcasa_Tapa.STL` (boca abajo, sin soportes). Antes de imprimir mide la shield y los agujeros del joystick
y, si no coinciden, corrige el diccionario `P` de `CAD/SolidWorks/generar_control_sw.py` y vuelve a ejecutarlo.
Detalles en `CAD/README.md`.

### 7. Armado y conexiones

1. Pon el puente de la shield en **3.3 V** (las filas V quedan a 3.3 V).
2. Conecta con cables Dupont hembra-hembra a las filas G-V-S de la shield:
   MPU6050 → fila 21 (VCC, GND, SDA) + S de la 22 (SCL); joystick → fila 32 (+5V, GND, VRx) + S de la 33 (VRy)
   y S de la 25 (SW); módulo vibrador → fila 18 (G → GND, V → VCC, S → IN).
3. Atornilla la shield y el joystick a sus postes (M3 autorroscante), pega el MPU6050 en su cuna con cinta
   doble faz de espuma (regleta en L hacia el joystick, VCC hacia atrás; los Dupont pasan bajo el joystick) y mete el módulo vibrador en su riel contra la pared derecha.
4. Mete la powerbank por la cara trasera y únela con un cable USB corto a la entrada USB de la shield.
5. Cierra la tapa con 4 tornillos M3 × 25.

## Lista de materiales del control

| Componente | Cant. |
|---|---|
| ESP32 DevKit 30 pines (ESP32-WROOM-32, Bluetooth Classic) | 1 |
| Shield expansora para ESP32 de 30 pines (filas G-V-S, entrada USB 5 V) | 1 |
| Módulo MPU6050 (GY-521) | 1 |
| Joystick analógico HW-504 (2 ejes + pulsador) | 1 |
| Módulo motor vibrador (IN-VCC-GND, con transistor) | 1 |
| Powerbank 5000 mAh (99 × 61 × 15 mm) + cable USB corto (10–15 cm) | 1 |
| Cables Dupont hembra-hembra | ~13 |
| LED 3 mm + resistencia 330 Ω (opcional, en la tapa) | 1 |
| Tornillos M3 × 25 (tapa) y M3 × 6 autorroscantes (shield y joystick) | 4 + 8 |
| Cinta doble faz de espuma, silicona caliente | — |
| Filamento PLA/PETG (~70 g) | — |

## Pendiente para el equipo

- Verificar las medidas de la shield y del joystick, imprimir la carcasa, armar el control y hacer las pruebas con el sistema real.
- Actualizar el informe (`Informe/generar_informe.py`) con el hardware nuevo: aún describe la LiPo, el TP4056, los 3 botones y la carcasa en OpenSCAD.
- Llenar en el informe los resultados medidos (el informe **no** trae datos inventados).
- Grabar el video demostrativo y subirlo a YouTube (ver lista de tomas en el informe).
