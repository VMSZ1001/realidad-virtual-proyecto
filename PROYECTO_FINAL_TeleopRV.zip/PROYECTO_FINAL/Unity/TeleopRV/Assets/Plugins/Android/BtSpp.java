package com.umng.teleoprv;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Puente Bluetooth Classic (SPP) para Unity.
 * Se conecta a un dispositivo YA EMPAREJADO por nombre, lee líneas de texto en un hilo aparte
 * y las entrega a Unity en bloque con pollAll() (una sola llamada JNI por cuadro).
 */
public class BtSpp {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final ConcurrentLinkedQueue<String> lines = new ConcurrentLinkedQueue<>();
    private volatile BluetoothSocket socket;
    private volatile OutputStream out;
    private volatile boolean connected = false;
    private volatile boolean connecting = false;
    private volatile String status = "inactivo";

    public boolean isConnected() { return connected; }
    public boolean isConnecting() { return connecting; }
    public String getStatus() { return status; }

    public void connectAsync(final String deviceName) {
        if (connecting || connected) return;
        connecting = true;
        new Thread(new Runnable() {
            @Override public void run() { connect(deviceName); }
        }, "BtSppConnect").start();
    }

    private void connect(String deviceName) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null) { status = "sin-bluetooth"; return; }
            if (!adapter.isEnabled()) { status = "bluetooth-apagado"; return; }

            BluetoothDevice device = null;
            for (BluetoothDevice d : adapter.getBondedDevices()) {
                if (deviceName.equals(d.getName())) { device = d; break; }
            }
            if (device == null) { status = "no-emparejado"; return; }

            status = "conectando";
            adapter.cancelDiscovery();
            BluetoothSocket s = openSocket(device);
            socket = s;
            out = s.getOutputStream();
            connected = true;
            status = "conectado";
            readLoop(s);
        } catch (SecurityException e) {
            status = "sin-permiso";
        } catch (Exception e) {
            status = "error: " + e.getMessage();
        } finally {
            connecting = false;
            if (connected) close();
        }
    }

    private BluetoothSocket openSocket(BluetoothDevice device) throws Exception {
        try {
            BluetoothSocket s = device.createRfcommSocketToServiceRecord(SPP_UUID);
            s.connect();
            return s;
        } catch (Exception first) {
            // Alternativa conocida para algunos teléfonos: canal RFCOMM 1 por reflexión
            Method m = device.getClass().getMethod("createRfcommSocket", int.class);
            BluetoothSocket s = (BluetoothSocket) m.invoke(device, 1);
            s.connect();
            return s;
        }
    }

    private void readLoop(BluetoothSocket s) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.US_ASCII));
        String line;
        while (connected && (line = reader.readLine()) != null) {
            if (lines.size() > 500) lines.poll();   // Unity dejó de leer: no crecer sin límite
            lines.add(line);
        }
        status = "desconectado";
    }

    /** Devuelve todas las líneas pendientes separadas por '\n', o "" si no hay. */
    public String pollAll() {
        if (lines.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = lines.poll()) != null) sb.append(l).append('\n');
        return sb.toString();
    }

    public boolean write(String text) {
        OutputStream o = out;
        if (!connected || o == null) return false;
        try {
            o.write(text.getBytes(StandardCharsets.US_ASCII));
            o.flush();
            return true;
        } catch (Exception e) {
            status = "error-escritura";
            close();
            return false;
        }
    }

    public void close() {
        connected = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) { }
        socket = null;
        out = null;
    }
}
