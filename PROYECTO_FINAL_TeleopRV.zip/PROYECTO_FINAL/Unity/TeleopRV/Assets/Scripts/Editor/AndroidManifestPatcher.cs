using System.IO;
using System.Xml;
using UnityEditor.Android;

namespace TeleopRV.EditorTools
{
    /// <summary>
    /// Agrega al AndroidManifest generado los permisos de Bluetooth y las características de hardware
    /// (giroscopio) que necesita la app. Se ejecuta automáticamente en cada compilación Android.
    /// </summary>
    public class AndroidManifestPatcher : IPostGenerateGradleAndroidProject
    {
        const string AndroidNs = "http://schemas.android.com/apk/res/android";
        public int callbackOrder => 10;

        public void OnPostGenerateGradleAndroidProject(string path)
        {
            string manifestPath = Path.Combine(path, "src", "main", "AndroidManifest.xml");
            if (!File.Exists(manifestPath)) return;

            var doc = new XmlDocument();
            doc.Load(manifestPath);
            var manifest = doc.DocumentElement;

            // Android 11 o anterior
            AddPermission(doc, manifest, "android.permission.BLUETOOTH", "30");
            AddPermission(doc, manifest, "android.permission.BLUETOOTH_ADMIN", "30");
            // Android 12 o superior: conectar a dispositivos ya emparejados
            AddPermission(doc, manifest, "android.permission.BLUETOOTH_CONNECT", null);

            AddFeature(doc, manifest, "android.hardware.bluetooth", true);
            AddFeature(doc, manifest, "android.hardware.sensor.gyroscope", true);

            doc.Save(manifestPath);
        }

        static bool Exists(XmlElement manifest, string tag, string name)
        {
            foreach (XmlNode n in manifest.GetElementsByTagName(tag))
                if (n is XmlElement e && e.GetAttribute("name", AndroidNs) == name) return true;
            return false;
        }

        static void AddPermission(XmlDocument doc, XmlElement manifest, string name, string maxSdk)
        {
            if (Exists(manifest, "uses-permission", name)) return;
            var e = doc.CreateElement("uses-permission");
            e.SetAttribute("name", AndroidNs, name);
            if (maxSdk != null) e.SetAttribute("maxSdkVersion", AndroidNs, maxSdk);
            manifest.AppendChild(e);
        }

        static void AddFeature(XmlDocument doc, XmlElement manifest, string name, bool required)
        {
            if (Exists(manifest, "uses-feature", name)) return;
            var e = doc.CreateElement("uses-feature");
            e.SetAttribute("name", AndroidNs, name);
            e.SetAttribute("required", AndroidNs, required ? "true" : "false");
            manifest.AppendChild(e);
        }
    }
}
