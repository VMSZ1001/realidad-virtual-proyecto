using UnityEditor;
using UnityEditor.SceneManagement;

namespace TeleopRV.EditorTools
{
    /// <summary>Al abrir el proyecto con una escena vacía, carga la escena de teleoperación.</summary>
    [InitializeOnLoad]
    static class OpenMainScene
    {
        static OpenMainScene()
        {
            EditorApplication.delayCall += () =>
            {
                if (UnityEngine.Application.isBatchMode || EditorApplication.isPlayingOrWillChangePlaymode) return;
                if (!string.IsNullOrEmpty(EditorSceneManager.GetActiveScene().path)) return;
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(SceneBuilder.ScenePath) != null)
                    EditorSceneManager.OpenScene(SceneBuilder.ScenePath);
            };
        }
    }
}
