using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TeleopRV.EditorTools
{
    /// <summary>
    /// Menú TeleopRV: configura el proyecto para Android + Cardboard, construye la escena y compila el APK.
    /// También se puede ejecutar sin abrir el editor:
    ///   Unity.exe -batchmode -quit -projectPath . -executeMethod TeleopRV.EditorTools.ProjectSetup.BatchAll
    /// </summary>
    public static class ProjectSetup
    {
        const string Define = "TELEOP_SERIAL";
        const string ApkPath = "Builds/TeleopRV.apk";

        [MenuItem("TeleopRV/1. Configurar proyecto (Android + Cardboard)", priority = 1)]
        public static void Configure()
        {
            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);

            PlayerSettings.companyName = "UMNG";
            PlayerSettings.productName = "TeleopRV";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.umng.teleoprv");
            PlayerSettings.bundleVersion = "1.0";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            EditorUserBuildSettings.buildAppBundle = false;

            // .NET Framework: necesario para System.IO.Ports (probar el control por puerto COM en el editor)
            foreach (var target in new[] { NamedBuildTarget.Android, NamedBuildTarget.Standalone })
            {
                PlayerSettings.SetApiCompatibilityLevel(target, ApiCompatibilityLevel.NET_Unity_4_8);
                var defines = PlayerSettings.GetScriptingDefineSymbols(target).Split(';').Where(d => d.Length > 0).ToList();
                if (!defines.Contains(Define)) defines.Add(Define);
                PlayerSettings.SetScriptingDefineSymbols(target, string.Join(";", defines));
            }

            AssetDatabase.SaveAssets();
            Debug.Log("[TeleopRV] Proyecto configurado para Android (IL2CPP, ARM64, API 26+, horizontal).");
        }

        [MenuItem("TeleopRV/2. Construir escena", priority = 2)]
        public static void BuildScene() => SceneBuilder.Build();

        [MenuItem("TeleopRV/3. Compilar APK", priority = 3)]
        public static void BuildApk()
        {
            Directory.CreateDirectory(Path.GetDirectoryName(ApkPath));
            var scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            if (scenes.Length == 0)
            {
                SceneBuilder.Build();
                scenes = new[] { SceneBuilder.ScenePath };
            }
            var report = BuildPipeline.BuildPlayer(new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = ApkPath,
                target = BuildTarget.Android,
                options = BuildOptions.None
            });
            if (report.summary.result == BuildResult.Succeeded)
                Debug.Log($"[TeleopRV] APK creado: {Path.GetFullPath(ApkPath)} ({report.summary.totalSize / (1024f * 1024f):0.0} MB)");
            else
                Debug.LogError("[TeleopRV] Falló la compilación del APK: " + report.summary.result);
        }

        /// <summary>Modo por lotes: configura y construye la escena; con el argumento -apk también compila.</summary>
        public static void BatchAll()
        {
            Configure();
            SceneBuilder.Build();
            if (System.Environment.GetCommandLineArgs().Contains("-apk")) BuildApk();
        }
    }
}
