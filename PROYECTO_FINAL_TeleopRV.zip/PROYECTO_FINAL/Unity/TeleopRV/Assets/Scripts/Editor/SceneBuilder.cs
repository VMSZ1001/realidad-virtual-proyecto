using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

namespace TeleopRV.EditorTools
{
    /// <summary>
    /// Construye por código la escena completa: sala con límites, obstáculos, objetos manipulables,
    /// zona de entrega, robot móvil con pinza, avatar con cámara estéreo, HUD y sistemas.
    /// Volver a ejecutarlo reemplaza la escena (los cambios manuales se pierden).
    /// </summary>
    public static class SceneBuilder
    {
        public const string ScenePath = "Assets/Scenes/Teleoperacion.unity";
        const string MatFolder = "Assets/Materials";

        // Dimensiones de la sala (m)
        const float RoomX = 20f, RoomZ = 16f, WallH = 3f, WallT = 0.4f, CeilingH = 4f;

        static readonly Dictionary<string, Material> mats = new Dictionary<string, Material>();

        public static void Build()
        {
            if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            mats.Clear();
            Directory.CreateDirectory(MatFolder);
            Directory.CreateDirectory(Path.GetDirectoryName(ScenePath));

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            BuildLighting();
            BuildRoom();
            var zone = BuildDeliveryZone(new Vector3(0f, 0f, 5.5f));
            BuildObstacles();
            BuildGrabbables();
            var (robot, gripper) = BuildRobot(new Vector3(0f, 0f, -2f));
            var (avatar, rig) = BuildAvatar(new Vector3(0f, 0f, -5.5f));
            BuildSystems(robot, gripper, zone, avatar, rig);

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            Debug.Log("[TeleopRV] Escena construida: " + ScenePath);
        }

        // ------------------------------------------------------------------ materiales

        static Material Mat(string name, Color color, float smoothness = 0.3f, Color? emission = null, float metallic = 0f)
        {
            if (mats.TryGetValue(name, out var cached)) return cached;
            string path = $"{MatFolder}/{name}.mat";
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null)
            {
                m = new Material(Shader.Find("Standard"));
                AssetDatabase.CreateAsset(m, path);
            }
            m.shader = Shader.Find("Standard");
            m.color = color;
            m.SetFloat("_Glossiness", smoothness);
            m.SetFloat("_Metallic", metallic);
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", emission ?? Color.black);
            m.globalIlluminationFlags = emission.HasValue ? MaterialGlobalIlluminationFlags.RealtimeEmissive : MaterialGlobalIlluminationFlags.EmissiveIsBlack;
            EditorUtility.SetDirty(m);
            mats[name] = m;
            return m;
        }

        static Material ShaderMat(string name, string shader, Color color)
        {
            string path = $"{MatFolder}/{name}.mat";
            var m = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (m == null)
            {
                m = new Material(Shader.Find(shader));
                AssetDatabase.CreateAsset(m, path);
            }
            m.shader = Shader.Find(shader);
            if (m.HasProperty("_Color")) m.color = color;
            EditorUtility.SetDirty(m);
            return m;
        }

        // ------------------------------------------------------------------ utilidades

        static GameObject Prim(PrimitiveType type, string name, Transform parent, Vector3 localPos, Vector3 scale, Material mat, bool keepCollider = true)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = scale;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            if (!keepCollider) Object.DestroyImmediate(go.GetComponent<Collider>());
            return go;
        }

        static Transform Group(string name, Transform parent = null)
        {
            var go = new GameObject(name);
            if (parent != null) go.transform.SetParent(parent, false);
            return go.transform;
        }

        static void MarkStatic(GameObject go) =>
            GameObjectUtility.SetStaticEditorFlags(go, StaticEditorFlags.BatchingStatic | StaticEditorFlags.OccluderStatic | StaticEditorFlags.OccludeeStatic);

        // ------------------------------------------------------------------ iluminación

        static void BuildLighting()
        {
            var sun = new GameObject("Luz direccional").AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.intensity = 1.0f;
            sun.color = new Color(1f, 0.97f, 0.92f);
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.6f;
            sun.transform.rotation = Quaternion.Euler(60f, -30f, 0f);

            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(0.55f, 0.62f, 0.70f);
            RenderSettings.ambientEquatorColor = new Color(0.36f, 0.40f, 0.45f);
            RenderSettings.ambientGroundColor = new Color(0.16f, 0.17f, 0.19f);
            RenderSettings.fog = false;

            var lights = Group("Luces de techo");
            for (int i = -1; i <= 1; i += 2)
            {
                var p = new GameObject("Luz " + (i < 0 ? "A" : "B")).AddComponent<Light>();
                p.transform.SetParent(lights, false);
                p.type = LightType.Point;
                p.range = 14f;
                p.intensity = 1.2f;
                p.color = new Color(0.7f, 0.9f, 1f);
                p.transform.localPosition = new Vector3(0f, CeilingH - 0.5f, i * 4f);
            }
        }

        // ------------------------------------------------------------------ sala

        static void BuildRoom()
        {
            var room = Group("Sala");
            var floorMat = Mat("Piso", new Color(0.20f, 0.22f, 0.25f), 0.65f);
            var wallMat = Mat("Pared", new Color(0.58f, 0.60f, 0.63f), 0.15f);
            var ceilMat = Mat("Techo", new Color(0.30f, 0.31f, 0.33f), 0.1f);
            var stripMat = Mat("Franja luminosa", new Color(0.3f, 0.9f, 1f), 0.8f, new Color(0.35f, 1.1f, 1.4f));

            var floor = Prim(PrimitiveType.Cube, "Piso", room, new Vector3(0f, -0.1f, 0f), new Vector3(RoomX, 0.2f, RoomZ), floorMat);
            MarkStatic(floor);

            // Límites físicos: 4 paredes con collider y HapticSurface
            var walls = Group("Límites", room);
            MakeWall(walls, "Pared norte", new Vector3(0f, WallH / 2, RoomZ / 2 + WallT / 2), new Vector3(RoomX + 2 * WallT, WallH, WallT), wallMat);
            MakeWall(walls, "Pared sur", new Vector3(0f, WallH / 2, -RoomZ / 2 - WallT / 2), new Vector3(RoomX + 2 * WallT, WallH, WallT), wallMat);
            MakeWall(walls, "Pared este", new Vector3(RoomX / 2 + WallT / 2, WallH / 2, 0f), new Vector3(WallT, WallH, RoomZ), wallMat);
            MakeWall(walls, "Pared oeste", new Vector3(-RoomX / 2 - WallT / 2, WallH / 2, 0f), new Vector3(WallT, WallH, RoomZ), wallMat);

            // Paneles superiores (sin collider) entre el muro y el techo
            var upper = Group("Paneles superiores", room);
            float upperH = CeilingH - WallH;
            Prim(PrimitiveType.Cube, "Panel N", upper, new Vector3(0f, WallH + upperH / 2, RoomZ / 2 + WallT / 2), new Vector3(RoomX + 2 * WallT, upperH, WallT), ceilMat, false);
            Prim(PrimitiveType.Cube, "Panel S", upper, new Vector3(0f, WallH + upperH / 2, -RoomZ / 2 - WallT / 2), new Vector3(RoomX + 2 * WallT, upperH, WallT), ceilMat, false);
            Prim(PrimitiveType.Cube, "Panel E", upper, new Vector3(RoomX / 2 + WallT / 2, WallH + upperH / 2, 0f), new Vector3(WallT, upperH, RoomZ), ceilMat, false);
            Prim(PrimitiveType.Cube, "Panel O", upper, new Vector3(-RoomX / 2 - WallT / 2, WallH + upperH / 2, 0f), new Vector3(WallT, upperH, RoomZ), ceilMat, false);

            var ceiling = Prim(PrimitiveType.Cube, "Techo", room, new Vector3(0f, CeilingH + 0.1f, 0f), new Vector3(RoomX + 2 * WallT, 0.2f, RoomZ + 2 * WallT), ceilMat, false);
            ceiling.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;   // deja pasar la luz direccional

            // Franjas luminosas: cuadrícula en el piso, líneas en el techo y verticales en las paredes (como la Figura 1)
            var strips = Group("Franjas", room);
            for (float x = -RoomX / 2 + 2f; x < RoomX / 2 - 0.1f; x += 4f)
                Prim(PrimitiveType.Cube, "Piso X", strips, new Vector3(x, 0.003f, 0f), new Vector3(0.05f, 0.006f, RoomZ), stripMat, false);
            for (float z = -RoomZ / 2 + 2f; z < RoomZ / 2 - 0.1f; z += 4f)
                Prim(PrimitiveType.Cube, "Piso Z", strips, new Vector3(0f, 0.003f, z), new Vector3(RoomX, 0.006f, 0.05f), stripMat, false);
            for (int i = -1; i <= 1; i++)
                Prim(PrimitiveType.Cube, "Techo", strips, new Vector3(i * 5f, CeilingH - 0.02f, 0f), new Vector3(0.15f, 0.04f, RoomZ - 1f), stripMat, false);
            for (float z = -RoomZ / 2 + 2f; z < RoomZ / 2; z += 4f)
            {
                Prim(PrimitiveType.Cube, "Pared E", strips, new Vector3(RoomX / 2 - 0.02f, WallH / 2 + 0.3f, z), new Vector3(0.04f, WallH - 0.6f, 0.08f), stripMat, false);
                Prim(PrimitiveType.Cube, "Pared O", strips, new Vector3(-RoomX / 2 + 0.02f, WallH / 2 + 0.3f, z), new Vector3(0.04f, WallH - 0.6f, 0.08f), stripMat, false);
            }
            foreach (Transform t in strips) t.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
        }

        static void MakeWall(Transform parent, string name, Vector3 pos, Vector3 size, Material mat)
        {
            var w = Prim(PrimitiveType.Cube, name, parent, pos, size, mat);
            w.AddComponent<HapticSurface>().type = SurfaceType.Wall;
            MarkStatic(w);
        }

        // ------------------------------------------------------------------ obstáculos y objetos

        static void BuildObstacles()
        {
            var group = Group("Obstáculos");
            var pillarMat = Mat("Pilar", new Color(0.10f, 0.22f, 0.62f), 0.45f);
            var blockMat = Mat("Bloque", new Color(0.35f, 0.38f, 0.45f), 0.3f);
            Vector3[] pillars =
            {
                new Vector3(-2.6f, 0f, 1.5f), new Vector3(2.6f, 0f, 1.5f), new Vector3(0f, 0f, 2.8f),
                new Vector3(-6.5f, 0f, 3.5f), new Vector3(6.5f, 0f, -1f), new Vector3(-5f, 0f, -3.5f)
            };
            foreach (var p in pillars)
            {
                var go = Prim(PrimitiveType.Cube, "Pilar", group, p + Vector3.up * 1.5f, new Vector3(0.6f, 3f, 0.6f), pillarMat);
                go.AddComponent<HapticSurface>().type = SurfaceType.Obstacle;
                MarkStatic(go);
            }
            Vector3[] blocks = { new Vector3(4.5f, 0f, 4f), new Vector3(-3f, 0f, -1f) };
            foreach (var p in blocks)
            {
                var go = Prim(PrimitiveType.Cube, "Bloque bajo", group, p + Vector3.up * 0.3f, new Vector3(1.2f, 0.6f, 0.8f), blockMat);
                go.AddComponent<HapticSurface>().type = SurfaceType.Obstacle;
                MarkStatic(go);
            }
        }

        static void BuildGrabbables()
        {
            var group = Group("Objetos manipulables");
            var red = Mat("Objeto manipulable", new Color(0.85f, 0.10f, 0.10f), 0.5f, Color.black);
            var orange = Mat("Esfera manipulable", new Color(0.95f, 0.45f, 0.10f), 0.6f, Color.black);

            Vector3[] cubes = { new Vector3(-7f, 0f, -5.5f), new Vector3(7.5f, 0f, 3.5f), new Vector3(-4.5f, 0f, 6f) };
            for (int i = 0; i < cubes.Length; i++)
                MakeGrabbable(group, PrimitiveType.Cube, $"Cubo {i + 1}", cubes[i] + Vector3.up * 0.125f, red, true);

            MakeGrabbable(group, PrimitiveType.Sphere, "Esfera", new Vector3(4f, 0.125f, -4.5f), orange, false);
        }

        static void MakeGrabbable(Transform parent, PrimitiveType type, string name, Vector3 pos, Material mat, bool target)
        {
            var go = Prim(type, name, parent, pos, Vector3.one * 0.25f, mat);
            var rb = go.AddComponent<Rigidbody>();
            rb.mass = 0.4f;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            rb.angularDamping = type == PrimitiveType.Sphere ? 1.5f : 0.05f;
            go.AddComponent<Grabbable>().isTaskTarget = target;
        }

        static DeliveryZone BuildDeliveryZone(Vector3 pos)
        {
            var zoneMat = ShaderMat("Zona de entrega", "Sprites/Default", new Color(0.1f, 0.9f, 0.3f, 0.35f));
            var root = new GameObject("Zona de entrega");
            root.transform.position = pos;
            var trigger = root.AddComponent<BoxCollider>();
            trigger.isTrigger = true;
            trigger.center = new Vector3(0f, 0.5f, 0f);
            trigger.size = new Vector3(2.4f, 1f, 2.4f);

            var pad = Prim(PrimitiveType.Cube, "Indicador", root.transform, new Vector3(0f, 0.01f, 0f), new Vector3(2.4f, 0.02f, 2.4f), zoneMat, false);
            pad.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;

            var zone = root.AddComponent<DeliveryZone>();
            zone.indicator = pad.GetComponent<Renderer>();
            return zone;
        }

        // ------------------------------------------------------------------ robot

        static (RobotController, RobotGripper) BuildRobot(Vector3 pos)
        {
            var body = Mat("Robot cuerpo", new Color(0.88f, 0.89f, 0.90f), 0.55f, null, 0.2f);
            var dark = Mat("Robot oscuro", new Color(0.08f, 0.08f, 0.09f), 0.3f);
            var accent = Mat("Robot acento", new Color(1f, 0.55f, 0.05f), 0.5f);
            var eye = Mat("Robot ojos", new Color(0.1f, 0.5f, 1f), 0.9f, new Color(0.2f, 0.9f, 2f));

            var root = new GameObject("Robot móvil");
            root.transform.position = pos;

            var rb = root.AddComponent<Rigidbody>();
            rb.mass = 20f;
            rb.linearDamping = 0.5f;
            var col = root.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, 0.16f, 0f);
            col.size = new Vector3(0.46f, 0.32f, 0.62f);
            var slippery = new PhysicsMaterial("Robot deslizante") { dynamicFriction = 0.05f, staticFriction = 0.05f, frictionCombine = PhysicsMaterialCombine.Minimum };
            AssetDatabase.CreateAsset(slippery, $"{MatFolder}/Robot deslizante.asset");
            col.sharedMaterial = slippery;

            var visual = Group("Visual", root.transform);
            Prim(PrimitiveType.Cube, "Chasis", visual, new Vector3(0f, 0.17f, 0f), new Vector3(0.40f, 0.12f, 0.56f), body, false);
            Prim(PrimitiveType.Cube, "Franja", visual, new Vector3(0f, 0.235f, 0f), new Vector3(0.41f, 0.015f, 0.57f), accent, false);
            var head = Prim(PrimitiveType.Cube, "Cabeza", visual, new Vector3(0f, 0.30f, 0.12f), new Vector3(0.22f, 0.12f, 0.16f), body, false);
            Prim(PrimitiveType.Sphere, "Ojo I", head.transform, new Vector3(-0.22f, 0.05f, 0.5f), new Vector3(0.28f, 0.4f, 0.2f), eye, false);
            Prim(PrimitiveType.Sphere, "Ojo D", head.transform, new Vector3(0.22f, 0.05f, 0.5f), new Vector3(0.28f, 0.4f, 0.2f), eye, false);
            Prim(PrimitiveType.Cube, "Mástil", visual, new Vector3(0f, 0.40f, -0.12f), new Vector3(0.05f, 0.34f, 0.05f), dark, false);
            Prim(PrimitiveType.Cube, "Brazo", visual, new Vector3(0f, 0.56f, 0.02f), new Vector3(0.05f, 0.05f, 0.34f), accent, false);
            Prim(PrimitiveType.Cube, "Antebrazo", visual, new Vector3(0f, 0.42f, 0.2f), new Vector3(0.05f, 0.30f, 0.05f), accent, false);

            // Ruedas: pivote sin rotación (gira en X local) + cilindro acostado
            var left = new List<Transform>();
            var right = new List<Transform>();
            foreach (float z in new[] { -0.19f, 0.19f })
                foreach (float x in new[] { -0.235f, 0.235f })
                {
                    var pivot = Group(x < 0 ? "Rueda I" : "Rueda D", visual);
                    pivot.localPosition = new Vector3(x, 0.09f, z);
                    var wheel = Prim(PrimitiveType.Cylinder, "Llanta", pivot, Vector3.zero, new Vector3(0.18f, 0.035f, 0.18f), dark, false);
                    wheel.transform.localRotation = Quaternion.Euler(0f, 0f, 90f);
                    Prim(PrimitiveType.Cube, "Rin", pivot, new Vector3(x < 0 ? -0.036f : 0.036f, 0f, 0f), new Vector3(0.005f, 0.12f, 0.03f), accent, false);
                    (x < 0 ? left : right).Add(pivot);
                }

            // Pinza al frente
            var gripRoot = Group("Pinza", root.transform);
            gripRoot.localPosition = new Vector3(0f, 0.2f, 0f);
            Prim(PrimitiveType.Cube, "Palma", gripRoot, new Vector3(0f, 0f, 0.33f), new Vector3(0.42f, 0.06f, 0.04f), dark, false);
            var lf = Prim(PrimitiveType.Cube, "Dedo I", gripRoot, new Vector3(-0.18f, 0f, 0.43f), new Vector3(0.03f, 0.1f, 0.18f), accent, false);
            var rf = Prim(PrimitiveType.Cube, "Dedo D", gripRoot, new Vector3(0.18f, 0f, 0.43f), new Vector3(0.03f, 0.1f, 0.18f), accent, false);
            var gripPoint = Group("Punto de agarre", gripRoot);
            gripPoint.localPosition = new Vector3(0f, 0f, 0.48f);

            var zone = new GameObject("Zona de agarre");
            zone.transform.SetParent(gripRoot, false);
            var trig = zone.AddComponent<BoxCollider>();
            trig.isTrigger = true;
            trig.center = new Vector3(0f, -0.05f, 0.5f);
            trig.size = new Vector3(0.5f, 0.35f, 0.45f);

            root.AddComponent<AudioSource>();
            root.AddComponent<ImpactAudio>();
            var robot = root.AddComponent<RobotController>();
            robot.leftWheels = left.ToArray();
            robot.rightWheels = right.ToArray();

            var gripper = zone.AddComponent<RobotGripper>();
            gripper.Robot = robot;
            gripper.gripPoint = gripPoint;
            gripper.leftFinger = lf.transform;
            gripper.rightFinger = rf.transform;
            gripper.fingerOpen = 0.18f;
            gripper.fingerClosed = 0.14f;
            return (robot, gripper);
        }

        // ------------------------------------------------------------------ avatar

        static (AvatarController, CardboardRig) BuildAvatar(Vector3 pos)
        {
            var root = new GameObject("Avatar (primera persona)");
            root.transform.position = pos;
            var cc = root.AddComponent<CharacterController>();
            cc.height = 1.7f;
            cc.radius = 0.3f;
            cc.center = new Vector3(0f, 0.85f, 0f);
            cc.stepOffset = 0.3f;

            var head = new GameObject("Cabeza");
            head.transform.SetParent(root.transform, false);
            head.transform.localPosition = new Vector3(0f, 1.6f, 0f);
            head.AddComponent<AudioListener>();

            Camera Eye(string name)
            {
                var go = new GameObject(name);
                go.transform.SetParent(head.transform, false);
                var cam = go.AddComponent<Camera>();
                cam.clearFlags = CameraClearFlags.Skybox;
                cam.nearClipPlane = 0.05f;
                cam.farClipPlane = 60f;
                return cam;
            }
            var leftEye = Eye("Ojo izquierdo");
            leftEye.tag = "MainCamera";
            var rightEye = Eye("Ojo derecho");

            var lensShader = Shader.Find("TeleopRV/CardboardBarrel");
            var rig = head.AddComponent<CardboardRig>();
            rig.leftEye = leftEye;
            rig.rightEye = rightEye;
            rig.lensMaterial = lensShader != null ? ShaderMat("Lente Cardboard", "TeleopRV/CardboardBarrel", Color.white) : null;

            var avatar = root.AddComponent<AvatarController>();
            avatar.head = rig;
            return (avatar, rig);
        }

        // ------------------------------------------------------------------ sistemas y HUD

        static void BuildSystems(RobotController robot, RobotGripper gripper, DeliveryZone zone, AvatarController avatar, CardboardRig rig)
        {
            var sys = new GameObject("Sistema");
            sys.AddComponent<HapticLink>();
            var metrics = sys.AddComponent<MetricsLogger>();
            metrics.robot = robot;
            metrics.gripper = gripper;
            var task = sys.AddComponent<TaskManager>();
            task.robot = robot;
            task.gripper = gripper;
            task.zone = zone;

            var hudRoot = new GameObject("HUD");
            // Posición inicial frente al avatar (en ejecución HudDisplay lo reubica siguiendo la mirada)
            hudRoot.transform.position = rig.transform.position + new Vector3(0f, -0.55f, 1.6f);
            var hud = hudRoot.AddComponent<HudDisplay>();
            hud.head = rig;
            hud.robot = robot;
            hud.task = task;
            hud.avatar = avatar;

            var bgMat = ShaderMat("HUD fondo", "Sprites/Default", new Color(0.02f, 0.04f, 0.07f, 0.6f));
            var bg = Prim(PrimitiveType.Quad, "Fondo", hudRoot.transform, new Vector3(0f, 0f, 0.01f), new Vector3(1.1f, 0.34f, 1f), bgMat, false);
            bg.GetComponent<Renderer>().shadowCastingMode = ShadowCastingMode.Off;
            hud.background = bg.transform;

            hud.text = MakeText(hudRoot.transform, "Texto", Vector3.zero, TextAnchor.MiddleCenter, Color.white, 0.0055f);
            hud.messageText = MakeText(hudRoot.transform, "Mensaje", new Vector3(0f, 0.28f, 0f), TextAnchor.MiddleCenter, new Color(1f, 0.85f, 0.2f), 0.007f);
            hud.messageText.alignment = TextAlignment.Center;
        }

        static TextMesh MakeText(Transform parent, string name, Vector3 pos, TextAnchor anchor, Color color, float charSize)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            var tm = go.AddComponent<TextMesh>();
            var font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            tm.font = font;
            tm.fontSize = 80;
            tm.characterSize = charSize;
            tm.anchor = anchor;
            tm.alignment = TextAlignment.Left;
            tm.color = color;
            tm.text = "";
            go.GetComponent<MeshRenderer>().sharedMaterial = font.material;
            return tm;
        }
    }
}
