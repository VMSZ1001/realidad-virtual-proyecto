using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace TeleopRV.EditorTools
{
    /// <summary>
    /// Guarda capturas de la escena en Capturas/: la vista del avatar (primera persona) y una vista en tercera persona.
    /// Útil para el informe. Por lotes: -executeMethod TeleopRV.EditorTools.SceneCapture.Capture
    /// </summary>
    public static class SceneCapture
    {
        const string Folder = "Capturas";

        [MenuItem("TeleopRV/4. Capturas para el informe", priority = 20)]
        public static void Capture()
        {
            if (EditorSceneManager.GetActiveScene().path != SceneBuilder.ScenePath)
                EditorSceneManager.OpenScene(SceneBuilder.ScenePath);
            Directory.CreateDirectory(Folder);

            var head = Object.FindFirstObjectByType<CardboardRig>();
            if (head != null)
                Render(head.transform.position, head.transform.rotation * Quaternion.Euler(12f, 0f, 0f), 75f, "primera_persona.png");

            // El techo, los paneles superiores y el HUD tapan las vistas desde arriba: se ocultan
            var hidden = new System.Collections.Generic.List<Renderer>();
            foreach (var r in Object.FindObjectsByType<Renderer>(FindObjectsSortMode.None))
            {
                bool above = r.bounds.min.y > 2.9f;
                bool hud = r.GetComponentInParent<HudDisplay>() != null;
                if (r.enabled && (above || hud)) { r.enabled = false; hidden.Add(r); }
            }

            var robot = Object.FindFirstObjectByType<RobotController>();
            Vector3 target = robot != null ? robot.transform.position : Vector3.zero;
            Vector3 eye = target + new Vector3(-6.5f, 5.5f, -7.5f);
            Render(eye, Quaternion.LookRotation(target + new Vector3(0f, 0f, 3f) - eye), 60f, "tercera_persona.png");

            Vector3 top = new Vector3(0f, 22f, 0.01f);
            Render(top, Quaternion.LookRotation(Vector3.down, Vector3.forward), 45f, "vista_aerea.png");
            foreach (var r in hidden) r.enabled = true;
            Debug.Log("[TeleopRV] Capturas guardadas en " + Path.GetFullPath(Folder));
        }

        static void Render(Vector3 pos, Quaternion rot, float fov, string file)
        {
            const int w = 1600, h = 900;
            var go = new GameObject("CamaraCaptura") { hideFlags = HideFlags.HideAndDontSave };
            var cam = go.AddComponent<Camera>();
            cam.transform.SetPositionAndRotation(pos, rot);
            cam.fieldOfView = fov;
            cam.nearClipPlane = 0.05f;
            cam.farClipPlane = 100f;
            cam.clearFlags = CameraClearFlags.Skybox;

            var rt = new RenderTexture(w, h, 24) { antiAliasing = 4 };
            cam.targetTexture = rt;
            cam.Render();
            RenderTexture.active = rt;
            var tex = new Texture2D(w, h, TextureFormat.RGB24, false);
            tex.ReadPixels(new Rect(0, 0, w, h), 0, 0);
            tex.Apply();
            File.WriteAllBytes(Path.Combine(Folder, file), tex.EncodeToPNG());

            RenderTexture.active = null;
            cam.targetTexture = null;
            Object.DestroyImmediate(rt);
            Object.DestroyImmediate(tex);
            Object.DestroyImmediate(go);
        }
    }
}
