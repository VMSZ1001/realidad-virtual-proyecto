using UnityEngine;

namespace TeleopRV
{
    public enum JoystickXMode
    {
        [Tooltip("El eje X desplaza al avatar hacia los lados")] Strafe,
        [Tooltip("El eje X gira la vista por pasos (útil si el usuario está sentado)")] SnapTurn
    }

    /// <summary>
    /// Avatar en primera persona: la cabeza sigue al giroscopio del celular y el joystick del control lo desplaza
    /// relativo a la dirección horizontal de la mirada (Y = adelante/atrás, X = lateral o giro por pasos).
    /// El CharacterController impide atravesar paredes y límites.
    /// Mantener el botón del joystick 2 s recentra la vista y pone en cero la inclinación del control.
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class AvatarController : MonoBehaviour
    {
        public CardboardRig head;
        [Tooltip("Velocidad máxima de desplazamiento (m/s)")] public float walkSpeed = 1.5f;
        [Tooltip("Zona muerta radial del joystick (0–1)")] [Range(0f, 0.5f)] public float joystickDeadZone = 0.15f;
        [Tooltip("Exponente de la respuesta del joystick (1 = lineal)")] [Range(1f, 3f)] public float joystickGamma = 1.5f;
        public JoystickXMode xAxisMode = JoystickXMode.Strafe;
        [Tooltip("Ángulo de cada giro por pasos (°)")] public float snapTurnAngle = 30f;
        public bool invertY;
        public float gravity = -9.81f;

        public event System.Action OnRecentered;

        public Vector2 MoveInput { get; private set; }   // joystick después de la zona muerta y la curva

        CharacterController cc;
        float verticalSpeed;
        bool snapArmed = true;

        void Awake() => cc = GetComponent<CharacterController>();

        /// <summary>Zona muerta radial con reescalado: el movimiento arranca suave justo al salir de la zona muerta.</summary>
        Vector2 ShapeJoystick(Vector2 raw)
        {
            float mag = raw.magnitude;
            if (mag <= joystickDeadZone) return Vector2.zero;
            float k = Mathf.Pow(Mathf.Clamp01((mag - joystickDeadZone) / (1f - joystickDeadZone)), joystickGamma);
            return raw / mag * k;
        }

        void Update()
        {
            var link = HapticLink.Instance;
            Vector2 raw = link != null ? link.Joystick : Vector2.zero;
            if (invertY) raw.y = -raw.y;
            Vector2 input = ShapeJoystick(raw);

            if (link != null && link.LongPressThisFrame) Recenter();
            if (Input.GetKeyDown(KeyCode.C)) Recenter();

            // Giro por pasos: un giro cada vez que el eje X pasa de 0.7 y vuelve al centro
            if (xAxisMode == JoystickXMode.SnapTurn)
            {
                if (snapArmed && Mathf.Abs(raw.x) > 0.7f)
                {
                    snapArmed = false;
                    if (head != null) head.AddYaw(Mathf.Sign(raw.x) * snapTurnAngle);
                }
                else if (Mathf.Abs(raw.x) < 0.3f) snapArmed = true;
                input.x = 0f;
            }
            MoveInput = input;

            Vector3 fwd = head != null ? head.FlatForward : transform.forward;
            Vector3 right = Vector3.Cross(Vector3.up, fwd);
            Vector3 move = (fwd * input.y + right * input.x) * walkSpeed;

            verticalSpeed = cc.isGrounded ? -1f : verticalSpeed + gravity * Time.deltaTime;
            move.y = verticalSpeed;
            cc.Move(move * Time.deltaTime);
        }

        public void Recenter()
        {
            if (head != null) head.Recenter();
            if (HapticLink.Instance != null)
            {
                HapticLink.Instance.ZeroController();
                HapticLink.Instance.Vibrate(HapticPattern.Grab, 220);
            }
            MetricsLogger.Instance?.LogEvent("recentrado", "vista+control", 0f, 3, 220);
            OnRecentered?.Invoke();
        }

        void OnControllerColliderHit(ControllerColliderHit hit)
        {
            if (MoveInput.sqrMagnitude < 0.01f) return;                      // solo al caminar contra algo
            var surface = hit.collider.GetComponentInParent<HapticSurface>();
            if (surface == null) return;
            // Sostenida mientras el avatar siga caminando contra la pared
            bool isNew = HapticLink.Instance != null && HapticLink.Instance.VibrateSustained(HapticPattern.Wall, 255);
            if (isNew) MetricsLogger.Instance?.LogEvent("colision_avatar", surface.type == SurfaceType.Wall ? "pared" : "obstaculo", walkSpeed, 2, 255);
        }
    }
}
