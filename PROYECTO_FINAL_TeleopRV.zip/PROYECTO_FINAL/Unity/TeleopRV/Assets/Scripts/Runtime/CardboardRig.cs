using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Cámara estéreo para visor tipo Cardboard: dos cámaras separadas por la distancia interpupilar,
    /// cada una en media pantalla, orientadas con el giroscopio del celular (3DOF).
    /// En el editor (sin giroscopio) se mira con el botón derecho del mouse.
    /// </summary>
    public class CardboardRig : MonoBehaviour
    {
        public Camera leftEye;
        public Camera rightEye;
        [Tooltip("Distancia interpupilar (m)")] public float ipd = 0.064f;
        [Tooltip("Campo de visión vertical por ojo (°)")] public float fieldOfView = 80f;
        [Tooltip("Estéreo en el celular; en el editor se ve una sola cámara")] public bool stereoOnDevice = true;
        public bool stereoInEditor = false;
        [Tooltip("Corrección de distorsión de los lentes (barril)")] public Material lensMaterial;
        public bool lensCorrection = true;

        [Header("Mouse (editor)")]
        public float mouseSensitivity = 3f;

        public bool UsingGyro { get; private set; }
        public bool IsStereo { get; private set; }

        Quaternion yawOffset = Quaternion.identity;
        float mouseYaw, mousePitch;
        float recenterAt;

        void Awake()
        {
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Application.targetFrameRate = 60;
#if !UNITY_EDITOR
            Screen.orientation = ScreenOrientation.LandscapeLeft;
#endif
            UsingGyro = SystemInfo.supportsGyroscope && !Application.isEditor;
            if (UsingGyro) Input.gyro.enabled = true;
            recenterAt = Time.time + 0.6f;   // el giroscopio tarda unos cuadros en entregar la orientación

            IsStereo = Application.isEditor ? stereoInEditor : stereoOnDevice;
            ConfigureCameras();
        }

        public void SetStereo(bool stereo)
        {
            IsStereo = stereo;
            ConfigureCameras();
        }

        bool UseLens => IsStereo && lensCorrection && lensMaterial != null;

        void ConfigureCameras()
        {
            if (leftEye == null || rightEye == null) return;
            foreach (var cam in new[] { leftEye, rightEye })
            {
                cam.fieldOfView = fieldOfView;
                cam.nearClipPlane = 0.05f;
            }

            if (IsStereo)
            {
                leftEye.transform.localPosition = new Vector3(-ipd * 0.5f, 0f, 0f);
                rightEye.transform.localPosition = new Vector3(ipd * 0.5f, 0f, 0f);
                rightEye.enabled = true;
                if (UseLens)
                {
                    // Cada ojo a su textura; el compositor las dibuja con la corrección de lentes
                    leftEye.rect = rightEye.rect = new Rect(0f, 0f, 1f, 1f);
                    EnsureEyeTextures();
                }
                else
                {
                    ReleaseEyeTextures();
                    leftEye.rect = new Rect(0f, 0f, 0.5f, 1f);
                    rightEye.rect = new Rect(0.5f, 0f, 0.5f, 1f);
                }
            }
            else
            {
                ReleaseEyeTextures();
                leftEye.rect = new Rect(0f, 0f, 1f, 1f);
                leftEye.transform.localPosition = Vector3.zero;
                rightEye.enabled = false;
            }
        }

        StereoCompositor compositor;
        int texW, texH;

        void EnsureEyeTextures()
        {
            int w = Mathf.Max(16, Screen.width / 2), h = Mathf.Max(16, Screen.height);
            if (compositor == null)
            {
                var go = new GameObject("Compositor estéreo");
                go.transform.SetParent(transform, false);
                var cam = go.AddComponent<Camera>();
                cam.cullingMask = 0;
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = Color.black;
                cam.depth = Mathf.Max(leftEye.depth, rightEye.depth) + 1;
                compositor = go.AddComponent<StereoCompositor>();
                compositor.material = lensMaterial;
            }
            compositor.gameObject.SetActive(true);
            if (leftEye.targetTexture != null && w == texW && h == texH) return;

            ReleaseEyeTextures(keepCompositor: true);
            texW = w; texH = h;
            leftEye.targetTexture = compositor.left = new RenderTexture(w, h, 24) { antiAliasing = 2, name = "Ojo izquierdo" };
            rightEye.targetTexture = compositor.right = new RenderTexture(w, h, 24) { antiAliasing = 2, name = "Ojo derecho" };
        }

        void ReleaseEyeTextures(bool keepCompositor = false)
        {
            foreach (var cam in new[] { leftEye, rightEye })
            {
                if (cam == null || cam.targetTexture == null) continue;
                var rt = cam.targetTexture;
                cam.targetTexture = null;
                rt.Release();
                Destroy(rt);
            }
            if (compositor != null && !keepCompositor) compositor.gameObject.SetActive(false);
        }

        void OnDestroy() => ReleaseEyeTextures();

        /// <summary>Hace que la dirección actual de la mirada quede alineada con el frente del avatar.</summary>
        public void Recenter()
        {
            if (UsingGyro)
            {
                float yaw = GyroRotation().eulerAngles.y;
                yawOffset = Quaternion.Euler(0f, -yaw, 0f);
            }
            else
            {
                mouseYaw = 0f;
                mousePitch = 0f;
            }
        }

        /// <summary>Gira la vista alrededor del eje vertical (giro por pasos con el joystick).</summary>
        public void AddYaw(float degrees)
        {
            if (UsingGyro) yawOffset = Quaternion.Euler(0f, degrees, 0f) * yawOffset;
            else mouseYaw += degrees;
        }

        static Quaternion GyroRotation()
        {
            // Sistema del giroscopio de Android (derecho) -> Unity (izquierdo), celular en horizontal izquierda
            Quaternion q = Input.gyro.attitude;
            return Quaternion.Euler(90f, 0f, 0f) * new Quaternion(q.x, q.y, -q.z, -q.w);
        }

        void LateUpdate()
        {
            // Si cambia la resolución (rotación de pantalla), se recrean las texturas de los ojos
            if (UseLens && (Screen.width / 2 != texW || Screen.height != texH)) EnsureEyeTextures();

            if (recenterAt > 0f && Time.time >= recenterAt)
            {
                recenterAt = -1f;
                Recenter();
            }

            if (UsingGyro)
            {
                transform.localRotation = yawOffset * GyroRotation();
            }
            else
            {
                if (Input.GetMouseButton(1))
                {
                    mouseYaw += Input.GetAxis("Mouse X") * mouseSensitivity;
                    mousePitch = Mathf.Clamp(mousePitch - Input.GetAxis("Mouse Y") * mouseSensitivity, -80f, 80f);
                }
                transform.localRotation = Quaternion.Euler(mousePitch, mouseYaw, 0f);
            }
        }

        /// <summary>Dirección horizontal de la mirada (para avanzar/retroceder el avatar).</summary>
        public Vector3 FlatForward
        {
            get
            {
                Vector3 f = transform.forward;
                f.y = 0f;
                return f.sqrMagnitude > 1e-4f ? f.normalized : transform.parent != null ? transform.parent.forward : Vector3.forward;
            }
        }
    }
}
