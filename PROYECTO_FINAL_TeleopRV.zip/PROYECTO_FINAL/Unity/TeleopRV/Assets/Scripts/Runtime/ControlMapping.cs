using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Mapeo ángulo -> comando normalizado en [-1, 1]:
    /// f(θ) = signo(θ) · clamp((|θ| − θz) / (θmax − θz), 0, 1)^γ
    /// La zona muerta θz evita que el robot se mueva por el temblor de la mano y el ruido de la IMU;
    /// γ > 1 da más resolución cerca del reposo (movimientos finos) y conserva la velocidad máxima.
    /// </summary>
    [System.Serializable]
    public class AxisMapping
    {
        [Tooltip("Zona muerta θz (grados)")] public float deadZone = 5f;
        [Tooltip("Ángulo de saturación θmax (grados)")] public float maxAngle = 35f;
        [Tooltip("Exponente de la curva γ (1 = lineal)")] [Range(0.5f, 3f)] public float gamma = 1.5f;
        public bool invert;

        public float Evaluate(float angleDeg)
        {
            float a = invert ? -angleDeg : angleDeg;
            float span = Mathf.Max(0.01f, maxAngle - deadZone);
            float x = Mathf.Clamp01((Mathf.Abs(a) - deadZone) / span);
            return Mathf.Sign(a) * Mathf.Pow(x, gamma);
        }
    }

    public enum ControlMode
    {
        [Tooltip("Velocidad proporcional a la inclinación")] Proportional,
        [Tooltip("Todo o nada: velocidad máxima al pasar el umbral (para comparar en las pruebas)")] Threshold
    }
}
