using System.Collections.Generic;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>Zona verde de entrega: cuenta los objetos de la tarea que están dentro y ya fueron soltados.</summary>
    [RequireComponent(typeof(Collider))]
    public class DeliveryZone : MonoBehaviour
    {
        public Renderer indicator;
        public Color idleColor = new Color(0.1f, 0.9f, 0.3f, 0.35f);
        public Color doneColor = new Color(0.2f, 1f, 1f, 0.55f);

        readonly HashSet<Grabbable> inside = new HashSet<Grabbable>();
        MaterialPropertyBlock block;
        static readonly int ColorId = Shader.PropertyToID("_Color");

        public int Delivered
        {
            get
            {
                int n = 0;
                inside.RemoveWhere(g => g == null);
                foreach (var g in inside) if (g.isTaskTarget && !g.IsHeld) n++;
                return n;
            }
        }

        public bool AllDelivered { get; set; }

        void Awake()
        {
            GetComponent<Collider>().isTrigger = true;
            block = new MaterialPropertyBlock();
        }

        void OnTriggerEnter(Collider other)
        {
            var g = other.GetComponentInParent<Grabbable>();
            if (g != null) inside.Add(g);
        }

        void OnTriggerExit(Collider other)
        {
            var g = other.GetComponentInParent<Grabbable>();
            if (g != null) inside.Remove(g);
        }

        void Update()
        {
            if (indicator == null) return;
            float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * (AllDelivered ? 6f : 2f));
            Color c = AllDelivered ? doneColor : idleColor;
            c.a *= 0.7f + 0.3f * pulse;
            indicator.GetPropertyBlock(block);
            block.SetColor(ColorId, c);
            indicator.SetPropertyBlock(block);
        }
    }
}
