using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Objeto que el robot puede agarrar. Se resalta cuando está al alcance de la pinza.
    /// Mientras está agarrado, sus choques con paredes también vibran el control.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class Grabbable : MonoBehaviour
    {
        public Color highlightColor = new Color(1f, 0.85f, 0.2f);
        [Tooltip("Cuenta para la tarea de llevar objetos a la zona verde")]
        public bool isTaskTarget = true;

        public Rigidbody Body { get; private set; }
        public RobotGripper HeldBy { get; set; }
        public bool IsHeld => HeldBy != null;

        Renderer[] renderers;
        MaterialPropertyBlock block;
        bool highlighted;
        static readonly int EmissionId = Shader.PropertyToID("_EmissionColor");

        void Awake()
        {
            Body = GetComponent<Rigidbody>();
            renderers = GetComponentsInChildren<Renderer>();
            block = new MaterialPropertyBlock();
            foreach (var r in renderers) r.material.EnableKeyword("_EMISSION");
        }

        public void SetHighlight(bool on)
        {
            if (on == highlighted) return;
            highlighted = on;
            foreach (var r in renderers)
            {
                r.GetPropertyBlock(block);
                block.SetColor(EmissionId, on ? highlightColor * 0.6f : Color.black);
                r.SetPropertyBlock(block);
            }
        }

        void OnCollisionEnter(Collision c) => HeldContact(c, true);
        void OnCollisionStay(Collision c) => HeldContact(c, false);

        void HeldContact(Collision c, bool first)
        {
            if (!IsHeld) return;
            var surface = c.collider.GetComponentInParent<HapticSurface>();
            if (surface != null) HeldBy.Robot.ReportCollision(surface, c.relativeVelocity.magnitude, "objeto_agarrado", first);
        }
    }
}
