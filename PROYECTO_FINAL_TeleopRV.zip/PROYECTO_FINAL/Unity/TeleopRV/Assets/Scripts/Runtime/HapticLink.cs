using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace TeleopRV
{
    public enum HapticPattern { Stop = 0, Object = 1, Wall = 2, Grab = 3 }

    /// <summary>
    /// Conexión con el control háptico: recibe Pitch/Roll, joystick y botón; envía vibraciones y mide latencia.
    /// Botón del joystick (RECOLECTAR): clic = agarrar/soltar, mantener 2 s = recentrar, mantener 5 s = reiniciar tarea.
    /// Si no hay control conectado, el teclado lo simula (flechas = inclinación, WASD = joystick, Espacio = botón).
    /// Protocolo: Docs/ESPECIFICACION.md, sección 4.
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class HapticLink : MonoBehaviour
    {
        public static HapticLink Instance { get; private set; }

        [Header("Conexión")]
        [Tooltip("Nombre Bluetooth del ESP32 (debe estar emparejado en Android)")]
        public string deviceName = "HapticRV";
        [Tooltip("Solo editor/Windows: puerto COM del ESP32 (USB o Bluetooth). Vacío = usar el teclado.")]
        public string serialPort = "";
        public int serialBaud = 115200;
        public float reconnectInterval = 3f;

        [Header("Simulador de teclado")]
        public bool keyboardWhenDisconnected = true;
        public float simulatedMaxAngle = 35f;
        public float simulatedRate = 90f;   // °/s

        [Header("Botón del joystick")]
        [Tooltip("Una pulsación más corta que esto es un clic (agarrar/soltar), en s")] public float clickMaxDuration = 0.5f;
        [Tooltip("Mantener presionado este tiempo recentra la vista y el control (s)")] public float longPressTime = 2f;
        [Tooltip("Mantener presionado este tiempo reinicia la tarea (s)")] public float veryLongPressTime = 5f;

        [Header("Vibración")]
        public float patternCooldown = 0.2f;

        // ------------- Estado leído -------------
        public float Pitch { get; private set; }
        public float Roll { get; private set; }
        /// <summary>Joystick normalizado a [-1, 1] (sin zona muerta; la aplica quien lo usa). +X derecha, +Y adelante.</summary>
        public Vector2 Joystick { get; private set; }
        public bool CollectHeld { get; private set; }
        public bool CollectPressedThisFrame { get; private set; }
        public bool CollectReleasedThisFrame { get; private set; }
        /// <summary>Se soltó el botón antes de clickMaxDuration.</summary>
        public bool CollectClickedThisFrame { get; private set; }
        /// <summary>El botón lleva longPressTime presionado (se dispara una vez por pulsación).</summary>
        public bool LongPressThisFrame { get; private set; }
        /// <summary>El botón lleva veryLongPressTime presionado (se dispara una vez por pulsación).</summary>
        public bool VeryLongPressThisFrame { get; private set; }
        public float CollectHeldTime => CollectHeld ? Time.unscaledTime - pressStart : 0f;
        public int BatteryMv { get; private set; }

        public bool IsConnected => transport != null && transport.IsOpen && Time.unscaledTime - lastDataTime < 1f;
        public bool IsSimulated => !IsConnected && keyboardWhenDisconnected;
        public string SourceName => IsConnected ? transport.Name : IsSimulated ? "Teclado (simulado)" : "Sin control";
        public string TransportStatus => transport != null ? transport.Status : "sin transporte";

        // ------------- Métricas -------------
        public float LastRttMs { get; private set; } = -1;
        public float AvgRttMs { get; private set; } = -1;
        public float PacketRateHz { get; private set; }
        public int PacketsReceived { get; private set; }
        public int PacketsLost { get; private set; }
        public float PacketLossPercent => PacketsReceived + PacketsLost == 0 ? 0 : 100f * PacketsLost / (PacketsReceived + PacketsLost);

        public event System.Action<float> OnRttMeasured;   // ms

        ILinkTransport transport;
        readonly List<string> lineBuffer = new List<string>();
        float lastDataTime = -10f, lastReconnect = -10f, lastPing;
        int lastSeq = -1, pingId;
        readonly Dictionary<int, double> pendingPings = new Dictionary<int, double>();
        readonly float[] lastPatternTime = new float[4];
        int rateCount; float rateWindowStart;
        bool prevCollect, longFired, veryLongFired;
        float pressStart;
        float simPitch, simRoll;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;
            transport = CreateTransport();
        }

        /// <summary>Las pruebas automáticas lo activan para no abrir el puerto serie ni el Bluetooth.</summary>
        public static bool DisableTransport;

        ILinkTransport CreateTransport()
        {
            if (DisableTransport) return null;
#if UNITY_ANDROID && !UNITY_EDITOR
            return new AndroidBluetoothTransport(deviceName);
#elif TELEOP_SERIAL && (UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN)
            return string.IsNullOrWhiteSpace(serialPort) ? null : new SerialPortTransport(serialPort.Trim(), serialBaud);
#else
            return null;
#endif
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
            transport?.Dispose();
        }

        void OnApplicationPause(bool paused)
        {
            if (paused) Send("V,0,0");
        }

        void Update()
        {
            if (transport != null && !transport.IsOpen && Time.unscaledTime - lastReconnect > reconnectInterval)
            {
                lastReconnect = Time.unscaledTime;
                transport.Open();
            }

            if (transport != null)
            {
                lineBuffer.Clear();
                transport.ReadLines(lineBuffer);
                foreach (var line in lineBuffer) Parse(line);
            }

            if (IsConnected && Time.unscaledTime - lastPing >= 1f)
            {
                lastPing = Time.unscaledTime;
                pingId++;
                pendingPings[pingId] = Time.realtimeSinceStartupAsDouble;
                if (pendingPings.Count > 10) pendingPings.Clear();   // pings perdidos
                Send("P," + pingId);
            }

            if (overrideActive) ApplyOverride();
            else if (IsSimulated) Simulate();
            else if (!IsConnected) { Pitch = Roll = 0; Joystick = Vector2.zero; CollectHeld = false; }

            UpdateButtonGestures();

            if (Time.unscaledTime - rateWindowStart >= 1f)
            {
                PacketRateHz = rateCount / (Time.unscaledTime - rateWindowStart);
                rateCount = 0;
                rateWindowStart = Time.unscaledTime;
            }
        }

        /// <summary>Clic, pulsación larga y muy larga del botón del joystick.</summary>
        void UpdateButtonGestures()
        {
            CollectPressedThisFrame = CollectHeld && !prevCollect;
            CollectReleasedThisFrame = !CollectHeld && prevCollect;
            prevCollect = CollectHeld;
            CollectClickedThisFrame = LongPressThisFrame = VeryLongPressThisFrame = false;

            if (CollectPressedThisFrame)
            {
                pressStart = Time.unscaledTime;
                longFired = veryLongFired = false;
            }
            if (CollectHeld)
            {
                float held = Time.unscaledTime - pressStart;
                if (!longFired && held >= longPressTime) { longFired = true; LongPressThisFrame = true; }
                if (!veryLongFired && held >= veryLongPressTime) { veryLongFired = true; VeryLongPressThisFrame = true; }
            }
            if (CollectReleasedThisFrame && Time.unscaledTime - pressStart <= clickMaxDuration)
                CollectClickedThisFrame = true;
        }

        void Parse(string line)
        {
            if (line.Length < 1 || line[0] == '#') return;   // '#' = mensajes de depuración del firmware
            var f = line.Split(',');
            switch (f[0])
            {
                case "D":
                    if (f.Length < 6) return;
                    if (!int.TryParse(f[1], out int seq) || !int.TryParse(f[2], out int p) ||
                        !int.TryParse(f[3], out int r) || !int.TryParse(f[4], out int b)) return;
                    int.TryParse(f[5], out int bat);
                    if (lastSeq >= 0)
                    {
                        int gap = (seq - lastSeq + 65536) % 65536 - 1;
                        if (gap > 0 && gap < 1000) PacketsLost += gap;
                    }
                    lastSeq = seq;
                    PacketsReceived++;
                    rateCount++;
                    lastDataTime = Time.unscaledTime;
                    Pitch = p / 100f;
                    Roll = r / 100f;
                    CollectHeld = (b & 1) != 0;
                    BatteryMv = bat;
                    // Joystick (campos 7 y 8, en milésimas). Si el firmware aún no los envía, queda en cero.
                    if (f.Length >= 8 && int.TryParse(f[6], out int jx) && int.TryParse(f[7], out int jy))
                        Joystick = new Vector2(Mathf.Clamp(jx / 1000f, -1f, 1f), Mathf.Clamp(jy / 1000f, -1f, 1f));
                    else
                        Joystick = Vector2.zero;
                    break;

                case "P":
                    if (f.Length >= 2 && int.TryParse(f[1], out int id) && pendingPings.TryGetValue(id, out double sent))
                    {
                        pendingPings.Remove(id);
                        LastRttMs = (float)((Time.realtimeSinceStartupAsDouble - sent) * 1000.0);
                        AvgRttMs = AvgRttMs < 0 ? LastRttMs : Mathf.Lerp(AvgRttMs, LastRttMs, 0.2f);
                        OnRttMeasured?.Invoke(LastRttMs);
                    }
                    break;

                case "H":
                    Debug.Log("[HapticLink] Control conectado: " + line);
                    lastSeq = -1;
                    break;

                case "K":
                    Debug.Log("[HapticLink] Calibración del control: " + line);
                    break;
            }
        }

        void Simulate()
        {
            float target(KeyCode neg, KeyCode pos) =>
                (Input.GetKey(pos) ? simulatedMaxAngle : 0f) - (Input.GetKey(neg) ? simulatedMaxAngle : 0f);
            simPitch = Mathf.MoveTowards(simPitch, target(KeyCode.DownArrow, KeyCode.UpArrow), simulatedRate * Time.deltaTime);
            simRoll = Mathf.MoveTowards(simRoll, target(KeyCode.LeftArrow, KeyCode.RightArrow), simulatedRate * Time.deltaTime);
            Pitch = simPitch;
            Roll = simRoll;
            CollectHeld = Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.G);
            float jx = (Input.GetKey(KeyCode.D) ? 1f : 0f) - (Input.GetKey(KeyCode.A) ? 1f : 0f);
            float jy = (Input.GetKey(KeyCode.W) ? 1f : 0f) - (Input.GetKey(KeyCode.S) ? 1f : 0f);
            Joystick = Vector2.ClampMagnitude(new Vector2(jx, jy), 1f);
            BatteryMv = 0;
        }

        // ------------------ Entrada forzada (pruebas automáticas) ------------------

        bool overrideActive, ovCollect;
        float ovPitch, ovRoll;
        Vector2 ovJoy;

        /// <summary>Fuerza el estado del control, ignorando el enlace y el teclado. Lo usan las pruebas en modo Play.</summary>
        public void OverrideInput(float pitch, float roll, Vector2 joystick, bool collect)
        {
            overrideActive = true;
            ovPitch = pitch; ovRoll = roll; ovJoy = joystick; ovCollect = collect;
        }

        public void ClearOverride() => overrideActive = false;

        void ApplyOverride()
        {
            Pitch = ovPitch; Roll = ovRoll; Joystick = ovJoy; CollectHeld = ovCollect;
        }

        // ------------------ Comandos hacia el control ------------------

        public void Send(string line)
        {
            if (transport != null && transport.IsOpen) transport.WriteLine(line);
        }

        /// <summary>Envía un patrón de vibración. Devuelve false si se descartó por el tiempo mínimo entre repeticiones.</summary>
        public bool Vibrate(HapticPattern pattern, int intensity = 255)
        {
            int i = (int)pattern;
            if (pattern != HapticPattern.Stop)
            {
                if (Time.unscaledTime - lastPatternTime[i] < patternCooldown) return false;
                lastPatternTime[i] = Time.unscaledTime;
            }
            Send(string.Format(CultureInfo.InvariantCulture, "V,{0},{1}", i, Mathf.Clamp(intensity, 0, 255)));
            if (IsSimulated && pattern != HapticPattern.Stop)
                Debug.Log($"[HapticLink] (simulado) vibración {pattern} intensidad {intensity}");
            return true;
        }

        [Tooltip("Cada cuánto se renueva una vibración sostenida mientras dura el contacto (s)")]
        public float sustainInterval = 0.1f;
        float lastSustain = -10f;

        /// <summary>
        /// Vibración sostenida: llamar en cada cuadro mientras dure el contacto. Se reenvía cada sustainInterval
        /// y el firmware la mantiene encendida; se apaga sola unos 250 ms después de la última renovación.
        /// Devuelve true solo al empezar un contacto nuevo (sirve para contar choques).
        /// </summary>
        public bool VibrateSustained(HapticPattern pattern, int intensity = 255)
        {
            float now = Time.unscaledTime;
            bool isNew = now - lastSustain > 0.3f;
            if (now - lastSustain < sustainInterval) return false;
            lastSustain = now;
            lastPatternTime[(int)pattern] = now;
            Send(string.Format(CultureInfo.InvariantCulture, "V,{0},{1}", (int)pattern, Mathf.Clamp(intensity, 0, 255)));
            if (isNew && IsSimulated) Debug.Log($"[HapticLink] (simulado) vibración sostenida {pattern}");
            return isNew;
        }

        /// <summary>Toma la inclinación actual del control como cero.</summary>
        public void ZeroController()
        {
            Send("C");
            simPitch = simRoll = 0;
        }

        public void RecalibrateGyro() => Send("G");
    }
}
