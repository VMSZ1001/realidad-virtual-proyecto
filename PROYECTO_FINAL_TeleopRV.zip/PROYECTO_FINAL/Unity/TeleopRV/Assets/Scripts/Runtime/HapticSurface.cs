using UnityEngine;

namespace TeleopRV
{
    public enum SurfaceType { Wall, Obstacle }

    /// <summary>Marca un collider como pared/límite u obstáculo: al chocar se envía el patrón PARED.</summary>
    public class HapticSurface : MonoBehaviour
    {
        public SurfaceType type = SurfaceType.Wall;
    }
}
