using System.Text;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Panel de información en el mundo 3D (visible en estéreo). Sigue la mirada con retraso ("lazy follow")
    /// para no marear: solo se reubica cuando la cabeza se aleja más de cierto ángulo.
    /// </summary>
    public class HudDisplay : MonoBehaviour
    {
        public CardboardRig head;
        public TextMesh text;
        public TextMesh messageText;
        [Tooltip("Fondo semitransparente; se ajusta al tamaño del texto")] public Transform background;
        public Vector2 backgroundMargin = new Vector2(0.06f, 0.04f);
        public RobotController robot;
        public TaskManager task;
        public AvatarController avatar;

        public float distance = 1.6f;
        public float heightOffset = -0.55f;
        [Tooltip("Ángulo a partir del cual el panel vuelve a ponerse al frente (°)")] public float followAngle = 35f;
        public float followSpeed = 3f;
        public float messageDuration = 3f;

        readonly StringBuilder sb = new StringBuilder(256);
        float targetYaw, messageUntil;
        bool initialized;

        void Start()
        {
            if (task != null) task.OnMessage += ShowMessage;
            if (avatar != null) avatar.OnRecentered += () => { initialized = false; ShowMessage("Vista y control recentrados"); };
        }

        public void ShowMessage(string msg)
        {
            if (messageText == null) return;
            messageText.text = msg;
            messageUntil = Time.time + messageDuration;
        }

        void LateUpdate()
        {
            if (head == null) return;

            float yaw = head.transform.eulerAngles.y;
            if (!initialized || Mathf.Abs(Mathf.DeltaAngle(targetYaw, yaw)) > followAngle)
            {
                targetYaw = yaw;
            }
            float currentYaw = initialized ? Mathf.LerpAngle(transform.eulerAngles.y, targetYaw, followSpeed * Time.deltaTime) : targetYaw;
            initialized = true;

            Quaternion rot = Quaternion.Euler(0f, currentYaw, 0f);
            Vector3 pos = head.transform.position + rot * new Vector3(0f, heightOffset, distance);
            // Inclinar el panel hacia los ojos
            Vector3 toEye = head.transform.position - pos;
            transform.SetPositionAndRotation(pos, Quaternion.LookRotation(-toEye.normalized, Vector3.up));

            if (messageText != null && Time.time > messageUntil) messageText.text = "";
            if (text != null)
            {
                text.text = BuildText();
                FitBackground();
            }
        }

        void FitBackground()
        {
            if (background == null) return;
            var r = text.GetComponent<Renderer>();
            if (r == null) return;
            Bounds b = r.localBounds;   // en el espacio local del texto
            Vector3 center = text.transform.localPosition + b.center;
            background.localPosition = new Vector3(center.x, center.y, background.localPosition.z);
            background.localScale = new Vector3(b.size.x + backgroundMargin.x, b.size.y + backgroundMargin.y, 1f);
        }

        string BuildText()
        {
            var l = HapticLink.Instance;
            sb.Clear();
            if (l == null) return "Sin HapticLink";

            sb.Append("Control: ").Append(l.SourceName);
            if (!l.IsConnected && l.TransportStatus != "sin transporte") sb.Append(" (").Append(l.TransportStatus).Append(')');
            if (l.BatteryMv > 0) sb.AppendFormat("   Bat {0:0.00} V", l.BatteryMv / 1000f);
            sb.Append('\n');

            if (l.IsConnected)
                sb.AppendFormat("Latencia {0:0} ms (RTT {1:0})   {2:0} Hz   pérdida {3:0.0} %\n",
                    l.AvgRttMs * 0.5f, l.AvgRttMs, l.PacketRateHz, l.PacketLossPercent);

            if (robot != null)
            {
                sb.AppendFormat("Pitch {0,6:+0.0;-0.0}°  ->  v {1,5:+0.00;-0.00} m/s\n", l.Pitch, robot.Speed);
                sb.AppendFormat("Roll  {0,6:+0.0;-0.0}°  ->  ω {1,5:+0;-0} °/s\n", l.Roll, robot.TurnRate);
            }

            if (task != null)
            {
                string state = task.Current == TaskManager.State.Waiting ? "mueve el robot para empezar"
                             : task.Current == TaskManager.State.Done ? "COMPLETADA" : "en curso";
                sb.AppendFormat("Tarea {0}/{1}   {2:0.0} s   choques {3}   ({4})",
                    task.Delivered, task.TargetCount, task.ElapsedTime, task.Collisions, state);
            }

            // Progreso de la pulsación larga del botón del joystick
            float held = l.CollectHeldTime;
            if (held > l.clickMaxDuration)
            {
                sb.Append('\n');
                if (held < l.longPressTime) sb.AppendFormat("Recentrar en {0:0.0} s...", l.longPressTime - held);
                else if (held < l.veryLongPressTime) sb.AppendFormat("Recentrado. Reiniciar tarea en {0:0.0} s...", l.veryLongPressTime - held);
                else sb.Append("Tarea reiniciada");
            }
            return sb.ToString();
        }
    }
}
