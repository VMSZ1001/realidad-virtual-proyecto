using System.Collections.Generic;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>Sonido 3D de impacto generado por código (no requiere archivos de audio).</summary>
    [RequireComponent(typeof(AudioSource))]
    public class ImpactAudio : MonoBehaviour
    {
        AudioSource source;
        readonly Dictionary<int, AudioClip> cache = new Dictionary<int, AudioClip>();

        void Awake()
        {
            source = GetComponent<AudioSource>();
            source.playOnAwake = false;
            source.spatialBlend = 1f;
            source.minDistance = 1f;
            source.maxDistance = 25f;
        }

        public void Play(float frequency, float volume)
        {
            int key = Mathf.RoundToInt(frequency);
            if (!cache.TryGetValue(key, out var clip)) cache[key] = clip = MakeClip(frequency);
            source.pitch = Random.Range(0.92f, 1.08f);
            source.PlayOneShot(clip, Mathf.Clamp01(volume));
        }

        static AudioClip MakeClip(float freq)
        {
            const int rate = 44100;
            int n = rate / 6;
            var data = new float[n];
            var rng = new System.Random(Seed(freq));
            for (int i = 0; i < n; i++)
            {
                float t = i / (float)rate;
                float env = Mathf.Exp(-t * 28f);
                float tone = Mathf.Sin(2f * Mathf.PI * freq * t) + 0.5f * Mathf.Sin(2f * Mathf.PI * freq * 2.7f * t);
                float noise = (float)(rng.NextDouble() * 2 - 1) * Mathf.Exp(-t * 90f);
                data[i] = 0.5f * env * tone + 0.35f * noise;
            }
            var clip = AudioClip.Create("impacto_" + freq, n, 1, rate, false);
            clip.SetData(data, 0);
            return clip;
        }

        static int Seed(float f) => Mathf.RoundToInt(f * 10f);
    }
}
