using System;
using System.Collections.Generic;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>Canal de texto por líneas hacia el control háptico.</summary>
    public interface ILinkTransport : IDisposable
    {
        string Name { get; }
        bool IsOpen { get; }
        string Status { get; }
        void Open();
        void WriteLine(string line);
        /// <summary>Agrega a <paramref name="into"/> las líneas recibidas desde la última llamada.</summary>
        void ReadLines(List<string> into);
    }

#if UNITY_ANDROID && !UNITY_EDITOR
    /// <summary>Bluetooth SPP en Android mediante Plugins/Android/BtSpp.java.</summary>
    public class AndroidBluetoothTransport : ILinkTransport
    {
        readonly string deviceName;
        AndroidJavaObject bridge;

        public AndroidBluetoothTransport(string deviceName) { this.deviceName = deviceName; }

        public string Name => "Bluetooth";
        public bool IsOpen => bridge != null && bridge.Call<bool>("isConnected");
        public string Status => bridge != null ? bridge.Call<string>("getStatus") : "inactivo";

        public void Open()
        {
            if (!AndroidPermissions.HasBluetoothConnect())
            {
                AndroidPermissions.RequestBluetoothConnect();
                return;
            }
            if (bridge == null) bridge = new AndroidJavaObject("com.umng.teleoprv.BtSpp");
            if (!bridge.Call<bool>("isConnecting") && !bridge.Call<bool>("isConnected"))
                bridge.Call("connectAsync", deviceName);
        }

        public void WriteLine(string line)
        {
            if (bridge != null) bridge.Call<bool>("write", line + "\n");
        }

        public void ReadLines(List<string> into)
        {
            if (bridge == null) return;
            string block = bridge.Call<string>("pollAll");
            if (string.IsNullOrEmpty(block)) return;
            foreach (var l in block.Split('\n'))
                if (l.Length > 0) into.Add(l);
        }

        public void Dispose()
        {
            if (bridge == null) return;
            bridge.Call("close");
            bridge.Dispose();
            bridge = null;
        }
    }

    public static class AndroidPermissions
    {
        const string BluetoothConnect = "android.permission.BLUETOOTH_CONNECT";

        static int SdkInt()
        {
            using (var version = new AndroidJavaClass("android.os.Build$VERSION"))
                return version.GetStatic<int>("SDK_INT");
        }

        // BLUETOOTH_CONNECT solo existe como permiso en tiempo de ejecución desde Android 12 (API 31)
        public static bool HasBluetoothConnect() =>
            SdkInt() < 31 || UnityEngine.Android.Permission.HasUserAuthorizedPermission(BluetoothConnect);

        public static void RequestBluetoothConnect() =>
            UnityEngine.Android.Permission.RequestUserPermission(BluetoothConnect);
    }
#endif

#if TELEOP_SERIAL && (UNITY_EDITOR_WIN || UNITY_STANDALONE_WIN)
    /// <summary>
    /// Puerto COM de Windows: el cable USB del ESP32, o el puerto "Bluetooth estándar por vínculo serie"
    /// que crea Windows al emparejar HapticRV. Sirve para probar en el editor sin compilar el APK.
    /// </summary>
    public class SerialPortTransport : ILinkTransport
    {
        readonly string portName;
        readonly int baud;
        volatile System.IO.Ports.SerialPort port;
        volatile System.Threading.Thread worker;
        readonly System.Collections.Concurrent.ConcurrentQueue<string> queue = new System.Collections.Concurrent.ConcurrentQueue<string>();
        volatile string status = "inactivo";

        public SerialPortTransport(string portName, int baud) { this.portName = portName; this.baud = baud; }

        public string Name => "Serie " + portName;
        public bool IsOpen { get { var p = port; return p != null && p.IsOpen; } }
        public string Status => status;

        /// <summary>
        /// Abre el puerto en un hilo aparte: en los puertos Bluetooth de Windows, Open() puede bloquear
        /// varios segundos si el ESP32 está apagado u ocupado, y no debe congelar Unity.
        /// </summary>
        public void Open()
        {
            if (IsOpen || worker != null) return;
            status = "conectando";
            worker = new System.Threading.Thread(OpenAndRead) { IsBackground = true, Name = "SerialPort " + portName };
            worker.Start();
        }

        void OpenAndRead()
        {
            try
            {
                var p = new System.IO.Ports.SerialPort(portName, baud)
                {
                    NewLine = "\n", ReadTimeout = 500, WriteTimeout = 200, DtrEnable = false, RtsEnable = false
                };
                p.Open();
                port = p;
                status = "conectado";
                while (p.IsOpen)
                {
                    try { queue.Enqueue(p.ReadLine().TrimEnd('\r')); }
                    catch (TimeoutException) { }
                }
            }
            catch (Exception e)
            {
                status = "error: " + e.Message;
            }
            finally
            {
                try { port?.Close(); } catch { }
                port = null;
                worker = null;
            }
        }

        public void WriteLine(string line)
        {
            var p = port;
            try { if (p != null && p.IsOpen) p.Write(line + "\n"); }
            catch (Exception e) { status = "error: " + e.Message; }
        }

        public void ReadLines(List<string> into)
        {
            while (queue.TryDequeue(out var l)) into.Add(l);
        }

        public void Dispose()
        {
            try { port?.Close(); } catch { }
            port = null;
        }
    }
#endif
}
