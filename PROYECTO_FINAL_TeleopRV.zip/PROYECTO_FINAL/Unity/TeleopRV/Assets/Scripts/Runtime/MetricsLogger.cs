using System;
using System.Globalization;
using System.IO;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Guarda las métricas de la sesión en CSV (separador coma, decimal punto) en
    /// Application.persistentDataPath/Metricas. En Android: Android/data/com.umng.teleoprv/files/Metricas.
    /// Se analizan con Docs/analisis/analizar_metricas.py.
    /// </summary>
    public class MetricsLogger : MonoBehaviour
    {
        public static MetricsLogger Instance { get; private set; }

        public RobotController robot;
        public RobotGripper gripper;
        [Tooltip("Frecuencia de muestreo del archivo de sesión (Hz)")] public float sampleRate = 10f;

        public string Folder { get; private set; }

        StreamWriter session, events, latency;
        float nextSample, nextFlush;
        static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

        void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss", Inv);
            Folder = Path.Combine(Application.persistentDataPath, "Metricas");
            try
            {
                Directory.CreateDirectory(Folder);
                session = Open($"sesion_{stamp}.csv", "t_s,pitch_deg,roll_deg,v_cmd_ms,w_cmd_dps,v_ms,w_dps,recolectar,joy_x,joy_y,sujetando,fuente,tasa_hz,perdidos,rtt_ms");
                events = Open($"eventos_{stamp}.csv", "t_s,tipo,detalle,valor,patron,intensidad");
                latency = Open($"latencia_{stamp}.csv", "t_s,rtt_ms,latencia_ms");
                Debug.Log("[Metricas] Guardando en " + Folder);
            }
            catch (Exception e)
            {
                Debug.LogWarning("[Metricas] No se pudo crear la carpeta: " + e.Message);
            }
        }

        StreamWriter Open(string name, string header)
        {
            var w = new StreamWriter(Path.Combine(Folder, name), false, new System.Text.UTF8Encoding(false));
            w.WriteLine(header);
            return w;
        }

        void OnEnable()
        {
            if (HapticLink.Instance != null) HapticLink.Instance.OnRttMeasured += LogRtt;
        }

        void Start()
        {
            // HapticLink puede despertar después de OnEnable
            if (HapticLink.Instance != null)
            {
                HapticLink.Instance.OnRttMeasured -= LogRtt;
                HapticLink.Instance.OnRttMeasured += LogRtt;
            }
        }

        void LogRtt(float rtt)
        {
            latency?.WriteLine(string.Format(Inv, "{0:0.000},{1:0.0},{2:0.0}", Time.time, rtt, rtt * 0.5f));
        }

        public void LogEvent(string type, string detail, float value, int pattern, int intensity)
        {
            events?.WriteLine(string.Format(Inv, "{0:0.000},{1},{2},{3:0.000},{4},{5}",
                Time.time, type, (detail ?? "").Replace(',', ' '), value, pattern, intensity));
        }

        void Update()
        {
            if (session != null && Time.time >= nextSample)
            {
                nextSample = Time.time + 1f / sampleRate;
                var l = HapticLink.Instance;
                if (l != null)
                {
                    session.WriteLine(string.Format(Inv,
                        "{0:0.000},{1:0.00},{2:0.00},{3:0.000},{4:0.0},{5:0.000},{6:0.0},{7},{8:0.00},{9:0.00},{10},{11},{12:0.0},{13},{14:0.0}",
                        Time.time, l.Pitch, l.Roll,
                        robot != null ? robot.CommandSpeed : 0f, robot != null ? robot.CommandTurn : 0f,
                        robot != null ? robot.Speed : 0f, robot != null ? robot.TurnRate : 0f,
                        l.CollectHeld ? 1 : 0, l.Joystick.x, l.Joystick.y,
                        gripper != null && gripper.Held != null ? 1 : 0,
                        l.IsConnected ? "control" : l.IsSimulated ? "teclado" : "ninguno",
                        l.PacketRateHz, l.PacketsLost, l.LastRttMs));
                }
            }

            if (Time.unscaledTime >= nextFlush)
            {
                nextFlush = Time.unscaledTime + 2f;
                Flush();
            }
        }

        void Flush()
        {
            session?.Flush();
            events?.Flush();
            latency?.Flush();
        }

        void OnApplicationPause(bool paused)
        {
            if (paused) Flush();   // Android puede cerrar la app en segundo plano sin avisar
        }

        void OnDestroy()
        {
            if (HapticLink.Instance != null) HapticLink.Instance.OnRttMeasured -= LogRtt;
            session?.Dispose();
            events?.Dispose();
            latency?.Dispose();
            if (Instance == this) Instance = null;
        }
    }
}
