using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Robot móvil de tracción diferencial. Pitch del control -> velocidad lineal v; Roll -> velocidad angular ω.
    /// v = v_max · f(pitch), ω = ω_max · f(roll), luego filtro de primer orden (τ) y límite de aceleración.
    /// Detecta colisiones y dispara el patrón háptico que corresponde.
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class RobotController : MonoBehaviour
    {
        [Header("Mapeo de control")]
        public ControlMode mode = ControlMode.Proportional;
        public AxisMapping pitchToSpeed = new AxisMapping();
        public AxisMapping rollToTurn = new AxisMapping { deadZone = 5f, maxAngle = 35f, gamma = 1.5f };
        [Tooltip("Velocidad lineal máxima (m/s)")] public float maxSpeed = 1.2f;
        [Tooltip("Velocidad angular máxima (°/s)")] public float maxTurnRate = 90f;
        [Tooltip("Constante de tiempo del filtro de suavizado (s)")] public float smoothingTau = 0.12f;
        [Tooltip("Aceleración lineal máxima (m/s²)")] public float maxAcceleration = 3f;
        [Range(0.1f, 2f)] public float sensitivity = 1f;

        [Header("Colisiones")]
        [Tooltip("Velocidad de impacto (m/s) que corresponde al volumen máximo del sonido de choque")] public float fullIntensityImpact = 1.5f;

        [Header("Visual")]
        public Transform[] leftWheels;
        public Transform[] rightWheels;
        public float wheelRadius = 0.09f;
        public float trackWidth = 0.42f;

        public float Speed { get; private set; }        // m/s filtrada
        public float TurnRate { get; private set; }     // °/s filtrada
        public float CommandSpeed { get; private set; } // m/s antes del filtro
        public float CommandTurn { get; private set; }  // °/s antes del filtro
        public bool HasMoved { get; private set; }

        public event System.Action<string, float> OnCollisionReported;   // tipo, velocidad de impacto

        Rigidbody rb;
        ImpactAudio impactAudio;
        Vector3 startPos;
        Quaternion startRot;

        void Awake()
        {
            rb = GetComponent<Rigidbody>();
            rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationZ;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            impactAudio = GetComponent<ImpactAudio>();
            startPos = transform.position;
            startRot = transform.rotation;
        }

        float MapAxis(AxisMapping m, float angle)
        {
            float f = m.Evaluate(angle);
            if (mode == ControlMode.Threshold) f = Mathf.Abs(f) > 0f ? Mathf.Sign(f) : 0f;
            return f;
        }

        void FixedUpdate()
        {
            var link = HapticLink.Instance;
            float pitch = link != null ? link.Pitch : 0f;
            float roll = link != null ? link.Roll : 0f;

            CommandSpeed = maxSpeed * sensitivity * MapAxis(pitchToSpeed, pitch);
            CommandTurn = maxTurnRate * sensitivity * MapAxis(rollToTurn, roll);

            // Filtro de primer orden discreto: y += (u − y)·(1 − e^(−dt/τ))
            float k = smoothingTau > 0f ? 1f - Mathf.Exp(-Time.fixedDeltaTime / smoothingTau) : 1f;
            float targetSpeed = Mathf.Lerp(Speed, CommandSpeed, k);
            Speed = Mathf.MoveTowards(Speed, targetSpeed, maxAcceleration * Time.fixedDeltaTime);
            TurnRate = Mathf.Lerp(TurnRate, CommandTurn, k);
            if (Mathf.Abs(CommandSpeed) > 0.01f || Mathf.Abs(CommandTurn) > 0.5f) HasMoved = true;

            Vector3 v = transform.forward * Speed;
            rb.linearVelocity = new Vector3(v.x, rb.linearVelocity.y, v.z);
            rb.angularVelocity = new Vector3(0f, TurnRate * Mathf.Deg2Rad, 0f);
        }

        void Update()
        {
            // Giro visual de las ruedas según la cinemática diferencial
            float w = TurnRate * Mathf.Deg2Rad;
            float vl = Speed - w * trackWidth * 0.5f, vr = Speed + w * trackWidth * 0.5f;
            SpinWheels(leftWheels, vl);
            SpinWheels(rightWheels, vr);

            if (transform.position.y < -5f) ResetPose();   // por si se sale del mundo
        }

        void SpinWheels(Transform[] wheels, float linear)
        {
            if (wheels == null) return;
            float deg = linear / wheelRadius * Mathf.Rad2Deg * Time.deltaTime;
            foreach (var t in wheels) if (t != null) t.Rotate(Vector3.right, deg, Space.Self);
        }

        public void ResetPose()
        {
            rb.position = startPos;
            rb.rotation = startRot;
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            Speed = TurnRate = 0f;
        }

        public void ClearMovedFlag() => HasMoved = false;

        void OnCollisionEnter(Collision c)
        {
            float impact = c.relativeVelocity.magnitude;
            var grabbable = c.collider.GetComponentInParent<Grabbable>();
            if (grabbable != null)
            {
                if (!grabbable.IsHeld) ObjectHit(impact);
                return;
            }
            var surface = c.collider.GetComponentInParent<HapticSurface>();
            if (surface != null) ReportCollision(surface, impact, KindOf(surface), true);
        }

        void OnCollisionStay(Collision c)
        {
            var surface = c.collider.GetComponentInParent<HapticSurface>();
            if (surface != null) ReportCollision(surface, c.relativeVelocity.magnitude, KindOf(surface), false);
        }

        static string KindOf(HapticSurface s) => s.type == SurfaceType.Wall ? "pared" : "obstaculo";

        /// <summary>
        /// Contacto con pared u obstáculo (del robot o del objeto que sujeta): vibración sostenida al 100 %
        /// mientras dure el contacto. En un contacto que ya existía solo se mantiene si el usuario sigue empujando,
        /// para que el robot estacionado junto a una pared no vibre sin parar.
        /// </summary>
        public void ReportCollision(HapticSurface surface, float impact, string kind, bool firstContact)
        {
            bool pushing = Mathf.Abs(CommandSpeed) > 0.05f || Mathf.Abs(CommandTurn) > 5f;
            if (!firstContact && !pushing) return;
            var link = HapticLink.Instance;
            bool isNew = link != null && link.VibrateSustained(HapticPattern.Wall, 255);
            if (!isNew) return;   // mismo contacto: la vibración ya está sostenida
            if (impactAudio != null) impactAudio.Play(110f, Mathf.Clamp01(impact / fullIntensityImpact) * 0.7f + 0.3f);
            MetricsLogger.Instance?.LogEvent("colision", kind, impact, (int)HapticPattern.Wall, 255);
            OnCollisionReported?.Invoke(kind, impact);
        }

        /// <summary>Choque con un objeto manipulable: dos pulsos al 100 %.</summary>
        void ObjectHit(float impact)
        {
            bool sent = HapticLink.Instance != null && HapticLink.Instance.Vibrate(HapticPattern.Object, 255);
            if (!sent) return;   // dentro del tiempo mínimo entre repeticiones: es el mismo choque
            if (impactAudio != null) impactAudio.Play(440f, Mathf.Clamp01(impact / fullIntensityImpact) * 0.7f + 0.3f);
            MetricsLogger.Instance?.LogEvent("colision", "objeto", impact, (int)HapticPattern.Object, 255);
            OnCollisionReported?.Invoke("objeto", impact);
        }
    }
}
