using System.Collections.Generic;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Pinza del robot: un trigger al frente detecta objetos agarrables. Con un clic del botón del joystick (RECOLECTAR) se sujeta el más
    /// cercano con un FixedJoint (attach); otro clic lo libera (detach).
    /// </summary>
    public class RobotGripper : MonoBehaviour
    {
        public RobotController Robot;
        [Tooltip("Punto donde queda el objeto agarrado")] public Transform gripPoint;
        [Tooltip("Dedos de la pinza (se cierran al agarrar)")] public Transform leftFinger, rightFinger;
        public float fingerOpen = 0.12f, fingerClosed = 0.07f;
        [Tooltip("true = un clic del botón del joystick agarra y otro suelta; false = mantener presionado para sujetar")]
        public bool toggleMode = true;

        public Grabbable Held { get; private set; }

        readonly HashSet<Grabbable> inRange = new HashSet<Grabbable>();
        Grabbable highlighted;
        FixedJoint joint;
        Rigidbody robotBody;

        void Awake()
        {
            if (Robot == null) Robot = GetComponentInParent<RobotController>();
            robotBody = Robot.GetComponent<Rigidbody>();
        }

        void OnTriggerEnter(Collider other)
        {
            var g = other.GetComponentInParent<Grabbable>();
            if (g != null) inRange.Add(g);
        }

        void OnTriggerExit(Collider other)
        {
            var g = other.GetComponentInParent<Grabbable>();
            if (g != null) inRange.Remove(g);
        }

        void Update()
        {
            var link = HapticLink.Instance;
            if (link != null)
            {
                if (toggleMode)
                {
                    // Clic corto (se evalúa al soltar, para no confundirlo con la pulsación larga de recentrado)
                    if (link.CollectClickedThisFrame)
                    {
                        if (Held == null) TryGrab();
                        else Release();
                    }
                }
                else
                {
                    // Mantener presionado: agarra en cuanto hay un objeto al alcance y suelta al dejar de presionar
                    if (link.CollectHeld && Held == null) TryGrab();
                    else if (!link.CollectHeld && Held != null) Release();
                }
            }

            // Resaltar el candidato más cercano
            var candidate = Held == null ? Nearest() : null;
            if (candidate != highlighted)
            {
                if (highlighted != null) highlighted.SetHighlight(false);
                if (candidate != null) candidate.SetHighlight(true);
                highlighted = candidate;
            }

            float target = Held != null ? fingerClosed : fingerOpen;
            MoveFinger(leftFinger, -target);
            MoveFinger(rightFinger, target);

            // Si el joint se rompió por una fuerza excesiva
            if (Held != null && joint == null) Release();
        }

        void MoveFinger(Transform finger, float x)
        {
            if (finger == null) return;
            var p = finger.localPosition;
            p.x = Mathf.MoveTowards(p.x, x, 0.4f * Time.deltaTime);
            finger.localPosition = p;
        }

        Grabbable Nearest()
        {
            Grabbable best = null;
            float bestD = float.MaxValue;
            inRange.RemoveWhere(g => g == null || !g.gameObject.activeInHierarchy);
            foreach (var g in inRange)
            {
                if (g.IsHeld) continue;
                float d = (g.transform.position - gripPoint.position).sqrMagnitude;
                if (d < bestD) { bestD = d; best = g; }
            }
            return best;
        }

        void TryGrab()
        {
            var g = Nearest();
            if (g == null) return;

            g.SetHighlight(false);
            highlighted = null;
            g.Body.position = gripPoint.position;
            g.Body.rotation = gripPoint.rotation;
            g.Body.linearVelocity = robotBody.linearVelocity;
            g.Body.angularVelocity = Vector3.zero;
            g.transform.SetPositionAndRotation(gripPoint.position, gripPoint.rotation);

            joint = g.gameObject.AddComponent<FixedJoint>();
            joint.connectedBody = robotBody;
            joint.enableCollision = false;
            joint.breakForce = 2000f;

            g.HeldBy = this;
            Held = g;
            HapticLink.Instance?.Vibrate(HapticPattern.Grab, 255);   // un pulso al recoger
            MetricsLogger.Instance?.LogEvent("agarre", g.name, 0f, (int)HapticPattern.Grab, 255);
        }

        public void Release()
        {
            if (Held == null) return;
            if (joint != null) Destroy(joint);
            joint = null;
            var g = Held;
            g.HeldBy = null;
            Held = null;
            MetricsLogger.Instance?.LogEvent("suelta", g.name, 0f, 0, 0);   // soltar no vibra
        }
    }
}
