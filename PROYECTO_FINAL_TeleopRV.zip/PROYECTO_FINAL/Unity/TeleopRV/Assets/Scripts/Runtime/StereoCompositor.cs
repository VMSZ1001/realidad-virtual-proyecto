using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Compone la imagen final del Cardboard: cada ojo se renderiza a su propia textura y esta cámara (que no ve
    /// ningún objeto) las dibuja una en cada mitad de la pantalla aplicando la pre-distorsión en barril de
    /// Assets/Shaders/CardboardBarrel.shader: r' = r·(1 + k1·r² + k2·r⁴).
    /// </summary>
    [RequireComponent(typeof(Camera))]
    public class StereoCompositor : MonoBehaviour
    {
        public Material material;
        public RenderTexture left, right;
        [Range(0f, 0.6f)] public float k1 = 0.22f;
        [Range(0f, 0.6f)] public float k2 = 0.10f;

        static readonly int MainTex = Shader.PropertyToID("_MainTex");
        static readonly int K1 = Shader.PropertyToID("_K1");
        static readonly int K2 = Shader.PropertyToID("_K2");
        static readonly int Aspect = Shader.PropertyToID("_Aspect");

        void OnPostRender()
        {
            if (material == null || left == null || right == null) return;
            material.SetFloat(K1, k1);
            material.SetFloat(K2, k2);
            material.SetFloat(Aspect, (float)left.width / Mathf.Max(1, left.height));

            GL.PushMatrix();
            GL.LoadOrtho();
            DrawEye(left, 0f);
            DrawEye(right, 0.5f);
            GL.PopMatrix();
        }

        void DrawEye(RenderTexture tex, float x0)
        {
            material.SetTexture(MainTex, tex);
            material.SetPass(0);
            GL.Begin(GL.QUADS);
            GL.TexCoord2(0f, 0f); GL.Vertex3(x0, 0f, 0f);
            GL.TexCoord2(0f, 1f); GL.Vertex3(x0, 1f, 0f);
            GL.TexCoord2(1f, 1f); GL.Vertex3(x0 + 0.5f, 1f, 0f);
            GL.TexCoord2(1f, 0f); GL.Vertex3(x0 + 0.5f, 0f, 0f);
            GL.End();
        }
    }
}
