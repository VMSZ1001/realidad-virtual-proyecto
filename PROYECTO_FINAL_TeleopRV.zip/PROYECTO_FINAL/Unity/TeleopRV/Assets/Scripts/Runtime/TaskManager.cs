using System.Collections.Generic;
using UnityEngine;

namespace TeleopRV
{
    /// <summary>
    /// Tarea de prueba para la evaluación experimental: llevar todos los objetos de la tarea a la zona verde.
    /// El cronómetro arranca cuando el robot se mueve por primera vez. Se cuentan las colisiones.
    /// Reiniciar: tecla R, o mantener el botón del joystick 5 s.
    /// </summary>
    public class TaskManager : MonoBehaviour
    {
        public enum State { Waiting, Running, Done }

        public RobotController robot;
        public RobotGripper gripper;
        public DeliveryZone zone;

        public State Current { get; private set; } = State.Waiting;
        public float ElapsedTime => Current == State.Waiting ? 0f : (Current == State.Done ? endTime : Time.time) - startTime;
        public int TargetCount { get; private set; }
        public int Delivered => zone != null ? zone.Delivered : 0;
        public int Collisions { get; private set; }
        public int Attempt { get; private set; } = 1;

        public event System.Action<string> OnMessage;

        float startTime, endTime;
        readonly List<(Grabbable g, Vector3 p, Quaternion r)> initialPoses = new List<(Grabbable, Vector3, Quaternion)>();

        void Start()
        {
            foreach (var g in FindObjectsByType<Grabbable>(FindObjectsSortMode.None))
            {
                initialPoses.Add((g, g.transform.position, g.transform.rotation));
                if (g.isTaskTarget) TargetCount++;
            }
            if (robot != null) robot.OnCollisionReported += (kind, impact) => { if (Current == State.Running) Collisions++; };
            OnMessage?.Invoke("Lleva los cubos a la zona verde");
        }

        void Update()
        {
            switch (Current)
            {
                case State.Waiting:
                    if (robot != null && robot.HasMoved)
                    {
                        Current = State.Running;
                        startTime = Time.time;
                        Collisions = 0;
                        MetricsLogger.Instance?.LogEvent("tarea_inicio", "intento " + Attempt, 0f, 0, 0);
                    }
                    break;

                case State.Running:
                    if (TargetCount > 0 && Delivered >= TargetCount)
                    {
                        Current = State.Done;
                        endTime = Time.time;
                        zone.AllDelivered = true;
                        HapticLink.Instance?.Vibrate(HapticPattern.Grab, 255);
                        MetricsLogger.Instance?.LogEvent("tarea_fin", $"intento {Attempt}; colisiones {Collisions}", ElapsedTime, 0, 0);
                        OnMessage?.Invoke($"¡Tarea completada en {ElapsedTime:0.0} s!");
                    }
                    break;
            }

            var link = HapticLink.Instance;
            if (Input.GetKeyDown(KeyCode.R) || (link != null && link.VeryLongPressThisFrame)) Restart();
        }

        public void Restart()
        {
            if (gripper != null) gripper.Release();
            foreach (var (g, p, r) in initialPoses)
            {
                if (g == null) continue;
                g.Body.linearVelocity = Vector3.zero;
                g.Body.angularVelocity = Vector3.zero;
                g.Body.position = p;
                g.Body.rotation = r;
                g.transform.SetPositionAndRotation(p, r);
            }
            if (robot != null) robot.ResetPose();
            if (zone != null) zone.AllDelivered = false;
            Current = State.Waiting;
            Attempt++;
            MetricsLogger.Instance?.LogEvent("tarea_reinicio", "intento " + Attempt, 0f, 0, 0);
            OnMessage?.Invoke("Tarea reiniciada (intento " + Attempt + ")");
            // HasMoved se reinicia para que el cronómetro espere el primer movimiento
            if (robot != null) robot.ClearMovedFlag();
        }
    }
}
