// Distorsión en barril para lentes tipo Cardboard (una pasada por ojo).
Shader "TeleopRV/CardboardBarrel"
{
    Properties
    {
        _MainTex ("Imagen del ojo", 2D) = "white" {}
        _K1 ("k1", Float) = 0.22
        _K2 ("k2", Float) = 0.10
        _Aspect ("Relación de aspecto", Float) = 1.0
    }
    SubShader
    {
        Cull Off ZWrite Off ZTest Always
        Pass
        {
            CGPROGRAM
            #pragma vertex vert_img
            #pragma fragment frag
            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float _K1, _K2, _Aspect;

            fixed4 frag (v2f_img i) : SV_Target
            {
                // Coordenadas centradas y corregidas por aspecto para que la distorsión sea radial
                float2 p = i.uv * 2.0 - 1.0;
                p.x *= _Aspect;
                float r2 = dot(p, p);
                float scale = 1.0 + _K1 * r2 + _K2 * r2 * r2;
                // Normaliza para que el borde horizontal siga tocando el borde de la imagen
                float edge = _Aspect * _Aspect;
                float norm = 1.0 + _K1 * edge + _K2 * edge * edge;
                p *= scale / norm;
                p.x /= _Aspect;
                float2 uv = p * 0.5 + 0.5;
                if (any(uv < 0.0) || any(uv > 1.0)) return fixed4(0, 0, 0, 1);
                return tex2D(_MainTex, uv);
            }
            ENDCG
        }
    }
    Fallback Off
}
