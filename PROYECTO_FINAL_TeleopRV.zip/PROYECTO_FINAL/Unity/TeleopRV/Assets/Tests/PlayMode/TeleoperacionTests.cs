using System.Collections;
using System.Collections.Generic;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.TestTools;

namespace TeleopRV.Tests
{
    /// <summary>
    /// Pruebas en modo Play sobre la escena real. El control se simula con HapticLink.OverrideInput.
    /// Ejecutar: Window → General → Test Runner → PlayMode, o por lotes con -runTests -testPlatform PlayMode.
    /// </summary>
    public class TeleoperacionTests
    {
        HapticLink link;
        RobotController robot;
        RobotGripper gripper;
        AvatarController avatar;
        TaskManager task;

        [UnitySetUp]
        public IEnumerator CargarEscena()
        {
            HapticLink.DisableTransport = true;   // sin puerto serie: el control se simula con OverrideInput
            SceneManager.LoadScene("Teleoperacion");
            yield return null;
            yield return null;
            link = HapticLink.Instance;
            robot = Object.FindFirstObjectByType<RobotController>();
            gripper = Object.FindFirstObjectByType<RobotGripper>();
            avatar = Object.FindFirstObjectByType<AvatarController>();
            task = Object.FindFirstObjectByType<TaskManager>();
            Assert.IsNotNull(link, "Falta HapticLink");
            Assert.IsNotNull(robot, "Falta el robot");
            Assert.IsNotNull(gripper, "Falta la pinza");
            Assert.IsNotNull(avatar, "Falta el avatar");
            link.OverrideInput(0, 0, Vector2.zero, false);
            yield return new WaitForSeconds(0.3f);   // que el robot se asiente en el piso
        }

        [UnityTearDown]
        public IEnumerator Limpiar()
        {
            if (link != null) link.ClearOverride();
            HapticLink.DisableTransport = false;
            yield return null;
        }

        static IEnumerator Esperar(float s) { yield return new WaitForSeconds(s); }

        IEnumerator Clic()
        {
            link.OverrideInput(link.Pitch, link.Roll, link.Joystick, true);
            yield return null;
            yield return null;
            link.OverrideInput(link.Pitch, link.Roll, link.Joystick, false);
            yield return null;
            yield return null;
        }

        void PonerRobot(Vector3 pos, float yaw)
        {
            var rb = robot.GetComponent<Rigidbody>();
            rb.position = pos;
            rb.rotation = Quaternion.Euler(0f, yaw, 0f);
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            robot.transform.SetPositionAndRotation(pos, Quaternion.Euler(0f, yaw, 0f));
        }

        // ------------------------------------------------------------------ robot

        [UnityTest]
        public IEnumerator Pitch_positivo_hace_avanzar_al_robot_y_negativo_retroceder()
        {
            Vector3 p0 = robot.transform.position;
            link.OverrideInput(30f, 0f, Vector2.zero, false);
            yield return Esperar(1.5f);
            float avance = Vector3.Dot(robot.transform.position - p0, robot.transform.forward);
            Assert.Greater(avance, 0.6f, $"El robot avanzó solo {avance:0.00} m");
            Assert.Greater(robot.Speed, 0.5f);

            link.OverrideInput(0f, 0f, Vector2.zero, false);
            yield return Esperar(0.8f);
            Assert.Less(Mathf.Abs(robot.Speed), 0.05f, "El robot no se detiene al volver el control a reposo");

            Vector3 p1 = robot.transform.position;
            link.OverrideInput(-30f, 0f, Vector2.zero, false);
            yield return Esperar(1.0f);
            float retro = Vector3.Dot(robot.transform.position - p1, robot.transform.forward);
            Assert.Less(retro, -0.3f, "Con pitch negativo el robot debería retroceder");
        }

        [UnityTest]
        public IEnumerator Roll_positivo_gira_a_la_derecha()
        {
            float yaw0 = robot.transform.eulerAngles.y;
            link.OverrideInput(0f, 30f, Vector2.zero, false);
            yield return Esperar(1.0f);
            float giro = Mathf.DeltaAngle(yaw0, robot.transform.eulerAngles.y);
            Assert.Greater(giro, 30f, $"El robot giró solo {giro:0.0}°");
        }

        [UnityTest]
        public IEnumerator Zona_muerta_ignora_inclinaciones_pequenas()
        {
            Vector3 p0 = robot.transform.position;
            link.OverrideInput(4f, -4f, Vector2.zero, false);   // dentro de la zona muerta de 5°
            yield return Esperar(1.0f);
            Assert.Less((robot.transform.position - p0).magnitude, 0.02f);
        }

        [UnityTest]
        public IEnumerator La_pared_detiene_al_robot_y_vibra_con_patron_pared()
        {
            var choques = new List<string>();
            robot.OnCollisionReported += (tipo, v) => choques.Add(tipo);
            PonerRobot(new Vector3(-3f, 0f, 6.3f), 0f);          // mirando a la pared norte (cara interior en z = 8)
            yield return new WaitForFixedUpdate();
            link.OverrideInput(35f, 0f, Vector2.zero, false);
            yield return Esperar(3f);
            Assert.Less(robot.transform.position.z, 7.8f, "El robot atravesó el límite");
            Assert.Contains("pared", choques, "No se reportó el choque con la pared");
        }

        [UnityTest]
        public IEnumerator Empujar_un_cubo_vibra_con_patron_objeto()
        {
            var choques = new List<string>();
            robot.OnCollisionReported += (tipo, v) => choques.Add(tipo);
            var cubo = GameObject.Find("Cubo 1").GetComponent<Grabbable>();
            Vector3 frente = robot.transform.position + robot.transform.forward * 1.3f + Vector3.up * 0.13f;
            cubo.Body.position = frente;
            cubo.transform.position = frente;
            yield return new WaitForFixedUpdate();
            link.OverrideInput(35f, 0f, Vector2.zero, false);
            yield return Esperar(2f);
            Assert.Contains("objeto", choques, "No se reportó el choque con el objeto manipulable");
        }

        // ------------------------------------------------------------------ pinza

        [UnityTest]
        public IEnumerator Clic_agarra_el_cubo_lo_transporta_y_otro_clic_lo_suelta()
        {
            var cubo = GameObject.Find("Cubo 1").GetComponent<Grabbable>();
            Vector3 p = gripper.gripPoint.position + robot.transform.forward * 0.02f;
            cubo.Body.position = p;
            cubo.transform.position = p;
            yield return Esperar(0.3f);

            yield return Clic();
            Assert.AreSame(cubo, gripper.Held, "El clic no agarró el cubo");

            link.OverrideInput(30f, 0f, Vector2.zero, false);
            yield return Esperar(1.2f);
            link.OverrideInput(0f, 0f, Vector2.zero, false);
            yield return Esperar(0.3f);
            float d = Vector3.Distance(cubo.transform.position, gripper.gripPoint.position);
            Assert.Less(d, 0.12f, $"El cubo no siguió a la pinza (distancia {d:0.00} m)");

            yield return Clic();
            Assert.IsNull(gripper.Held, "El segundo clic no soltó el cubo");
        }

        [UnityTest]
        public IEnumerator Clic_sin_objeto_al_alcance_no_agarra_nada()
        {
            yield return Clic();
            Assert.IsNull(gripper.Held);
        }

        // ------------------------------------------------------------------ avatar

        [UnityTest]
        public IEnumerator Joystick_mueve_al_avatar_hacia_adelante_y_a_los_lados()
        {
            Vector3 p0 = avatar.transform.position;
            link.OverrideInput(0f, 0f, new Vector2(0f, 1f), false);
            yield return Esperar(1f);
            Vector3 d = avatar.transform.position - p0;
            Assert.Greater(d.z, 1.0f, $"Adelante: se movió {d.z:0.00} m en z");

            Vector3 p1 = avatar.transform.position;
            link.OverrideInput(0f, 0f, new Vector2(1f, 0f), false);
            yield return Esperar(1f);
            Vector3 d2 = avatar.transform.position - p1;
            Assert.Greater(d2.x, 1.0f, $"Derecha: se movió {d2.x:0.00} m en x");
            Assert.Less(Mathf.Abs(d2.z), 0.1f);
        }

        [UnityTest]
        public IEnumerator Joystick_en_zona_muerta_no_mueve_al_avatar()
        {
            Vector3 p0 = avatar.transform.position;
            link.OverrideInput(0f, 0f, new Vector2(0.1f, -0.1f), false);
            yield return Esperar(1f);
            Vector3 d = avatar.transform.position - p0;
            d.y = 0f;
            Assert.Less(d.magnitude, 0.01f);
        }

        [UnityTest]
        public IEnumerator El_avatar_no_sale_de_la_sala()
        {
            link.OverrideInput(0f, 0f, new Vector2(0f, -1f), false);   // hacia la pared sur (cara interior en z = −8)
            yield return Esperar(4f);
            Assert.Greater(avatar.transform.position.z, -7.8f, "El avatar atravesó el límite");
        }

        [UnityTest]
        public IEnumerator Mantener_el_boton_2s_recentra_sin_agarrar()
        {
            bool recentrado = false;
            avatar.OnRecentered += () => recentrado = true;
            link.OverrideInput(0f, 0f, Vector2.zero, true);
            yield return Esperar(2.3f);
            link.OverrideInput(0f, 0f, Vector2.zero, false);
            yield return null;
            yield return null;
            Assert.IsTrue(recentrado, "La pulsación larga no recentró");
            Assert.IsNull(gripper.Held, "La pulsación larga no debe contar como clic");
        }

        // ------------------------------------------------------------------ tarea

        [UnityTest]
        public IEnumerator La_tarea_se_completa_al_dejar_los_cubos_en_la_zona()
        {
            Assert.AreEqual(3, task.TargetCount);
            link.OverrideInput(20f, 0f, Vector2.zero, false);   // mover el robot arranca el cronómetro
            yield return Esperar(0.5f);
            link.OverrideInput(0f, 0f, Vector2.zero, false);
            Assert.AreEqual(TaskManager.State.Running, task.Current);

            var zona = Object.FindFirstObjectByType<DeliveryZone>().transform.position;
            int i = 0;
            foreach (var g in Object.FindObjectsByType<Grabbable>(FindObjectsSortMode.None))
            {
                if (!g.isTaskTarget) continue;
                Vector3 p = zona + new Vector3(-0.6f + 0.6f * i++, 0.2f, 0f);
                g.Body.position = p;
                g.transform.position = p;
            }
            yield return Esperar(0.5f);
            Assert.AreEqual(TaskManager.State.Done, task.Current, $"Entregados {task.Delivered}/{task.TargetCount}");
            Assert.Greater(task.ElapsedTime, 0f);
        }
    }
}
